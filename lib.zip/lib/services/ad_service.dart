// lib/services/ad_service.dart - COMPLETE FIXED VERSION
import 'package:flutter/material.dart';

class AdService {
  static final AdService _instance = AdService._internal();
  factory AdService() => _instance;
  AdService._internal();

  bool _adsEnabled = false; // Always false for ad-free experience

  Future<void> init() async {
    print('✅ Ad service initialized (Ad-Free Mode)');
    await Future.delayed(const Duration(milliseconds: 100));
  }

  Future<bool> showInterstitialAd() async {
    print('🆓 Ad-Free Mode: Skipping interstitial ad');
    await Future.delayed(const Duration(milliseconds: 100));
    return true;
  }

  // Banner ad simulation - COMPLETELY FIXED VERSION
  Widget createBannerAd({AdSize? adSize}) {
    if (!_adsEnabled) {
      return const SizedBox.shrink(); // Return empty container in ad-free mode
    }

    return Container(
      width: adSize?.width.toDouble() ?? 320,
      height: adSize?.height.toDouble() ?? 50,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Center(
        child: Text(
          'AD BANNER\n(Ad-Free Mode)',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  // Smart ad display
  Future<bool> showSmartInterstitialAd({
    int minTimeBetweenAds = 60,
    bool forceShow = false,
  }) async {
    print('🆓 Ad-Free Mode: Smart interstitial ad requested');
    return true;
  }

  // Quick banner widgets
  Widget get standardBanner => createBannerAd(adSize: AdSize.banner);
  Widget get largeBanner => createBannerAd(adSize: AdSize.largeBanner);
  Widget get mediumRectangle => createBannerAd(adSize: AdSize.mediumRectangle);

  // Ad state getters
  bool get isInterstitialAdLoaded => true;
  String get adStatus => 'Ad-Free Mode Active';

  void dispose() {
    print('🧹 Ad service disposed');
  }
}

// Mock AdSize class
class AdSize {
  final int width;
  final int height;

  const AdSize({required this.width, required this.height});

  // Standard ad sizes
  static const AdSize banner = AdSize(width: 320, height: 50);
  static const AdSize largeBanner = AdSize(width: 320, height: 100);
  static const AdSize mediumRectangle = AdSize(width: 300, height: 250);
  static const AdSize fullBanner = AdSize(width: 468, height: 60);
}