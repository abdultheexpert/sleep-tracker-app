// lib/services/notification_service.dart - COMPLETE FIXED VERSION
import 'package:flutter/material.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  // Global key to access navigator context
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  Future<void> init() async {
    print('✅ Notification service initialized');
  }

  Future<void> showSleepReminderNotification() async {
    print('🔔 Sleep reminder notification triggered');
    _showLocalAlert(
      'Time for Sleep Tracking! 🌙',
      'Start tracking your sleep for better insights and health monitoring.',
    );
  }

  Future<void> showSleepAnalysisNotification(String analysis) async {
    print('🔔 Sleep analysis notification triggered');
    _showLocalAlert('Sleep Analysis Complete! 📊', analysis);
  }

  Future<void> showDailyAffirmationNotification(String affirmation) async {
    print('🔔 Daily affirmation notification triggered');
    _showLocalAlert('Daily Affirmation 💫', affirmation);
  }

  Future<void> showPremiumUnlockedNotification() async {
    print('🔔 Premium unlocked notification triggered');
    _showLocalAlert(
      'Premium Unlocked! 🎉',
      'You now have access to all premium features including 260+ sounds and advanced analytics.',
    );
  }

  Future<void> showGiftCodeRedeemedNotification(String plan) async {
    print('🔔 Gift code redeemed notification triggered');
    _showLocalAlert(
      'Gift Code Activated! 🎁',
      'Your $plan subscription has been activated. Enjoy premium features!',
    );
  }

  void _showLocalAlert(String title, String message) {
    // Use the navigator key to show dialog
    if (navigatorKey.currentState != null && navigatorKey.currentContext != null) {
      showDialog(
        context: navigatorKey.currentContext!,
        builder: (context) => AlertDialog(
          backgroundColor: Color(0xFF1D1E33),
          title: Text(
            title,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: Text(
            message,
            style: TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'OK',
                style: TextStyle(color: Colors.blueAccent),
              ),
            ),
          ],
        ),
      );
    } else {
      print('⚠️ Cannot show notification - no navigator context available');
    }
  }

  // Schedule notifications (simplified version)
  Future<void> scheduleDailyReminder(TimeOfDay time, String message) async {
    print('⏰ Scheduled daily reminder for ${time.hour}:${time.minute}: $message');
    // In production, you would use flutter_local_notifications package here
  }

  Future<void> scheduleSleepReminder() async {
    final eveningTime = TimeOfDay(hour: 21, minute: 0); // 9:00 PM
    await scheduleDailyReminder(
      eveningTime,
      'Time to wind down and track your sleep for optimal rest and recovery.',
    );
  }

  Future<void> scheduleMorningReminder() async {
    final morningTime = TimeOfDay(hour: 7, minute: 0); // 7:00 AM
    await scheduleDailyReminder(
      morningTime,
      'Check your sleep analysis and start your day with a fresh affirmation!',
    );
  }

  // Notification management
  Future<void> cancelAllNotifications() async {
    print('🔕 All scheduled notifications cancelled');
  }

  Future<void> cancelNotification(int id) async {
    print('🔕 Notification $id cancelled');
  }

  // Test method
  Future<void> testNotification() async {
    await showSleepReminderNotification();
  }

  // Check if notifications are enabled
  Future<bool> areNotificationsEnabled() async {
    return true; // Simplified - always return true
  }

  // Request notification permissions
  Future<bool> requestPermissions() async {
    print('🔔 Notification permissions requested');
    return true; // Simplified - always return true
  }

  // Get notification settings
  Map<String, dynamic> getNotificationSettings() {
    return {
      'sleepReminders': true,
      'analysisAlerts': true,
      'dailyAffirmations': true,
      'premiumAlerts': true,
    };
  }

  // Update notification settings
  Future<void> updateNotificationSettings(Map<String, bool> settings) async {
    print('⚙️ Notification settings updated: $settings');
  }
}

// Standalone TimeOfDay class (in case you don't have it imported)
class TimeOfDay {
  final int hour;
  final int minute;

  const TimeOfDay({required this.hour, required this.minute});

  String format(BuildContext context) {
    final hour12 = hour > 12 ? hour - 12 : hour;
    final period = hour >= 12 ? 'PM' : 'AM';
    return '${hour12.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')} $period';
  }

  @override
  String toString() {
    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }
}

// Optional: If you want to create a separate NavigationService, here it is:
class NavigationService {
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static BuildContext? get context => navigatorKey.currentContext;

  static Future<dynamic> navigateTo(String routeName, {Object? arguments}) {
    return navigatorKey.currentState!.pushNamed(routeName, arguments: arguments);
  }

  static void goBack() {
    navigatorKey.currentState!.pop();
  }

  static Future<dynamic> navigateReplacement(String routeName, {Object? arguments}) {
    return navigatorKey.currentState!.pushReplacementNamed(routeName, arguments: arguments);
  }

  static Future<dynamic> navigateAndRemoveUntil(String routeName, {Object? arguments}) {
    return navigatorKey.currentState!.pushNamedAndRemoveUntil(
      routeName,
          (route) => false,
      arguments: arguments,
    );
  }
}