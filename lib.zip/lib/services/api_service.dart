import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static String BASE_URL = 'https://sleep-tracker-backend-0a9f.onrender.com';
  static const Duration TIMEOUT_DURATION = Duration(seconds: 15);

  static String? _authToken;

  // Initialize API service
  static Future<void> initialize() async {
    await _loadAuthToken();
    print('🚀 API Service initialized with: $BASE_URL');
  }

  // Load stored auth token
  static Future<void> _loadAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    _authToken = prefs.getString('auth_token');
    if (_authToken != null) {
      print('🔑 Loaded auth token from storage');
    }
  }

  // Save auth token
  static Future<void> _saveAuthToken(String token) async {
    _authToken = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    print('💾 Auth token saved');
  }

  // Clear auth token (logout)
  static Future<void> clearAuthToken() async {
    _authToken = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    print('🗑️ Auth token cleared');
  }

  // ========== HEALTH CHECK ==========
  static Future<bool> testConnection() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/health'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      bool isConnected = response.statusCode == 200;
      print(isConnected ? '✅ Backend connected!' : '❌ Backend error');
      return isConnected;
    } catch (e) {
      print('❌ Backend connection failed: $e');
      return false;
    }
  }

  // ========== AUTHENTICATION ENDPOINTS ==========

  // User Registration - POST /api/users/register
  static Future<Map<String, dynamic>> registerUser({
    required String name,
    required String email,
    required String password,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$BASE_URL/api/users/register'),
        headers: _getHeaders(),
        body: json.encode({
          'name': name,
          'email': email,
          'password': password,
          'subscription': 'free'
        }),
      ).timeout(TIMEOUT_DURATION);

      final data = json.decode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (data['token'] != null) {
          await _saveAuthToken(data['token']);
        }
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['message'] ?? 'Registration failed'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // User Login - POST /api/users/login
  static Future<Map<String, dynamic>> loginUser({
    required String email,
    required String password,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$BASE_URL/api/users/login'),
        headers: _getHeaders(),
        body: json.encode({
          'email': email,
          'password': password,
        }),
      ).timeout(TIMEOUT_DURATION);

      final data = json.decode(response.body);

      if (response.statusCode == 200) {
        if (data['token'] != null) {
          await _saveAuthToken(data['token']);
        }
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['message'] ?? 'Login failed'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Get User Profile - GET /api/users/profile
  static Future<Map<String, dynamic>> getUserProfile() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/users/profile'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': 'Failed to fetch profile'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // ========== SLEEP SESSION MANAGEMENT ==========

  // Submit sleep session - OPTIMIZED FOR SLEEP TRACKER
  static Future<Map<String, dynamic>> submitSleepSession({
    required double duration,
    required int quality,
    required Map<String, double> stages,
    required List<String> soundsDetected,
    required String date,
  }) async {
    try {
      print('💾 Submitting sleep session to backend...');
      final response = await http.post(
        Uri.parse('$BASE_URL/api/sleep-sessions'),
        headers: _getHeaders(),
        body: json.encode({
          'duration': duration,
          'quality': quality,
          'stages': stages,
          'soundsDetected': soundsDetected,
          'date': date,
          'deviceType': 'flutter_mobile',
          'appVersion': '1.0.0',
        }),
      ).timeout(TIMEOUT_DURATION);

      final data = json.decode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        print('✅ Sleep session submitted successfully! Session ID: ${data['_id']}');
        return {'success': true, 'data': data};
      } else {
        print('❌ Sleep session submission failed: ${response.statusCode} - ${data['message']}');
        return {'success': false, 'error': data['message'] ?? 'Failed to submit sleep session'};
      }
    } catch (e) {
      print('❌ Error submitting sleep session: $e');
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // Get all users (admin only)
  static Future<List<dynamic>> getUsers() async {
    try {
      print('👥 Fetching users from backend...');
      final response = await http.get(
        Uri.parse('$BASE_URL/api/admin/users'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        print('✅ Users fetched: ${data.length} users');
        return data;
      } else {
        print('❌ Users endpoint returned status: ${response.statusCode}');
        return _getDemoUsers();
      }
    } catch (e) {
      print('❌ Error fetching users: $e');
      return _getDemoUsers();
    }
  }

  // Get User Sleep History - GET /api/sleep-sessions
  static Future<List<dynamic>> getSleepHistory() async {
    try {
      print('📊 Fetching sleep history from backend...');
      final response = await http.get(
        Uri.parse('$BASE_URL/api/sleep-sessions'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        print('✅ Sleep history fetched: ${data.length} sessions');
        return data;
      } else {
        print('❌ Sleep history endpoint returned status: ${response.statusCode}');
        return _getDemoSleepData();
      }
    } catch (e) {
      print('❌ Error fetching sleep history: $e');
      return _getDemoSleepData();
    }
  }

  // Get Sleep Analytics - GET /api/sleep-analytics
  static Future<Map<String, dynamic>> getSleepAnalytics({String period = '30d'}) async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/sleep-analytics?period=$period'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return {'success': true, 'data': data};
      } else {
        return await getDemoStats();
      }
    } catch (e) {
      return await getDemoStats();
    }
  }

  // ========== SOUNDS MANAGEMENT ==========

  // Get All Sounds - GET /api/sounds
  static Future<List<dynamic>> getSounds() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/sounds'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data;
      } else {
        return _getDemoSounds();
      }
    } catch (e) {
      return _getDemoSounds();
    }
  }

  // ========== CONTENT MANAGEMENT ==========

  // Get Meditations
  static Future<List<dynamic>> getMeditations() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/content/meditations'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data;
      } else {
        return _getDemoMeditations();
      }
    } catch (e) {
      return _getDemoMeditations();
    }
  }

  // Get Stories
  static Future<List<dynamic>> getStories() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/content/stories'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data;
      } else {
        return _getDemoStories();
      }
    } catch (e) {
      return _getDemoStories();
    }
  }

  // Get Music
  static Future<List<dynamic>> getMusic() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/content/music'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data;
      } else {
        return _getDemoMusic();
      }
    } catch (e) {
      return _getDemoMusic();
    }
  }

  // Get Videos
  static Future<List<dynamic>> getVideos() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/content/videos'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data;
      } else {
        return _getDemoVideos();
      }
    } catch (e) {
      return _getDemoVideos();
    }
  }

  // ========== SUBSCRIPTION MANAGEMENT ==========

  // Get Subscription Plans
  static Future<List<dynamic>> getSubscriptionPlans() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/payments/plans'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data;
      } else {
        return _getDemoSubscriptionPlans();
      }
    } catch (e) {
      return _getDemoSubscriptionPlans();
    }
  }

  // Check Subscription Status
  static Future<bool> checkSubscriptionStatus() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/payments/subscription'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['isActive'] == true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
    }
  }

  // ========== GIFT CODE SYSTEM ==========

  // Redeem Gift Code
  static Future<Map<String, dynamic>> redeemGiftCode({
    required String code,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$BASE_URL/api/gift-codes/redeem'),
        headers: _getHeaders(),
        body: json.encode({
          'code': code,
        }),
      ).timeout(TIMEOUT_DURATION);

      final data = json.decode(response.body);

      if (response.statusCode == 200) {
        return {'success': true, 'data': data};
      } else {
        return {'success': false, 'error': data['message'] ?? 'Redemption failed'};
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // ========== AI SLEEP ANALYSIS ==========

  // AI Sleep Analysis - OPTIMIZED FOR SLEEP TRACKER
  static Future<Map<String, dynamic>> analyzeSleepWithAI({
    required String audioData,
    required String userId,
    required String sessionId,
  }) async {
    try {
      print('🤖 Sending sleep data for AI analysis...');
      final response = await http.post(
        Uri.parse('$BASE_URL/api/ai/analyze-sleep'),
        headers: _getHeaders(),
        body: json.encode({
          'audio_data': audioData,
          'userId': userId,
          'sessionId': sessionId,
          'analysis_type': 'comprehensive',
          'timestamp': DateTime.now().toIso8601String(),
        }),
      ).timeout(TIMEOUT_DURATION);

      final data = json.decode(response.body);

      if (response.statusCode == 200) {
        print('✅ AI analysis completed successfully');
        return {'success': true, 'data': data};
      } else {
        print('❌ AI analysis failed: ${data['message']}');
        return {'success': false, 'error': data['message'] ?? 'AI analysis failed'};
      }
    } catch (e) {
      print('❌ Error during AI analysis: $e');
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // ========== DASHBOARD ANALYTICS ==========

  // Get Dashboard Stats
  static Future<Map<String, dynamic>> getDashboardStats() async {
    try {
      final response = await http.get(
        Uri.parse('$BASE_URL/api/dashboard/stats'),
        headers: _getHeaders(),
      ).timeout(TIMEOUT_DURATION);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return {'success': true, 'data': data};
      } else {
        return await getDemoStats();
      }
    } catch (e) {
      return await getDemoStats();
    }
  }

  // ========== SOCIAL LOGIN ==========

  // Social Login
  static Future<Map<String, dynamic>> socialLogin({
    required String provider,
    required String token,
    required String email,
    required String name,
  }) async {
    try {
      print('🌐 Social login with: $provider');
      final response = await http.post(
        Uri.parse('$BASE_URL/api/auth/social'),
        headers: _getHeaders(),
        body: json.encode({
          'provider': provider,
          'token': token,
          'email': email,
          'name': name,
        }),
      ).timeout(TIMEOUT_DURATION);

      final data = json.decode(response.body);

      if (response.statusCode == 200) {
        if (data['token'] != null) {
          await _saveAuthToken(data['token']);
        }
        print('✅ Social login successful!');
        return {'success': true, 'data': data};
      } else {
        print('❌ Social login failed: ${data['message']}');
        return {'success': false, 'error': data['message'] ?? 'Social login failed'};
      }
    } catch (e) {
      print('❌ Error during social login: $e');
      return {'success': false, 'error': 'Network error: $e'};
    }
  }

  // ========== HELPER METHODS ==========

  // Get headers with authorization
  static Map<String, String> _getHeaders() {
    final headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (_authToken != null) {
      headers['Authorization'] = 'Bearer $_authToken';
    }

    return headers;
  }

  // ========== DEMO DATA (FALLBACK) ==========

  static Future<Map<String, dynamic>> getDemoStats() async {
    await Future.delayed(Duration(milliseconds: 500));
    return {
      'success': true,
      'data': {
        'totalUsers': 1250,
        'activeSubscriptions': 298,
        'totalSleepSessions': 15678,
        'premiumUsers': 298,
        'monthlyRevenue': 2977.02
      }
    };
  }

  static List<dynamic> _getDemoUsers() {
    return [
      {
        '_id': '1',
        'name': 'John Doe',
        'email': 'john@example.com',
        'isPremium': true,
        'joinDate': '2024-01-15',
        'source': 'demo_data'
      },
      {
        '_id': '2',
        'name': 'Sarah Smith',
        'email': 'sarah@example.com',
        'isPremium': false,
        'joinDate': '2024-01-20',
        'source': 'demo_data'
      }
    ];
  }

  static List<dynamic> _getDemoSleepData() {
    return [
      {
        '_id': '1',
        'duration': 7.5,
        'quality': 85,
        'stages': {'light': 4.5, 'deep': 1.5, 'rem': 1.5},
        'soundsDetected': ['snoring', 'deep breathing'],
        'date': DateTime.now().subtract(Duration(days: 1)).toIso8601String(),
        'source': 'demo_data'
      }
    ];
  }

  static List<dynamic> _getDemoSounds() {
    return [
      {
        '_id': '1',
        'name': 'Ocean Waves',
        'category': 'Nature',
        'isPremium': false,
        'file': 'sounds/nature/ocean_waves.mp3',
        'source': 'demo_data'
      },
      {
        '_id': '2',
        'name': 'Rainfall',
        'category': 'Nature',
        'isPremium': false,
        'file': 'sounds/nature/rainfall.mp3',
        'source': 'demo_data'
      }
    ];
  }

  static List<dynamic> _getDemoMeditations() {
    return [
      {
        '_id': '1',
        'title': 'Morning Calm',
        'description': 'Start your day with peace',
        'duration': '10 min',
        'isPremium': false,
        'source': 'demo_data'
      }
    ];
  }

  static List<dynamic> _getDemoStories() {
    return [
      {
        '_id': '1',
        'title': 'The Peaceful Forest',
        'description': 'A calming journey through enchanted woods',
        'duration': '25 min',
        'isPremium': false,
        'source': 'demo_data'
      }
    ];
  }

  static List<dynamic> _getDemoMusic() {
    return [
      {
        '_id': 'music_1',
        'title': 'Calm Piano Melodies',
        'description': 'Soothing piano for relaxation',
        'duration': '45 min',
        'artist': 'Piano Peace',
        'isPremium': false,
        'source': 'demo_data'
      }
    ];
  }

  static List<dynamic> _getDemoVideos() {
    return [
      {
        '_id': 'video_1',
        'title': 'Guided Sleep Meditation',
        'description': 'Visual journey to peaceful sleep',
        'duration': '15 min',
        'isPremium': false,
        'source': 'demo_data'
      }
    ];
  }

  static List<dynamic> _getDemoSubscriptionPlans() {
    return [
      {
        'id': 'free',
        'name': 'Free',
        'price': 0,
        'features': ['Basic sleep tracking', '5 sounds access']
      },
      {
        'id': 'premium',
        'name': 'Premium',
        'price': 9.99,
        'features': ['260+ premium sounds', 'AI sleep analysis']
      }
    ];
  }

  // ========== COMPREHENSIVE TEST ==========
  static Future<void> runComprehensiveTest() async {
    print('\n🧪 ===== COMPREHENSIVE BACKEND TEST =====\n');

    try {
      bool connected = await testConnection();
      print('🔗 Connection: ${connected ? "✅ SUCCESS" : "❌ FAILED"}');

      if (connected) {
        await getSounds();
        await getMeditations();
        await getStories();
        await getMusic();
        await getVideos();
        await getSubscriptionPlans();
        await getDashboardStats();
        await getSleepHistory();

        print('\n🎉 ===== ALL ENDPOINTS TESTED SUCCESSFULLY =====\n');
      } else {
        print('\n⚠️  Backend offline - using demo data mode\n');
      }
    } catch (e) {
      print('\n❌ Comprehensive test failed: $e\n');
    }
  }
}