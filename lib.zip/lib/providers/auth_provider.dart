import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

class AuthProvider with ChangeNotifier {
  bool _isLoggedIn = false;
  String _userName = '';
  String _userEmail = '';
  String _loginMethod = '';
  bool _isPremium = false;
  String _userId = '';
  bool _isGuest = false;
  bool _showSignupSuccess = false;
  bool _isLoading = false;
  String? _error;
  String? _authToken;
  DateTime? _premiumExpiry;
  Map<String, dynamic> _userProfile = {};

  // Getters
  bool get isLoggedIn => _isLoggedIn;
  String get userName => _userName;
  String get userEmail => _userEmail;
  String get loginMethod => _loginMethod;
  bool get isPremium => _isPremium;
  String get userId => _userId;
  bool get isGuest => _isGuest;
  bool get showSignupSuccess => _showSignupSuccess;
  bool get isLoading => _isLoading;
  String? get error => _error;
  String? get authToken => _authToken;
  DateTime? get premiumExpiry => _premiumExpiry;
  Map<String, dynamic> get userProfile => _userProfile;

  AuthProvider() {
    _loadAuthState();
  }

  // ========== AUTH STATE MANAGEMENT ==========

  Future<void> _loadAuthState() async {
    try {
      setState(() {
        _isLoading = true;
      });

      final prefs = await SharedPreferences.getInstance();
      _isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
      _userName = prefs.getString('userName') ?? '';
      _userEmail = prefs.getString('userEmail') ?? '';
      _loginMethod = prefs.getString('loginMethod') ?? '';
      _isPremium = prefs.getBool('isPremium') ?? false;
      _userId = prefs.getString('userId') ?? '';
      _isGuest = prefs.getBool('isGuest') ?? false;
      _showSignupSuccess = prefs.getBool('showSignupSuccess') ?? false;
      _authToken = prefs.getString('authToken');

      final expiryString = prefs.getString('premiumExpiry');
      if (expiryString != null) {
        _premiumExpiry = DateTime.tryParse(expiryString);
      }

      // Sync with backend if logged in and has valid token
      if (_isLoggedIn && _authToken != null && !_isGuest) {
        await _syncWithBackend();
      }

      print('🔐 Auth state loaded: $_isLoggedIn, User: $_userName, Premium: $_isPremium');
    } catch (e) {
      print('❌ Error loading auth state: $e');
      _error = 'Failed to load authentication state';
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _syncWithBackend() async {
    try {
      print('🔄 Syncing user data with backend...');

      // Get user profile from backend
      final result = await ApiService.getUserProfile();
      if (result['success']) {
        final userData = result['data'];
        _updateUserDataFromBackend(userData);
        await _saveAuthState();
        print('✅ User data synced with backend');
      } else {
        print('⚠️ Backend sync failed: ${result['error']}');
      }
    } catch (e) {
      print('❌ Error syncing with backend: $e');
    }
  }

  void _updateUserDataFromBackend(Map<String, dynamic> userData) {
    _userName = userData['name'] ?? _userName;
    _userEmail = userData['email'] ?? _userEmail;
    _isPremium = userData['isPremium'] ?? _isPremium;
    _userId = userData['_id'] ?? _userId;

    // Update premium expiry if available
    if (userData['premiumExpiry'] != null) {
      _premiumExpiry = DateTime.tryParse(userData['premiumExpiry']);
    }

    _userProfile = userData;
  }

  Future<void> _saveAuthState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isLoggedIn', _isLoggedIn);
      await prefs.setString('userName', _userName);
      await prefs.setString('userEmail', _userEmail);
      await prefs.setString('loginMethod', _loginMethod);
      await prefs.setBool('isPremium', _isPremium);
      await prefs.setString('userId', _userId);
      await prefs.setBool('isGuest', _isGuest);
      await prefs.setBool('showSignupSuccess', _showSignupSuccess);

      if (_authToken != null) {
        await prefs.setString('authToken', _authToken!);
      }

      if (_premiumExpiry != null) {
        await prefs.setString('premiumExpiry', _premiumExpiry!.toIso8601String());
      }
    } catch (e) {
      print('❌ Error saving auth state: $e');
    }
  }

  // ========== AUTHENTICATION METHODS ==========

  Future<bool> loginAsGuest() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      await Future.delayed(Duration(seconds: 1));

      _isLoggedIn = true;
      _userName = 'Guest User';
      _userEmail = 'guest@sleeptracker.com';
      _loginMethod = 'guest';
      _userId = 'guest_${DateTime.now().millisecondsSinceEpoch}';
      _isPremium = false;
      _isGuest = true;
      _authToken = null;
      _premiumExpiry = null;

      await _saveAuthState();
      notifyListeners();

      print('🎮 Guest login successful');
      return true;
    } catch (e) {
      _error = 'Failed to login as guest';
      return false;
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<bool> login(String email, String password) async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      print('🔐 Attempting login for: $email');

      // Use backend login
      final result = await ApiService.loginUser(email: email, password: password);

      if (result['success']) {
        // Backend login successful
        final userData = result['data'];
        _handleSuccessfulLogin(
          name: userData['user']['name'] ?? email.split('@').first,
          email: email,
          method: 'email',
          userId: userData['user']['_id'],
          isPremium: userData['user']['isPremium'] ?? false,
          token: userData['token'],
          premiumExpiry: userData['user']['premiumExpiry'],
        );

        print('✅ Backend login successful');
        return true;
      } else {
        // Backend login failed
        _error = result['error'] ?? 'Login failed. Please check your credentials.';
        return false;
      }
    } catch (e) {
      print('❌ Login error: $e');
      _error = 'Login failed. Please check your internet connection.';
      return false;
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<bool> signUp(String name, String email, String password) async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      print('📝 Attempting signup for: $email');

      // Use backend registration
      final result = await ApiService.registerUser(
        name: name,
        email: email,
        password: password,
      );

      if (result['success']) {
        // Backend registration successful
        final userData = result['data'];
        _handleSuccessfulLogin(
          name: name,
          email: email,
          method: 'email',
          userId: userData['user']['_id'],
          isPremium: userData['user']['isPremium'] ?? false,
          token: userData['token'],
        );

        _showSignupSuccess = true;
        await _saveAuthState();
        notifyListeners();

        print('✅ Backend signup successful');
        return true;
      } else {
        // Backend registration failed
        _error = result['error'] ?? 'Registration failed. Please try again.';
        return false;
      }
    } catch (e) {
      print('❌ Signup error: $e');
      _error = 'Registration failed. Please check your internet connection.';
      return false;
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<bool> loginWithSocial(String name, String email, String method) async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      print('🌐 Social login: $method - $email');

      // Use backend social login
      final result = await ApiService.socialLogin(
        provider: method,
        token: 'social_token_${DateTime.now().millisecondsSinceEpoch}',
        email: email,
        name: name,
      );

      if (result['success']) {
        final userData = result['data'];
        _handleSuccessfulLogin(
          name: name,
          email: email,
          method: method,
          userId: userData['user']['_id'],
          isPremium: userData['user']['isPremium'] ?? false,
          token: userData['token'],
        );

        print('✅ Social login successful: $method');
        return true;
      } else {
        // Fallback to local social login if backend fails
        return await _localSocialLogin(name, email, method);
      }
    } catch (e) {
      print('❌ Social login error: $e');
      return await _localSocialLogin(name, email, method);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<bool> _localSocialLogin(String name, String email, String method) async {
    try {
      _handleSuccessfulLogin(
        name: name,
        email: email,
        method: method,
        userId: '${method}_${DateTime.now().millisecondsSinceEpoch}',
        isPremium: false,
      );

      print('✅ Local social login successful: $method');
      return true;
    } catch (e) {
      _error = 'Social login failed';
      return false;
    }
  }

  // ========== SIMPLIFIED FIREBASE METHODS ==========

  Future<bool> loginWithFirebase(String name, String email, String uid) async {
    try {
      setState(() {
        _isLoading = true;
      });

      _isLoggedIn = true;
      _userName = name;
      _userEmail = email;
      _userId = uid;
      _isPremium = false;
      _authToken = 'firebase_token_$uid';
      _isGuest = false;
      _loginMethod = 'firebase';

      await _saveAuthState();
      notifyListeners();

      print('✅ Firebase login successful: $_userName');

      // Sync with backend
      await _syncFirebaseUserWithBackend(name, email, uid);
      return true;
    } catch (e) {
      print('❌ Error with Firebase login: $e');
      _error = 'Failed to login with Firebase';
      return false;
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _syncFirebaseUserWithBackend(String name, String email, String uid) async {
    try {
      print('🔄 Syncing Firebase user with backend...');

      final result = await ApiService.socialLogin(
        provider: 'firebase',
        token: 'firebase_token_$uid',
        email: email,
        name: name,
      );

      if (result['success']) {
        final userData = result['data'];
        _updateUserDataFromBackend(userData);
        await _saveAuthState();
        print('✅ Firebase user synced with backend');
      }
    } catch (e) {
      print('❌ Error syncing Firebase user with backend: $e');
    }
  }

  Future<void> checkAuthenticationStatus() async {
    try {
      setState(() {
        _isLoading = true;
      });

      // Check if we have a stored token
      if (_authToken != null) {
        // Verify token with backend
        final isValid = await _validateTokenWithBackend();
        if (isValid) {
          // Token is valid, user is logged in
          _isLoggedIn = true;
          await _syncWithBackend();
          notifyListeners();
          return;
        } else {
          // Token is invalid, clear it
          await clearAuthToken();
        }
      }

      // Check guest session
      final prefs = await SharedPreferences.getInstance();
      bool isGuest = prefs.getBool('isGuest') ?? false;

      if (isGuest) {
        _isLoggedIn = true;
        _isGuest = true;
        _userName = prefs.getString('userName') ?? 'Guest User';
        _userEmail = prefs.getString('userEmail') ?? 'guest@sleeptracker.com';
        notifyListeners();
        return;
      }

      // No valid session found
      _isLoggedIn = false;
      notifyListeners();

    } catch (e) {
      print('❌ Error in checkAuthenticationStatus: $e');
      // On error, default to logged out state for security
      _isLoggedIn = false;
      notifyListeners();
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<bool> _validateTokenWithBackend() async {
    try {
      final result = await ApiService.getUserProfile();
      return result['success'] == true;
    } catch (e) {
      return false;
    }
  }

  Future<void> clearAuthToken() async {
    _authToken = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('authToken');
    print('🗑️ Auth token cleared');
  }

  void _handleSuccessfulLogin({
    required String name,
    required String email,
    required String method,
    required String userId,
    required bool isPremium,
    String? token,
    String? premiumExpiry,
  }) {
    _isLoggedIn = true;
    _userName = name;
    _userEmail = email;
    _loginMethod = method;
    _userId = userId;
    _isPremium = isPremium;
    _isGuest = false;
    _authToken = token;

    if (premiumExpiry != null) {
      _premiumExpiry = DateTime.tryParse(premiumExpiry);
    }

    _saveAuthState();
    notifyListeners();
  }

  // ========== PREMIUM SUBSCRIPTION MANAGEMENT ==========

  Future<bool> upgradeToPremium([String plan = 'monthly']) async {
    try {
      setState(() {
        _isLoading = true;
      });

      print('⭐ Upgrading to premium: $plan');

      _isPremium = true;

      // Calculate expiry based on plan
      final now = DateTime.now();
      if (plan == 'monthly') {
        _premiumExpiry = now.add(Duration(days: 30));
      } else if (plan == 'yearly') {
        _premiumExpiry = now.add(Duration(days: 365));
      } else if (plan == 'lifetime') {
        _premiumExpiry = now.add(Duration(days: 365 * 10));
      }

      await _saveAuthState();
      notifyListeners();

      print('✅ Premium upgrade successful: $plan');
      return true;
    } catch (e) {
      print('❌ Premium upgrade error: $e');
      _error = 'Upgrade failed. Please try again.';
      return false;
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<bool> redeemGiftCode(String code) async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      print('🎁 Redeeming gift code: $code');

      final result = await ApiService.redeemGiftCode(code: code);

      if (result['success']) {
        _isPremium = true;
        final plan = result['data']['plan'] ?? 'monthly';

        // Set expiry based on plan
        final now = DateTime.now();
        if (plan == 'monthly') {
          _premiumExpiry = now.add(Duration(days: 30));
        } else if (plan == 'yearly') {
          _premiumExpiry = now.add(Duration(days: 365));
        } else if (plan == 'lifetime') {
          _premiumExpiry = now.add(Duration(days: 365 * 10));
        }

        await _saveAuthState();
        notifyListeners();

        print('✅ Gift code redeemed successfully: $plan');
        return true;
      } else {
        _error = result['error'] ?? 'Invalid gift code';
        return false;
      }
    } catch (e) {
      print('❌ Gift code redemption error: $e');
      _error = 'Failed to redeem gift code';
      return false;
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void downgradeToFree() {
    _isPremium = false;
    _premiumExpiry = null;
    _saveAuthState();
    notifyListeners();

    print('🔓 Downgraded to free tier');
  }

  // ========== UTILITY METHODS ==========

  void setSignupSuccess() {
    _showSignupSuccess = true;
    _saveAuthState();
    notifyListeners();
  }

  void resetSignupSuccess() {
    _showSignupSuccess = false;
    _saveAuthState();
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void logout() {
    _isLoggedIn = false;
    _userName = '';
    _userEmail = '';
    _loginMethod = '';
    _isPremium = false;
    _userId = '';
    _isGuest = false;
    _showSignupSuccess = false;
    _authToken = null;
    _premiumExpiry = null;
    _userProfile = {};

    // Clear API service token
    ApiService.clearAuthToken();

    _saveAuthState();
    notifyListeners();

    print('🚪 User logged out');
  }

  Future<void> checkSubscriptionStatus() async {
    if (_isGuest || _userId.isEmpty) {
      return;
    }

    try {
      setState(() {
        _isLoading = true;
      });

      bool isPremiumBackend = await ApiService.checkSubscriptionStatus();
      if (_isPremium != isPremiumBackend) {
        _isPremium = isPremiumBackend;
        await _saveAuthState();
        notifyListeners();
      }

      // Check if premium has expired
      if (_isPremium && _premiumExpiry != null && _premiumExpiry!.isBefore(DateTime.now())) {
        _isPremium = false;
        _premiumExpiry = null;
        await _saveAuthState();
        notifyListeners();
      }

    } catch (e) {
      print('❌ Error checking subscription: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Check if premium is about to expire (within 7 days)
  bool get isPremiumExpiringSoon {
    if (!_isPremium || _premiumExpiry == null) return false;
    final daysUntilExpiry = _premiumExpiry!.difference(DateTime.now()).inDays;
    return daysUntilExpiry <= 7 && daysUntilExpiry > 0;
  }

  // Get days until premium expiry
  int? get daysUntilPremiumExpiry {
    if (!_isPremium || _premiumExpiry == null) return null;
    return _premiumExpiry!.difference(DateTime.now()).inDays;
  }

  void setState(VoidCallback fn) {
    fn();
    notifyListeners();
  }

  // Refresh user data from backend
  Future<void> refreshUserData() async {
    if (_isLoggedIn && !_isGuest) {
      await _syncWithBackend();
    }
  }

  // Validate current auth state
  bool get isValidAuthState {
    if (!_isLoggedIn) return true; // Not logged in is valid
    if (_isGuest) return true; // Guest mode is valid

    // For logged-in users, check if we have essential data
    return _userId.isNotEmpty && _userEmail.isNotEmpty;
  }

  // Get user display name (first name only)
  String get displayName {
    if (_userName.isEmpty) return 'User';
    return _userName.split(' ').first;
  }

  // Check if user has active subscription
  bool get hasActiveSubscription {
    if (!_isPremium) return false;
    if (_premiumExpiry == null) return true;
    return _premiumExpiry!.isAfter(DateTime.now());
  }
}