import 'package:flutter/foundation.dart';
import '../services/api_service.dart';

class ContentProvider with ChangeNotifier {
  List<Map<String, dynamic>> _meditations = [];
  List<Map<String, dynamic>> _stories = [];
  List<Map<String, dynamic>> _music = [];
  List<Map<String, dynamic>> _affirmations = [];
  List<Map<String, dynamic>> _videos = [];
  int _currentAffirmationIndex = 0;
  bool _isLoading = false;
  String? _error;

  // Getters
  List<Map<String, dynamic>> get meditations => _meditations;
  List<Map<String, dynamic>> get stories => _stories;
  List<Map<String, dynamic>> get music => _music;
  List<Map<String, dynamic>> get affirmations => _affirmations;
  List<Map<String, dynamic>> get videos => _videos;
  bool get isLoading => _isLoading;
  String? get error => _error;

  String get dailyAffirmation => _affirmations.isNotEmpty
      ? _affirmations[_currentAffirmationIndex]['text']
      : 'Start your day with positive energy!';

  Map<String, dynamic> get currentAffirmation => _affirmations.isNotEmpty
      ? _affirmations[_currentAffirmationIndex]
      : {'id': 'default', 'text': 'Start your day with positive energy!', 'day': 1};

  ContentProvider() {
    _loadAllContent();
  }

  // ========== CONTENT LOADING ==========

  Future<void> _loadAllContent() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      // Try backend first, then fallback to local
      await _loadContentFromBackend();

      // Load affirmations (always local)
      _loadAffirmations();

      // If backend failed, load local content
      if (_meditations.isEmpty && _stories.isEmpty && _music.isEmpty && _videos.isEmpty) {
        _loadLocalContent();
      }

      print('✅ Content loaded: ${_meditations.length} meditations, ${_stories.length} stories, '
          '${_music.length} music, ${_videos.length} videos, ${_affirmations.length} affirmations');
    } catch (e) {
      print('❌ Error loading content: $e');
      _error = 'Failed to load content. Please check your connection.';
      _loadLocalContent();
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _loadContentFromBackend() async {
    try {
      print('🔄 Loading content from backend...');

      // Load meditations from backend
      final backendMeditations = await ApiService.getMeditations();
      if (backendMeditations.isNotEmpty) {
        _meditations = _convertBackendToAppFormat(backendMeditations, 'meditation');
        print('✅ Loaded ${_meditations.length} meditations from backend');
      }

      // Load stories from backend
      final backendStories = await ApiService.getStories();
      if (backendStories.isNotEmpty) {
        _stories = _convertBackendToAppFormat(backendStories, 'story');
        print('✅ Loaded ${_stories.length} stories from backend');
      }

      // Load music from backend
      final backendMusic = await ApiService.getMusic();
      if (backendMusic.isNotEmpty) {
        _music = _convertBackendToAppFormat(backendMusic, 'music');
        print('✅ Loaded ${_music.length} music from backend');
      }

      // Load videos from backend
      final backendVideos = await ApiService.getVideos();
      if (backendVideos.isNotEmpty) {
        _videos = _convertBackendToAppFormat(backendVideos, 'video');
        print('✅ Loaded ${_videos.length} videos from backend');
      }

    } catch (e) {
      print('❌ Error loading content from backend: $e');
      // Continue to local content loading
    }
  }

  List<Map<String, dynamic>> _convertBackendToAppFormat(List<dynamic> backendData, String category) {
    return backendData.map((item) {
      // Handle both backend format and demo data format
      final isDemoData = item['source'] == 'demo_data';

      return {
        'id': item['_id'] ?? item['id'] ?? '${category}_${DateTime.now().millisecondsSinceEpoch}',
        'title': item['title'] ?? 'Untitled',
        'description': item['description'] ?? 'No description available',
        'duration': item['duration'] ?? 'Unknown',
        'isPremium': item['isPremium'] ?? false,
        'category': category,
        'thumbnail': item['thumbnail'] ?? _getDefaultThumbnail(category),
        'file': item['file'] ?? item['audioUrl'] ?? '',
        'videoUrl': item['videoUrl'] ?? item['url'] ?? '',
        'source': isDemoData ? 'demo' : 'backend',

        // Additional fields based on category
        if (category == 'meditation') ...{
          'instructor': item['instructor'] ?? item['author'] ?? 'Unknown Instructor',
        },
        if (category == 'story') ...{
          'narrator': item['narrator'] ?? item['author'] ?? 'Unknown Narrator',
        },
        if (category == 'music') ...{
          'artist': item['artist'] ?? item['author'] ?? 'Unknown Artist',
        },
        if (category == 'video') ...{
          'isYouTube': (item['videoUrl']?.toString().contains('youtube') == true) ||
              (item['url']?.toString().contains('youtube') == true),
          'youtubeId': _extractYouTubeId(item['videoUrl'] ?? item['url']),
        },
      };
    }).toList();
  }

  String? _extractYouTubeId(String? url) {
    if (url == null) return null;
    try {
      final regex = RegExp(
        r'(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)',
        caseSensitive: false,
      );
      final match = regex.firstMatch(url);
      return match?.group(1);
    } catch (e) {
      return null;
    }
  }

  String _getDefaultThumbnail(String category) {
    switch (category) {
      case 'meditation':
        return 'assets/images/meditation_thumb.jpg';
      case 'story':
        return 'assets/images/stories_thumb.jpg';
      case 'music':
        return 'assets/images/music_thumb.jpg';
      case 'video':
        return 'assets/images/video_thumb.jpg';
      default:
        return 'assets/images/default_thumb.jpg';
    }
  }

  void _loadLocalContent() {
    print('🔄 Loading local content...');
    _loadLocalMeditations();
    _loadLocalStories();
    _loadLocalMusic();
    _loadLocalVideos();
  }

  // ========== AFFIRMATIONS MANAGEMENT ==========

  void _loadAffirmations() {
    _affirmations = List.generate(365, (index) => {
      'id': 'affirmation_${index + 1}',
      'text': _getAffirmationText(index + 1),
      'day': index + 1,
      'category': 'affirmation',
      'source': 'local',
    });

    // Set current affirmation based on day of year
    final today = DateTime.now();
    final dayOfYear = today.difference(DateTime(today.year, 1, 1)).inDays;
    _currentAffirmationIndex = dayOfYear % _affirmations.length;

    print('✅ Loaded ${_affirmations.length} affirmations (Today: ${_currentAffirmationIndex + 1})');
  }

  String _getAffirmationText(int day) {
    final affirmations = [
      'I am capable of amazing things today!',
      'My potential is limitless and I embrace new challenges.',
      'I radiate positivity and attract wonderful opportunities.',
      'Every day I grow stronger and more confident.',
      'I am worthy of love, success, and happiness.',
      'My mind is clear and my focus is sharp.',
      'I choose to see the good in every situation.',
      'I am grateful for all the blessings in my life.',
      'My energy attracts positive people and experiences.',
      'I trust the journey and believe in my path.',
      'Today I choose peace over worry and faith over fear.',
      'I am becoming the best version of myself every day.',
      'My dreams are valid and achievable.',
      'I release all negative thoughts and embrace positivity.',
      'I am strong, resilient, and capable of overcoming any challenge.',
      'I embrace change and welcome growth in my life.',
      'My heart is open to giving and receiving love.',
      'I am at peace with my past and excited for my future.',
      'I choose happiness and let go of what I cannot control.',
      'My presence brings calm and comfort to others.',
      'I am enough just as I am in this moment.',
      'Every challenge is an opportunity for growth.',
      'I attract abundance in all areas of my life.',
      'My intuition guides me to make the right decisions.',
      'I am surrounded by love and everything is fine.',
    ];
    return affirmations[(day - 1) % affirmations.length];
  }

  void nextAffirmation() {
    _currentAffirmationIndex = (_currentAffirmationIndex + 1) % _affirmations.length;
    notifyListeners();
  }

  void previousAffirmation() {
    _currentAffirmationIndex = (_currentAffirmationIndex - 1) % _affirmations.length;
    if (_currentAffirmationIndex < 0) _currentAffirmationIndex = _affirmations.length - 1;
    notifyListeners();
  }

  void setAffirmationByDay(int day) {
    _currentAffirmationIndex = (day - 1) % _affirmations.length;
    notifyListeners();
  }

  void setAffirmationByDate(DateTime date) {
    final dayOfYear = date.difference(DateTime(date.year, 1, 1)).inDays + 1;
    setAffirmationByDay(dayOfYear);
  }

  // ========== LOCAL CONTENT DATA ==========

  void _loadLocalMeditations() {
    if (_meditations.isNotEmpty) return;

    _meditations = [
      {
        'id': 'med_1',
        'title': 'Morning Calm Meditation',
        'description': 'Start your day with peace and clarity',
        'duration': '10 min',
        'instructor': 'Sarah Mindfulness',
        'isPremium': false,
        'category': 'meditation',
        'thumbnail': 'assets/images/meditation_thumb.jpg',
        'file': 'meditations/morning_calm.mp3',
        'source': 'local',
      },
      {
        'id': 'med_2',
        'title': 'Deep Relaxation',
        'description': 'Release tension and find deep peace',
        'duration': '20 min',
        'instructor': 'Michael Zen',
        'isPremium': true,
        'category': 'meditation',
        'thumbnail': 'assets/images/yoga_thumb.jpg',
        'file': 'meditations/deep_relaxation.mp3',
        'source': 'local',
      },
    ];
  }

  void _loadLocalStories() {
    if (_stories.isNotEmpty) return;

    _stories = [
      {
        'id': 'story_1',
        'title': 'The Peaceful Forest',
        'description': 'A calming journey through enchanted woods',
        'duration': '25 min',
        'narrator': 'Storyteller Jane',
        'isPremium': false,
        'category': 'story',
        'thumbnail': 'assets/images/stories_thumb.jpg',
        'file': 'stories/peaceful_forest.mp3',
        'source': 'local',
      },
    ];
  }

  void _loadLocalMusic() {
    if (_music.isNotEmpty) return;

    _music = [
      {
        'id': 'music_1',
        'title': 'Calm Piano Melodies',
        'description': 'Soothing piano for relaxation',
        'duration': '45 min',
        'artist': 'Piano Peace',
        'isPremium': false,
        'category': 'music',
        'thumbnail': 'assets/images/music_thumb.jpg',
        'file': 'music/calm_piano.mp3',
        'source': 'local',
      },
    ];
  }

  void _loadLocalVideos() {
    if (_videos.isNotEmpty) return;

    _videos = [
      {
        'id': 'video_1',
        'title': 'Guided Sleep Meditation',
        'description': 'Visual journey to peaceful sleep',
        'duration': '15 min',
        'isPremium': false,
        'category': 'video',
        'thumbnail': 'assets/images/meditation_thumb.jpg',
        'videoUrl': 'https://www.youtube.com/watch?v=inpok4MKVLM',
        'isYouTube': true,
        'youtubeId': 'inpok4MKVLM',
        'source': 'local',
      },
    ];
  }

  // ========== CONTENT FILTERING & SEARCH ==========

  List<Map<String, dynamic>> getContentByCategory(String category) {
    switch (category) {
      case 'meditation':
        return _meditations;
      case 'story':
        return _stories;
      case 'music':
        return _music;
      case 'video':
        return _videos;
      case 'affirmation':
        return _affirmations;
      default:
        return [];
    }
  }

  List<Map<String, dynamic>> getPremiumContent() {
    return [
      ..._meditations.where((item) => item['isPremium'] == true),
      ..._stories.where((item) => item['isPremium'] == true),
      ..._music.where((item) => item['isPremium'] == true),
      ..._videos.where((item) => item['isPremium'] == true),
    ];
  }

  List<Map<String, dynamic>> getFreeContent() {
    return [
      ..._meditations.where((item) => item['isPremium'] == false),
      ..._stories.where((item) => item['isPremium'] == false),
      ..._music.where((item) => item['isPremium'] == false),
      ..._videos.where((item) => item['isPremium'] == false),
    ];
  }

  List<Map<String, dynamic>> searchContent(String query) {
    if (query.isEmpty) return [];

    final searchTerm = query.toLowerCase();
    final allContent = [..._meditations, ..._stories, ..._music, ..._videos];

    return allContent.where((item) {
      return (item['title']?.toString().toLowerCase().contains(searchTerm) == true) ||
          (item['description']?.toString().toLowerCase().contains(searchTerm) == true) ||
          (item['instructor']?.toString().toLowerCase().contains(searchTerm) == true) ||
          (item['narrator']?.toString().toLowerCase().contains(searchTerm) == true) ||
          (item['artist']?.toString().toLowerCase().contains(searchTerm) == true);
    }).toList();
  }

  List<Map<String, dynamic>> getYouTubeVideos() {
    return _videos.where((video) => video['isYouTube'] == true).toList();
  }

  // ========== CONTENT MANAGEMENT ==========

  Map<String, dynamic>? getContentById(String id) {
    final allContent = [..._meditations, ..._stories, ..._music, ..._videos, ..._affirmations];
    try {
      return allContent.firstWhere((item) => item['id'] == id);
    } catch (e) {
      return null;
    }
  }

  // ========== UTILITY METHODS ==========

  Future<void> refreshContent() async {
    await _loadAllContent();
  }

  Future<void> syncWithBackend() async {
    await _loadContentFromBackend();
    notifyListeners();
  }

  void setState(VoidCallback fn) {
    fn();
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  // Get featured content for homepage
  List<Map<String, dynamic>> getFeaturedContent() {
    final featured = [
      ..._meditations.where((item) => item['isPremium'] == false).take(2),
      ..._stories.where((item) => item['isPremium'] == false).take(2),
      ..._music.where((item) => item['isPremium'] == false).take(2),
      ..._videos.where((item) => item['isPremium'] == false).take(2),
    ];

    featured.shuffle();
    return featured.take(6).toList();
  }

  // Get content statistics
  Map<String, int> getContentStats() {
    return {
      'meditations': _meditations.length,
      'stories': _stories.length,
      'music': _music.length,
      'videos': _videos.length,
      'affirmations': _affirmations.length,
      'premium': getPremiumContent().length,
      'free': getFreeContent().length,
    };
  }
}