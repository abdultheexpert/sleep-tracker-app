import 'package:flutter/foundation.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:async';
import '../services/api_service.dart';

class SoundMixerProvider with ChangeNotifier {
  final AudioPlayer _audioPlayer = AudioPlayer();
  List<Map<String, dynamic>> _availableSounds = [];
  List<Map<String, dynamic>> _activeSounds = [];
  List<Map<String, dynamic>> _favoriteMixes = [];
  bool _isPlaying = false;
  bool _isLoading = false;
  Map<String, double> _soundVolumes = {};
  double _masterVolume = 0.5;
  Timer? _playbackTimer;

  // Getters
  List<Map<String, dynamic>> get availableSounds => _availableSounds;
  List<Map<String, dynamic>> get activeSounds => _activeSounds;
  List<Map<String, dynamic>> get favoriteMixes => _favoriteMixes;
  bool get isPlaying => _isPlaying;
  bool get isLoading => _isLoading;
  double get masterVolume => _masterVolume;

  SoundMixerProvider() {
    _setupAudioPlayer();
    _loadSounds();
  }

  // ========== INITIALIZATION ==========

  void _setupAudioPlayer() {
    _audioPlayer.onPlayerStateChanged.listen((PlayerState state) {
      _isPlaying = state == PlayerState.playing;
      notifyListeners();
    });

    _audioPlayer.onPlayerComplete.listen((event) {
      // Auto-loop for continuous playback
      if (_isPlaying && _activeSounds.isNotEmpty) {
        _playMixedSounds();
      }
    });

    _audioPlayer.onLog.listen((log) {
      if (kDebugMode) {
        print('Audio Player Log: $log');
      }
    });
  }

  Future<void> _loadSounds() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Try to load from backend first
      final backendSounds = await ApiService.getSounds();

      if (backendSounds.isNotEmpty) {
        // Convert backend format to app format
        _availableSounds = backendSounds.map((sound) => {
          'id': sound['_id'] ?? sound['id'],
          'name': sound['name'] ?? 'Unknown Sound',
          'icon': _getIconForCategory(sound['category'] ?? 'Noise'),
          'file': sound['file'] ?? '',
          'category': sound['category'] ?? 'Noise',
          'isFavorite': sound['isFavorite'] ?? false,
          'isPremium': sound['isPremium'] ?? false,
          'source': 'backend'
        }).toList();
      } else {
        // Fallback to local sounds
        _loadAllRealSounds();
      }

      // Initialize volumes for all sounds
      for (var sound in _availableSounds) {
        _soundVolumes[sound['id']] = 0.5;
      }

      print('✅ Loaded ${_availableSounds.length} sounds');

    } catch (e) {
      print('❌ Error loading sounds from backend: $e');
      _loadAllRealSounds();
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // ========== SOUND MANAGEMENT ==========

  void toggleSound(Map<String, dynamic> sound) {
    if (_activeSounds.contains(sound)) {
      _activeSounds.remove(sound);
      _stopIndividualSound(sound['id']);
    } else if (_activeSounds.length < 7) {
      _activeSounds.add(sound);
      if (_isPlaying) {
        _playMixedSounds();
      }
    }
    notifyListeners();
  }

  void toggleFavorite(String soundId) async {
    final soundIndex = _availableSounds.indexWhere((s) => s['id'] == soundId);
    if (soundIndex != -1) {
      final newFavoriteState = !_availableSounds[soundIndex]['isFavorite'];
      _availableSounds[soundIndex]['isFavorite'] = newFavoriteState;

      // Sync with backend if available
      try {
        // You would call an API endpoint to update favorite status
        // await ApiService.updateSoundFavorite(soundId, newFavoriteState);
      } catch (e) {
        print('❌ Error syncing favorite status: $e');
      }

      notifyListeners();
    }
  }

  // ========== PLAYBACK CONTROL ==========

  Future<void> togglePlayback() async {
    if (_isPlaying) {
      await _stopSoundPlayback();
    } else {
      if (_activeSounds.isNotEmpty) {
        await _playMixedSounds();
      }
    }
  }

  Future<void> _playMixedSounds() async {
    if (_activeSounds.isEmpty) return;

    try {
      // For production, you'd use a proper audio mixing solution
      // This is a simplified version that plays the first sound
      final firstSound = _activeSounds.first;
      final volume = (_soundVolumes[firstSound['id']] ?? 0.5) * _masterVolume;

      // Use AssetSource for local files
      await _audioPlayer.play(
        AssetSource(firstSound['file']),
        volume: volume,
      );

      _isPlaying = true;

      // Set up looping timer for continuous playback
      _setupPlaybackTimer();

      print('🎵 Playing sound: ${firstSound['name']}');

    } catch (e) {
      print('❌ Error playing sound: $e');
      _isPlaying = false;
    }
    notifyListeners();
  }

  void _setupPlaybackTimer() {
    _playbackTimer?.cancel();
    _playbackTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (_isPlaying && _activeSounds.isNotEmpty) {
        _playMixedSounds(); // Restart playback for looping
      }
    });
  }

  Future<void> _stopIndividualSound(String soundId) async {
    // In a real implementation with multiple players,
    // you'd stop the specific sound player
    if (_activeSounds.isEmpty) {
      await _stopSoundPlayback();
    }
  }

  Future<void> _stopSoundPlayback() async {
    _playbackTimer?.cancel();
    _playbackTimer = null;

    await _audioPlayer.stop();
    _isPlaying = false;
    print('⏹️ Playback stopped');
    notifyListeners();
  }

  // ========== VOLUME CONTROL ==========

  void setVolume(String soundId, double volume) {
    _soundVolumes[soundId] = volume.clamp(0.0, 1.0);

    // In a real implementation, you'd update the specific sound's volume
    if (_isPlaying) {
      _updatePlaybackVolume();
    }
    notifyListeners();
  }

  void setMasterVolume(double volume) {
    _masterVolume = volume.clamp(0.0, 1.0);

    if (_isPlaying) {
      _updatePlaybackVolume();
    }
    notifyListeners();
  }

  void _updatePlaybackVolume() {
    if (_activeSounds.isNotEmpty) {
      final firstSound = _activeSounds.first;
      final volume = (_soundVolumes[firstSound['id']] ?? 0.5) * _masterVolume;
      _audioPlayer.setVolume(volume);
    }
  }

  double getVolume(String soundId) {
    return _soundVolumes[soundId] ?? 0.5;
  }

  // ========== MIX MANAGEMENT ==========

  void saveCurrentMix(String mixName) {
    if (_activeSounds.isEmpty) return;

    final newMix = {
      'id': 'mix_${DateTime.now().millisecondsSinceEpoch}',
      'name': mixName,
      'sounds': List<Map<String, dynamic>>.from(_activeSounds),
      'volumes': Map<String, double>.from(_soundVolumes),
      'masterVolume': _masterVolume,
      'createdAt': DateTime.now(),
      'soundCount': _activeSounds.length,
    };

    _favoriteMixes.insert(0, newMix); // Add to beginning for recent first

    // Sync with backend if available
    _syncMixToBackend(newMix);

    print('💾 Saved mix: $mixName with ${_activeSounds.length} sounds');
    notifyListeners();
  }

  Future<void> _syncMixToBackend(Map<String, dynamic> mix) async {
    try {
      // You would call an API endpoint to save the mix
      // await ApiService.saveSoundMix(mix);
    } catch (e) {
      print('❌ Error syncing mix to backend: $e');
    }
  }

  void loadMix(int index) {
    if (index < _favoriteMixes.length) {
      final mix = _favoriteMixes[index];
      _activeSounds = List<Map<String, dynamic>>.from(mix['sounds']);
      _soundVolumes = Map<String, double>.from(mix['volumes']);
      _masterVolume = mix['masterVolume'] ?? 0.5;

      // Restart playback if it was playing
      if (_isPlaying) {
        _playMixedSounds();
      }

      print('📥 Loaded mix: ${mix['name']}');
      notifyListeners();
    }
  }

  void deleteMix(int index) {
    if (index < _favoriteMixes.length) {
      final mixId = _favoriteMixes[index]['id'];
      _favoriteMixes.removeAt(index);

      // Sync deletion with backend
      _deleteMixFromBackend(mixId);

      print('🗑️ Deleted mix at index: $index');
      notifyListeners();
    }
  }

  Future<void> _deleteMixFromBackend(String mixId) async {
    try {
      // You would call an API endpoint to delete the mix
      // await ApiService.deleteSoundMix(mixId);
    } catch (e) {
      print('❌ Error deleting mix from backend: $e');
    }
  }

  void clearAllSounds() {
    _activeSounds.clear();
    _stopSoundPlayback();
    print('🧹 Cleared all active sounds');
    notifyListeners();
  }

  // ========== SOUND FILTERING & CATEGORIZATION ==========

  List<Map<String, dynamic>> getSoundsByCategory(String category) {
    if (category == 'All') return _availableSounds;
    if (category == 'Favorites') return getFavoriteSounds();
    return _availableSounds.where((sound) => sound['category'] == category).toList();
  }

  List<Map<String, dynamic>> getFavoriteSounds() {
    return _availableSounds.where((sound) => sound['isFavorite'] == true).toList();
  }

  List<String> getCategories() {
    final categories = _availableSounds.map((sound) => sound['category'] as String).toSet().toList();
    categories.sort();
    categories.insert(0, 'All');
    if (getFavoriteSounds().isNotEmpty) {
      categories.add('Favorites');
    }
    return categories;
  }

  // ========== ANALYTICS & STATISTICS ==========

  Map<String, int> getActiveSoundsByCategory() {
    Map<String, int> categoryCounts = {};
    for (var sound in _activeSounds) {
      final category = sound['category'];
      categoryCounts[category] = (categoryCounts[category] ?? 0) + 1;
    }
    return categoryCounts;
  }

  bool isSoundActive(String soundId) {
    return _activeSounds.any((sound) => sound['id'] == soundId);
  }

  int getTotalSounds() => _availableSounds.length;
  int getFavoriteSoundsCount() => getFavoriteSounds().length;
  int getSoundsInCategory(String category) => getSoundsByCategory(category).length;

  // ========== UTILITY METHODS ==========

  String _getIconForCategory(String category) {
    final icons = {
      'Noise': '🎵',
      'Birds': '🐦',
      'Forest': '🌲',
      'Nature': '🌿',
      'Rain': '🌧️',
      'River': '🌊',
      'Sleep': '😴',
      'Thunder': '⚡',
      'Wind': '💨',
    };
    return icons[category] ?? '🎵';
  }

  // Performance optimization
  void preloadSounds(List<String> soundIds) {
    // Preload frequently used sounds for better performance
    for (var soundId in soundIds) {
      final sound = _availableSounds.firstWhere((s) => s['id'] == soundId, orElse: () => {});
      if (sound.isNotEmpty) {
        // In a real implementation, you'd preload the audio file
      }
    }
  }

  void setState(VoidCallback fn) {
    fn();
    notifyListeners();
  }

  Future<void> refreshSounds() async {
    await _loadSounds();
  }

  // Get sound statistics for dashboard
  Map<String, dynamic> getSoundStats() {
    return {
      'totalSounds': _availableSounds.length,
      'activeSounds': _activeSounds.length,
      'favoriteSounds': getFavoriteSounds().length,
      'savedMixes': _favoriteMixes.length,
      'categories': getCategories().length,
      'soundsByCategory': _getSoundsCountByCategory(),
    };
  }

  Map<String, int> _getSoundsCountByCategory() {
    Map<String, int> counts = {};
    for (var sound in _availableSounds) {
      final category = sound['category'];
      counts[category] = (counts[category] ?? 0) + 1;
    }
    return counts;
  }

  // Search functionality
  List<Map<String, dynamic>> searchSounds(String query) {
    if (query.isEmpty) return [];

    final searchTerm = query.toLowerCase();
    return _availableSounds.where((sound) {
      return sound['name'].toString().toLowerCase().contains(searchTerm) ||
          sound['category'].toString().toLowerCase().contains(searchTerm);
    }).toList();
  }

  // Get popular sounds (most used in mixes)
  List<Map<String, dynamic>> getPopularSounds() {
    // Simple implementation - return sounds from active mixes
    final soundUsage = <String, int>{};

    for (var mix in _favoriteMixes) {
      for (var sound in mix['sounds']) {
        final soundId = sound['id'];
        soundUsage[soundId] = (soundUsage[soundId] ?? 0) + 1;
      }
    }

    // Sort by usage count
    final sortedSoundIds = soundUsage.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return sortedSoundIds.take(10).map((entry) {
      return _availableSounds.firstWhere((s) => s['id'] == entry.key);
    }).toList();
  }

  @override
  void dispose() {
    _playbackTimer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  // ========== SOUNDS DATA - EMPTY FOR YOU TO MANAGE ==========
  void _loadAllRealSounds() {
    _availableSounds = [
      // NOISE CATEGORY (150+ sounds)
      {'id': '1', 'name': 'Xylophone Tip Toe', 'icon': '🎵', 'file': 'sounds/noise/Xylophone Tip Toe Scale Up.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '2', 'name': 'Woodpecker Fast', 'icon': '🐦', 'file': 'sounds/noise/Woodpecker Pecking Fast.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '3', 'name': 'Woodpecker Fast 2', 'icon': '🐦', 'file': 'sounds/noise/Woodpecker Pecking Fast (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '4', 'name': 'Woodpecker Eating', 'icon': '🌳', 'file': 'sounds/noise/Woodpecker Eating Distant.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '5', 'name': 'Train Whistle', 'icon': '🚂', 'file': 'sounds/noise/Wooden Train Whistle.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '6', 'name': 'Bat Tapping', 'icon': '🏏', 'file': 'sounds/noise/Wooden Bat Tapping Home Plate.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '7', 'name': 'Wood Bat Hits', 'icon': '⚾', 'file': 'sounds/noise/Wooden Bat Hits.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '8', 'name': 'Baseball Bat Run', 'icon': '⚾', 'file': 'sounds/noise/Wooden Bat Hits Baseball Run.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '9', 'name': 'Bat Dropped', 'icon': '🏏', 'file': 'sounds/noise/Wooden Bat Dropped On Asphalt.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '10', 'name': 'Wood Hit Metal', 'icon': '🔨', 'file': 'sounds/noise/Wood Hit Metal Crash (2).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '11', 'name': 'Wood Hit Metal 2', 'icon': '🔨', 'file': 'sounds/noise/Wood Hit Metal Crash (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '12', 'name': 'Golf Club Hit', 'icon': '🏌️', 'file': 'sounds/noise/Wood Golf Club Hit Ball.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '13', 'name': 'Wood Door Close', 'icon': '🚪', 'file': 'sounds/noise/Wood Door Close and Rattle.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '14', 'name': 'Wood Chipper', 'icon': '🌲', 'file': 'sounds/noise/Wood Chipper.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '15', 'name': 'Wood Chipper 2', 'icon': '🌲', 'file': 'sounds/noise/Wood Chipper (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '16', 'name': 'Bowling Pins', 'icon': '🎳', 'file': 'sounds/noise/Wood Bowling Pin Drop Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '17', 'name': 'Bowling Pins 2', 'icon': '🎳', 'file': 'sounds/noise/Wood Bowling Pin Drop Series (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '18', 'name': 'Bat Falling', 'icon': '🏏', 'file': 'sounds/noise/Wood Bat Falling in Dirt.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '19', 'name': 'Wiping Sink', 'icon': '🧽', 'file': 'sounds/noise/Wiping Out Sink With Hand.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '20', 'name': 'Wiping Counter', 'icon': '🧽', 'file': 'sounds/noise/Wiping Off Counter.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '21', 'name': 'Wiping Counter 2', 'icon': '🧽', 'file': 'sounds/noise/Wiping Off Counter (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '22', 'name': 'Wineglass Wood', 'icon': '🍷', 'file': 'sounds/noise/Wineglass On Wood Soft.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '23', 'name': 'Wineglass Granite', 'icon': '🍷', 'file': 'sounds/noise/Wineglass On Granite Soft.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '24', 'name': 'Wine Glass Table', 'icon': '🍷', 'file': 'sounds/noise/Wine Glass Up Down on Table.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '25', 'name': 'Wine Glass Shatter', 'icon': '🍷', 'file': 'sounds/noise/Wine Glass Shatter.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '26', 'name': 'Windshield Hit', 'icon': '🚗', 'file': 'sounds/noise/Windshield Hit With Bar.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '27', 'name': 'Window Latch', 'icon': '🪟', 'file': 'sounds/noise/Window Latch Open Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '28', 'name': 'Window Close', 'icon': '🪟', 'file': 'sounds/noise/Window Close Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '29', 'name': 'Alarm Clock', 'icon': '⏰', 'file': 'sounds/noise/Winding Alarm Clock.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '30', 'name': 'Wind Chime', 'icon': '🎐', 'file': 'sounds/noise/Windchime Drone.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '31', 'name': 'Wind Up Toy', 'icon': '🤖', 'file': 'sounds/noise/Wind Up Toy.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '32', 'name': 'Wind Creaks', 'icon': '🌬️', 'file': 'sounds/noise/Wind Quiet Creaks.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '33', 'name': 'Pine Trees', 'icon': '🌲', 'file': 'sounds/noise/Wind In Pine Trees.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '34', 'name': 'Leaves Rustle', 'icon': '🍃', 'file': 'sounds/noise/Wind In Leaves On Porch.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '35', 'name': 'Fire Wind', 'icon': '🔥', 'file': 'sounds/noise/Wind Drawn Into Fire.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '36', 'name': 'Wet Towel', 'icon': '🧼', 'file': 'sounds/noise/Wet Towel Wring.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '37', 'name': 'Wet Tire', 'icon': '🚙', 'file': 'sounds/noise/Wet Tire Drive By.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '38', 'name': 'Wet Tearing Meat', 'icon': '🥩', 'file': 'sounds/noise/Wet Tearing Meat.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '39', 'name': 'Wet Squeak', 'icon': '🚿', 'file': 'sounds/noise/Wet Squeak Rub on Bathtub.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '40', 'name': 'Wet Shoes', 'icon': '👟', 'file': 'sounds/noise/Wet Shoes Walking Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '41', 'name': 'Wet Leg Cut', 'icon': '💧', 'file': 'sounds/noise/Wet Leg Cut Off.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '42', 'name': 'Wet Fart', 'icon': '💨', 'file': 'sounds/noise/Wet Fart.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '43', 'name': 'Waves Crashing', 'icon': '🌊', 'file': 'sounds/noise/Waves Crashing on Rock Beach.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '44', 'name': 'Water Walk', 'icon': '💧', 'file': 'sounds/noise/Water Walk Series Sweetener .mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '45', 'name': 'Water Spray', 'icon': '🚿', 'file': 'sounds/noise/Water Spray On Body Steady Stream.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '46', 'name': 'Water Splashes', 'icon': '💦', 'file': 'sounds/noise/Water Splashes Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '47', 'name': 'Water Splash Cement', 'icon': '🏗️', 'file': 'sounds/noise/Water Splash on Cement Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '48', 'name': 'Water Sizzle', 'icon': '🍳', 'file': 'sounds/noise/Water Sizzle.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '49', 'name': 'Water Running', 'icon': '💧', 'file': 'sounds/noise/Water Running By.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '50', 'name': 'Water Pour Tray', 'icon': '🏥', 'file': 'sounds/noise/Water Pour Into Surgical Tray.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '51', 'name': 'Water Pour Sink', 'icon': '🚰', 'file': 'sounds/noise/Water Pour Into Half Full Sink.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '52', 'name': 'Water on Metal', 'icon': '🔩', 'file': 'sounds/noise/Water on Metal Surface.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '53', 'name': 'Water in Bath', 'icon': '🛁', 'file': 'sounds/noise/Water Movement In Bath.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '54', 'name': 'Water Leak', 'icon': '💧', 'file': 'sounds/noise/Water Leak.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '55', 'name': 'Water Lapping', 'icon': '🌊', 'file': 'sounds/noise/Water Lapping Wind.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '56', 'name': 'Water Lapping 2', 'icon': '🌊', 'file': 'sounds/noise/Water Lapping Wind (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '57', 'name': 'Water Hose', 'icon': '🚿', 'file': 'sounds/noise/Water Hose on Concrete.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '58', 'name': 'Water Hose 2', 'icon': '🚿', 'file': 'sounds/noise/Water Hose on Concrete (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '59', 'name': 'Water Drains', 'icon': '🚰', 'file': 'sounds/noise/Water Drains In Pipe.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '60', 'name': 'Water Drains Pump', 'icon': '🚰', 'file': 'sounds/noise/Water Drains In Pipe with Pump.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '61', 'name': 'Water Can Fall', 'icon': '💧', 'file': 'sounds/noise/Water Can Fall.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '62', 'name': 'Wasp Window', 'icon': '🐝', 'file': 'sounds/noise/Wasp On Window.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '63', 'name': 'Washing Machine', 'icon': '🧼', 'file': 'sounds/noise/Washing Machine Door.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '64', 'name': 'Wash Hands', 'icon': '🚰', 'file': 'sounds/noise/Wash Hands Running Water.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '65', 'name': 'Wall Switch Medium', 'icon': '💡', 'file': 'sounds/noise/Wall Light Switch Medium.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '66', 'name': 'Wall Switch Close', 'icon': '💡', 'file': 'sounds/noise/Wall Light Switch Close.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '67', 'name': 'Walking Wood Floor', 'icon': '🚶', 'file': 'sounds/noise/Walking Wood Floor House.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '68', 'name': 'Walking Wood Floor 2', 'icon': '🚶', 'file': 'sounds/noise/Walking Wood Floor House (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '69', 'name': 'Walking Metal', 'icon': '👣', 'file': 'sounds/noise/Walking on Hollow Metal.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '70', 'name': 'Walking Forest', 'icon': '🌲', 'file': 'sounds/noise/Walking In Forest.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '71', 'name': 'Walk on Snow', 'icon': '❄️', 'file': 'sounds/noise/Walk on Snow Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '72', 'name': 'Walk on Rocks', 'icon': '🪨', 'file': 'sounds/noise/Walk on Rocks.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '73', 'name': 'Walk Muddy Gravel', 'icon': '👣', 'file': 'sounds/noise/Walk on Muddy Gravel Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '74', 'name': 'Walk Shallow Water', 'icon': '💧', 'file': 'sounds/noise/Walk in Shallow Water Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '75', 'name': 'Walk Fast Wood', 'icon': '🚶', 'file': 'sounds/noise/Walk Fast on Hollow Wood Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '76', 'name': 'Walk Fast Gravel', 'icon': '🏃', 'file': 'sounds/noise/Walk Fast on Gravel Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '77', 'name': 'Walk Fast Concrete', 'icon': '🏃', 'file': 'sounds/noise/Walk Fast on Concrete Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '78', 'name': 'Vulcan Gun', 'icon': '🔫', 'file': 'sounds/noise/Vulcan Machine Gun Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '79', 'name': 'Vomiting Close', 'icon': '🤢', 'file': 'sounds/noise/Vomiting Close.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '80', 'name': 'Vomit Bathroom', 'icon': '🚽', 'file': 'sounds/noise/Vomit in Bathroom.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '81', 'name': 'Volleyball Spikes', 'icon': '🏐', 'file': 'sounds/noise/Volleyball Spikes.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '82', 'name': 'Volleyball Slap', 'icon': '🏐', 'file': 'sounds/noise/Volleyball Slap on Ball.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '83', 'name': 'Volleyball Bounce', 'icon': '🏐', 'file': 'sounds/noise/Volleyball Ball Slow Bounce.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '84', 'name': 'Vibrate Wood', 'icon': '📳', 'file': 'sounds/noise/Vibrate on Wood.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '85', 'name': 'Vegetables Mixing', 'icon': '🥗', 'file': 'sounds/noise/Vegetables Mixing in Metal Bowl.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '86', 'name': 'Vegetables Counter', 'icon': '🥦', 'file': 'sounds/noise/Vegetables Down on Counter Series (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '87', 'name': 'Unloading Gun Singles', 'icon': '🔫', 'file': 'sounds/noise/Unloading Gun Magazine Singles.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '88', 'name': 'Unloading Gun Series', 'icon': '🔫', 'file': 'sounds/noise/Unloading Gun Magazine Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '89', 'name': 'UFO Zip', 'icon': '👽', 'file': 'sounds/noise/UFO Zip Whistle.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '90', 'name': 'Twist Break Spine', 'icon': '🦴', 'file': 'sounds/noise/Twist And Break Spine.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '91', 'name': 'Twig Snap', 'icon': '🌿', 'file': 'sounds/noise/Twig Snap Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '92', 'name': 'Tweeter Static', 'icon': '📢', 'file': 'sounds/noise/Tweeter Electric Static.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '93', 'name': 'Truck Parking', 'icon': '🚚', 'file': 'sounds/noise/Truck Driving in Parking Structure.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '94', 'name': 'Truck Parking 2', 'icon': '🚚', 'file': 'sounds/noise/Truck Driving in Parking Structure (2).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '95', 'name': 'Truck Parking 3', 'icon': '🚚', 'file': 'sounds/noise/Truck Driving in Parking Structure (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '96', 'name': 'Trampoline Jumps', 'icon': '🤸', 'file': 'sounds/noise/Trampoline Jumps.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '97', 'name': 'Tossing Wood', 'icon': '🪵', 'file': 'sounds/noise/Tossing Wood Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '98', 'name': 'Toilet Seat', 'icon': '🚽', 'file': 'sounds/noise/Toliet Seat Closing Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '99', 'name': 'Toilet Flush Close', 'icon': '🚽', 'file': 'sounds/noise/Toliet Flush Very Close.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '100', 'name': 'Toilet Flush Far', 'icon': '🚽', 'file': 'sounds/noise/Toliet Flush Far.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '101', 'name': 'Toilet Flush', 'icon': '🚽', 'file': 'sounds/noise/Toliet Flush .mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '102', 'name': 'Toilet Closed Door', 'icon': '🚪', 'file': 'sounds/noise/Toilet Flush Through Closed Door.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '103', 'name': 'Toilet Small Bathroom', 'icon': '🚽', 'file': 'sounds/noise/Toilet Flush Small Bathroom.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '104', 'name': 'Tentacle Flop', 'icon': '🐙', 'file': 'sounds/noise/Tentacle Flop Down.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '105', 'name': 'Tennis Racket Hit', 'icon': '🎾', 'file': 'sounds/noise/Tennis Racket Hit Low.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '106', 'name': 'Tennis Ball Bounce', 'icon': '🎾', 'file': 'sounds/noise/Tennis Ball Bouncing on Pavement.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '107', 'name': 'Straw Squeak', 'icon': '🥤', 'file': 'sounds/noise/Straw Squeak.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '108', 'name': 'Straw Squeak 2', 'icon': '🥤', 'file': 'sounds/noise/Straw Squeak (2).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '109', 'name': 'Straw Squeak 3', 'icon': '🥤', 'file': 'sounds/noise/Straw Squeak (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '110', 'name': 'Stones Water Cement', 'icon': '🪨', 'file': 'sounds/noise/Stones and Water On Cement.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '111', 'name': 'Start Motor Away', 'icon': '🚗', 'file': 'sounds/noise/Start Motor Drive Away.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '112', 'name': 'Start Motor Away 2', 'icon': '🚗', 'file': 'sounds/noise/Start Motor Drive Away (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '113', 'name': 'Splashing Water', 'icon': '💦', 'file': 'sounds/noise/Splashing Water.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '114', 'name': 'Splashing Water Fast', 'icon': '💦', 'file': 'sounds/noise/Splashing Water Fast.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '115', 'name': 'Sneaker Metal Grate', 'icon': '👟', 'file': 'sounds/noise/Sneaker on Metal Grate Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '116', 'name': 'Sneaker Grass Slow', 'icon': '👟', 'file': 'sounds/noise/Sneaker on Grass Series Slow.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '117', 'name': 'Sneaker Grass Fast', 'icon': '👟', 'file': 'sounds/noise/Sneaker on Grass Series Fast.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '118', 'name': 'Sneaker Dirt Slow', 'icon': '👟', 'file': 'sounds/noise/Sneaker on Dirt Series Slow.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '119', 'name': 'Sneaker Concrete Slow', 'icon': '👟', 'file': 'sounds/noise/Sneaker on Concrete Series Slow.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '120', 'name': 'Sneaker Shallow Water', 'icon': '👟', 'file': 'sounds/noise/Sneaker in Shallow Water Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '121', 'name': 'Sneaker Soggy Grass', 'icon': '👟', 'file': 'sounds/noise/Sneaker in  Soggy Grass Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '122', 'name': 'Sneaker Fast Wood', 'icon': '👟', 'file': 'sounds/noise/Sneaker Fast Walk Solid Wood.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '123', 'name': 'Shoveling Snow', 'icon': '🪣', 'file': 'sounds/noise/Shoveling Snow.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '124', 'name': 'Sheet Woosh', 'icon': '🛏️', 'file': 'sounds/noise/Sheet Woosh Thin.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '125', 'name': 'Ratcheting Wench', 'icon': '🔧', 'file': 'sounds/noise/Ratcheting Trailer Wench.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '126', 'name': 'Radiation Suit Rustle', 'icon': '🥼', 'file': 'sounds/noise/Radiation Suit Rustle.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '127', 'name': 'Radiation Suit On Off', 'icon': '🥼', 'file': 'sounds/noise/Radiation Suit On Off.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '128', 'name': 'Out of Shower', 'icon': '🚿', 'file': 'sounds/noise/Out of Shower Curtain Pull Towel Use.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '129', 'name': 'Opening Plastic Container', 'icon': '📦', 'file': 'sounds/noise/Opening Plastic Storage Container .mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '130', 'name': 'Open Close Window', 'icon': '🪟', 'file': 'sounds/noise/Open and Close Window.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '131', 'name': 'Muscle Car Alleyway', 'icon': '🚗', 'file': 'sounds/noise/Muscle Car Start Up Alleyway.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '132', 'name': 'Muscle Car Rev Idle', 'icon': '🏎️', 'file': 'sounds/noise/Muscle Car Start Rev and Idle.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '133', 'name': 'Muscle Car Idle Stall', 'icon': '🏎️', 'file': 'sounds/noise/Muscle Car Start Idle and Stall.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '134', 'name': 'Muscle Car Drive Away', 'icon': '🏎️', 'file': 'sounds/noise/Muscle Car Start and Drive Away.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '135', 'name': 'Muscle Car Highway', 'icon': '🏎️', 'file': 'sounds/noise/Muscle Car Speeding Highway.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '136', 'name': 'Muscle Car Skid Out', 'icon': '🏎️', 'file': 'sounds/noise/Muscle Car Driving Skid Out.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '137', 'name': 'Muscle Car Rev Short', 'icon': '🏎️', 'file': 'sounds/noise/Muscle Car Distant Rev Short.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '138', 'name': 'Lake Wind Ambience', 'icon': '🌊', 'file': 'sounds/noise/Lake Wind Ambience.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '139', 'name': 'Kids Playing', 'icon': '👦', 'file': 'sounds/noise/Kids Playing.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '140', 'name': 'Keyboard Typing', 'icon': '⌨️', 'file': 'sounds/noise/Keyboard Typing Fast Far.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '141', 'name': 'Household Drill', 'icon': '🛠️', 'file': 'sounds/noise/Household Drill .mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '142', 'name': 'Highway Waterfront', 'icon': '🛣️', 'file': 'sounds/noise/Highway Near Waterfront Distant.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '143', 'name': 'Highway Waterfront 2', 'icon': '🛣️', 'file': 'sounds/noise/Highway Near Waterfront Distant (3).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '144', 'name': 'Highway Waterfront 3', 'icon': '🛣️', 'file': 'sounds/noise/Highway Near Waterfront Distant (2).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '145', 'name': 'Highway Waterfront 4', 'icon': '🛣️', 'file': 'sounds/noise/Highway Near Waterfront Distant (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '146', 'name': 'High Heels Walking', 'icon': '👠', 'file': 'sounds/noise/High Heels Walking Series.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '147', 'name': 'Hands Touching Sink', 'icon': '🚰', 'file': 'sounds/noise/Hands Touching Sink .mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '148', 'name': 'Dumpster Door Slam', 'icon': '🗑️', 'file': 'sounds/noise/Dumpster Door Slam.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '149', 'name': 'Dumpster Door Slam 2', 'icon': '🗑️', 'file': 'sounds/noise/Dumpster Door Slam (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '150', 'name': 'Dry Off Towel', 'icon': '🧖', 'file': 'sounds/noise/Dry Off with Towel.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '151', 'name': 'Daytime Bonfire', 'icon': '🔥', 'file': 'sounds/noise/Daytime Forrest Bonfire.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '152', 'name': 'Daytime Bonfire 2', 'icon': '🔥', 'file': 'sounds/noise/Daytime Forrest Bonfire (3).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '153', 'name': 'Daytime Bonfire 3', 'icon': '🔥', 'file': 'sounds/noise/Daytime Forrest Bonfire (2).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '154', 'name': 'Daytime Bonfire 4', 'icon': '🔥', 'file': 'sounds/noise/Daytime Forrest Bonfire (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '155', 'name': 'Clean Up Spill', 'icon': '🧹', 'file': 'sounds/noise/Clean Up Spill.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '156', 'name': 'Child Toy Chime', 'icon': '🎪', 'file': 'sounds/noise/Child Toy Chime Clinck and Clanks.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '157', 'name': 'Cartoon Metal Thunk', 'icon': '📺', 'file': 'sounds/noise/Cartoon Metal Thunk.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '158', 'name': 'Car Horn Birds', 'icon': '🚗', 'file': 'sounds/noise/Car Horn Distant with Bird Chirp.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '159', 'name': 'Car Drive By', 'icon': '🚙', 'file': 'sounds/noise/Car Drive By.mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '160', 'name': 'Car Drive By 2', 'icon': '🚙', 'file': 'sounds/noise/Car Drive By (1).mp3', 'category': 'Noise', 'isFavorite': false},
      {'id': '161', 'name': 'Car Cruise Window', 'icon': '🚗', 'file': 'sounds/noise/Car Cruise Hand Out Window.mp3', 'category': 'Noise', 'isFavorite': false},

      // BIRDS CATEGORY
      {'id': '200', 'name': 'Thunder Birds', 'icon': '⛈️', 'file': 'sounds/birds/Thunder with Birds and Flies.mp3', 'category': 'Birds', 'isFavorite': false},
      {'id': '201', 'name': 'June Songbirds', 'icon': '🐦', 'file': 'sounds/birds/June Songbirds.mp3', 'category': 'Birds', 'isFavorite': false},
      {'id': '202', 'name': 'Songbirds Crows', 'icon': '🎵', 'file': 'sounds/birds/June Songbirds With Crows.mp3', 'category': 'Birds', 'isFavorite': false},

      // FOREST CATEGORY
      {'id': '300', 'name': 'Forest Walk', 'icon': '🚶', 'file': 'sounds/forest/Walking In Forest.mp3', 'category': 'Forest', 'isFavorite': false},
      {'id': '301', 'name': 'Summer Forest', 'icon': '🌞', 'file': 'sounds/forest/Summer Forest.mp3', 'category': 'Forest', 'isFavorite': false},
      {'id': '302', 'name': 'Spring Forest', 'icon': '🌸', 'file': 'sounds/forest/Spring Day Forest.mp3', 'category': 'Forest', 'isFavorite': false},
      {'id': '303', 'name': 'Forest Hiking', 'icon': '🥾', 'file': 'sounds/forest/Hiking in Forest.mp3', 'category': 'Forest', 'isFavorite': false},
      {'id': '304', 'name': 'Wood Snapping', 'icon': '🪵', 'file': 'sounds/forest/Forest Wood Snapping.mp3', 'category': 'Forest', 'isFavorite': false},
      {'id': '305', 'name': 'Forest Wind', 'icon': '💨', 'file': 'sounds/forest/Forest Wind Summer.mp3', 'category': 'Forest', 'isFavorite': false},
      {'id': '306', 'name': 'Forest Bonfire', 'icon': '🔥', 'file': 'sounds/forest/Daytime Forest Bonfire.mp3', 'category': 'Forest', 'isFavorite': false},
      {'id': '307', 'name': 'Forest Chopping', 'icon': '🪓', 'file': 'sounds/forest/Chopping in Forest.mp3', 'category': 'Forest', 'isFavorite': false},
      {'id': '308', 'name': 'Battle Forest', 'icon': '⚔️', 'file': 'sounds/forest/Battle Intimidation Forest.mp3', 'category': 'Forest', 'isFavorite': false},

      // NATURE CATEGORY
      {'id': '400', 'name': 'Train Whistle', 'icon': '🚂', 'file': 'sounds/nature/Wooden Train Whistle.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '401', 'name': 'Wind-Up Mountains', 'icon': '🏔️', 'file': 'sounds/nature/Wind-Up Mountains - Schwartzy.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '402', 'name': 'Wellspring', 'icon': '💧', 'file': 'sounds/nature/wellspring - Lish Grooves.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '403', 'name': 'Water Drains', 'icon': '🚰', 'file': 'sounds/nature/Water Drains In Pipe.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '404', 'name': 'Walking Dog', 'icon': '🐕', 'file': 'sounds/nature/Walking The Dog - Jeremy Korpas.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '405', 'name': 'Treasure Hunt', 'icon': '🗺️', 'file': 'sounds/nature/Treasure Hunt - Jeremy Korpas.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '406', 'name': 'Color of Barrel', 'icon': '🎨', 'file': 'sounds/nature/The Color of the Barrel - Nathan Moore.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '407', 'name': 'Sunrise Moonbeam', 'icon': '🌅', 'file': 'sounds/nature/Sunrise From a Moonbeam - Dan _Lebo_ Lebowitz, Tone Seeker.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '408', 'name': 'Spaghettification', 'icon': '🌀', 'file': 'sounds/nature/Spaghettification - The Grey Room _ Density & Time.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '409', 'name': 'Sleep Music', 'icon': '🎵', 'file': 'sounds/nature/Sleep Music No. 1 - Chris Haugen.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '410', 'name': 'Seasons', 'icon': '🍂', 'file': 'sounds/nature/Seasons - Telecasted.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '411', 'name': 'Sailing', 'icon': '⛵', 'file': 'sounds/nature/Sailing - Telecasted.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '412', 'name': 'Rooster', 'icon': '🐓', 'file': 'sounds/nature/Rooster - Telecasted.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '413', 'name': 'Rapid Disassembly', 'icon': '⚙️', 'file': 'sounds/nature/Rapid Unscheduled Disassembly - The Grey Room _ Density & Time.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '414', 'name': 'Nineties Pad', 'icon': '🎹', 'file': 'sounds/nature/Nineties Pad - Brian Bolger.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '415', 'name': 'Nebula', 'icon': '🌌', 'file': 'sounds/nature/Nebula - The Grey Room _ Density & Time.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '416', 'name': 'Nature Nurture', 'icon': '🌱', 'file': 'sounds/nature/Nature Nurture - Quincas Moreira.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '417', 'name': 'My First True Love', 'icon': '💝', 'file': 'sounds/nature/My First True Love - Jeremy Korpas.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '418', 'name': 'Lets Keep Trying', 'icon': '💪', 'file': 'sounds/nature/Let_s Keep Trying - Jeremy Korpas.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '419', 'name': 'Lets Do This', 'icon': '🎵', 'file': 'sounds/nature/Let_s Do This! - Nat Keefe & Hot Buttered Rum.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '420', 'name': 'Koto San', 'icon': '🎶', 'file': 'sounds/nature/Koto San - Ofshane.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '421', 'name': 'Jomon Grove', 'icon': '🌳', 'file': 'sounds/nature/Jomon Grove - The Mini Vandals.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '422', 'name': 'I Wuv U', 'icon': '💖', 'file': 'sounds/nature/I Wuv U - Jeremy Korpas.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '423', 'name': 'Guitar House', 'icon': '🎸', 'file': 'sounds/nature/Guitar House - josh pan.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '424', 'name': 'Good for Ghost', 'icon': '👻', 'file': 'sounds/nature/good for the ghost - Alge.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '425', 'name': 'Gold Crawfish', 'icon': '🦞', 'file': 'sounds/nature/Gold and Crawfish - Density & Time.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '426', 'name': 'Fruits of Life', 'icon': '🍎', 'file': 'sounds/nature/Fruits of Life - Jimena Contreras.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '427', 'name': 'From Here on In', 'icon': '🎵', 'file': 'sounds/nature/From Here on In - Everet Almond.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '428', 'name': 'Fractal of Light', 'icon': '✨', 'file': 'sounds/nature/Fractal of Light - Chris Haugen.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '429', 'name': 'Floating Home', 'icon': '🏠', 'file': 'sounds/nature/Floating Home - Brian Bolger.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '430', 'name': 'Farm Country', 'icon': '🚜', 'file': 'sounds/nature/Farm Country - Telecasted.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '431', 'name': 'False Vacuum', 'icon': '⚛️', 'file': 'sounds/nature/False Vacuum Decay - The Grey Room _ Density & Time.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '432', 'name': 'Everything Where', 'icon': '🎵', 'file': 'sounds/nature/Everything Where it Needs to Be - Nat Keefe & Hot Buttered Rum.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '433', 'name': 'Dusty Road Magic', 'icon': '🛣️', 'file': 'sounds/nature/Dusty Road Magic - Chris Haugen.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '434', 'name': 'Daydreamer', 'icon': '🌌', 'file': 'sounds/nature/Daydreamer - Jeremy Black.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '435', 'name': 'Cumbia City', 'icon': '💃', 'file': 'sounds/nature/Cumbia City - An Jone.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '436', 'name': 'Crops', 'icon': '🌾', 'file': 'sounds/nature/Crops - Telecasted.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '437', 'name': 'County Lines', 'icon': '🗺️', 'file': 'sounds/nature/County Lines - Telecasted.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '438', 'name': 'Campfire', 'icon': '🔥', 'file': 'sounds/nature/Campfire - Telecasted.mp3', 'category': 'Nature', 'isFavorite': false},
      {'id': '439', 'name': 'Bailemos Guera', 'icon': '💃', 'file': 'sounds/nature/Bailemos Guera - Cumbia Deli.mp3', 'category': 'Nature', 'isFavorite': false},

      // RAIN CATEGORY
      {'id': '500', 'name': 'Rainstick', 'icon': '🎋', 'file': 'sounds/rain/Rainstick Slow.mp3', 'category': 'Rain', 'isFavorite': false},
      {'id': '501', 'name': 'Rain on Roof', 'icon': '🏠', 'file': 'sounds/rain/Rain On Roof.mp3', 'category': 'Rain', 'isFavorite': false},
      {'id': '502', 'name': 'Rain on Car', 'icon': '🚗', 'file': 'sounds/rain/Rain on Car Heavy.mp3', 'category': 'Rain', 'isFavorite': false},
      {'id': '503', 'name': 'Heavy Rain', 'icon': '🌧️', 'file': 'sounds/rain/Rain Heavy Loud.mp3', 'category': 'Rain', 'isFavorite': false},

      // RIVER CATEGORY
      {'id': '600', 'name': 'Webdriver Torso', 'icon': '🌊', 'file': 'sounds/river/Webdriver Torso.mp3', 'category': 'River', 'isFavorite': false},
      {'id': '601', 'name': 'Golf Driver', 'icon': '🏌️', 'file': 'sounds/river/Driver Club Hitting Golf Ball.mp3', 'category': 'River', 'isFavorite': false},

      // SLEEP CATEGORY
      {'id': '700', 'name': 'Your Love', 'icon': '💖', 'file': 'sounds/sleep/Your Love - Yung Logos.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '701', 'name': 'Toy Shopping', 'icon': '🛍️', 'file': 'sounds/sleep/Toy Shopping - Jeremy Korpas.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '702', 'name': 'Tiburtina', 'icon': '🎻', 'file': 'sounds/sleep/Tiburtina - Schwartzy.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '703', 'name': 'Thumri', 'icon': '🎵', 'file': 'sounds/sleep/Thumri - Sandeep Das, Anisha Roy, Bivakar Chaudhuri.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '704', 'name': 'Sugar High', 'icon': '🍬', 'file': 'sounds/sleep/Sugar High - Jeremy Korpas.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '705', 'name': 'Suave Sleuth', 'icon': '🕵️', 'file': 'sounds/sleep/Suave Sleuth - Casa Rosa_s Tulum Vibes.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '706', 'name': 'Somnia 10', 'icon': '🎵', 'file': 'sounds/sleep/Somnia Variation 10 relax and sleep - Reed Mathis.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '707', 'name': 'Somnia 9', 'icon': '🎵', 'file': 'sounds/sleep/Somnia Variation 9 relax and sleep - Reed Mathis.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '708', 'name': 'Somnia 8', 'icon': '🎵', 'file': 'sounds/sleep/Somnia Variation 8 relax and sleep - Reed Mathis.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '709', 'name': 'Somnia 7', 'icon': '🎵', 'file': 'sounds/sleep/Somnia Variation 7 relax and sleep - Reed Mathis.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '710', 'name': 'Somnia 6', 'icon': '🎵', 'file': 'sounds/sleep/Somnia Variation 6 relax and sleep - Reed Mathis.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '711', 'name': 'Somnia 2', 'icon': '🎵', 'file': 'sounds/sleep/Somnia Variation 2 relax and sleep - Reed Mathis.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '712', 'name': 'Somnia 1', 'icon': '🎵', 'file': 'sounds/sleep/Somnia Variation 1 relax and sleep - Reed Mathis.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '713', 'name': 'Sleeper', 'icon': '😴', 'file': 'sounds/sleep/Sleeper - Steve Adams.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '714', 'name': 'Ricky Tar', 'icon': '🎵', 'file': 'sounds/sleep/Ricky Tar - Casa Rosa_s Tulum Vibes.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '715', 'name': 'PELAGIC', 'icon': '🌊', 'file': 'sounds/sleep/PELAGIC - Density & Time.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '716', 'name': 'Never Play', 'icon': '🎵', 'file': 'sounds/sleep/Never Play - Jeremy Blake.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '717', 'name': 'Monster Alien', 'icon': '👾', 'file': 'sounds/sleep/Monster Alien Grunt Sleepy.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '718', 'name': 'Manj Khammaj', 'icon': '🎵', 'file': 'sounds/sleep/Manj Khammaj - Aditya Verma.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '719', 'name': 'Malkauns', 'icon': '🎵', 'file': 'sounds/sleep/Malkauns - Aditya Verma.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '720', 'name': 'Lullabye', 'icon': '🎶', 'file': 'sounds/sleep/Lullabye No.108 - The Mini Vandals.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '721', 'name': 'Icelandic Arpeggios', 'icon': '🎹', 'file': 'sounds/sleep/Icelandic Arpeggios - DivKid.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '722', 'name': 'GROWTH DECAY', 'icon': '📈', 'file': 'sounds/sleep/GROWTH_DECAY - Density & Time.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '723', 'name': 'First Dream', 'icon': '💭', 'file': 'sounds/sleep/First Dream - Brian Bolger.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '724', 'name': 'Fat Man', 'icon': '🎵', 'file': 'sounds/sleep/Fat Man - Yung Logos.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '725', 'name': 'Escapism', 'icon': '🏃', 'file': 'sounds/sleep/Escapism - Yung Logos.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '726', 'name': 'Eternal Garden', 'icon': '🌿', 'file': 'sounds/sleep/Eternal Garden - Dan Henig.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '727', 'name': 'Earth Appears', 'icon': '🌍', 'file': 'sounds/sleep/Earth Appears - Brian Bolger.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '728', 'name': 'Drifting 432Hz', 'icon': '🎵', 'file': 'sounds/sleep/Drifting at 432 Hz - Unicorn Heads.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '729', 'name': 'Bah Dop Bop', 'icon': '🎵', 'file': 'sounds/sleep/Bah Dop Bop - Casa Rosa_s Tulum Vibes.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '730', 'name': 'Baby Sleep Breaths', 'icon': '👶', 'file': 'sounds/sleep/Baby Sleep Breaths.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '731', 'name': 'Apollo', 'icon': '🚀', 'file': 'sounds/sleep/Apollo - Telecasted.mp3', 'category': 'Sleep', 'isFavorite': false},
      {'id': '732', 'name': 'AETHER', 'icon': '💫', 'file': 'sounds/sleep/AETHER - Density & Time.mp3', 'category': 'Sleep', 'isFavorite': false},

      // THUNDER CATEGORY
      {'id': '800', 'name': 'Western Soundtrack', 'icon': '🎬', 'file': 'sounds/thunder/Western Modern Soundtrack - Freedom Trail Studio.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '801', 'name': 'Tropical Thunder', 'icon': '🌴', 'file': 'sounds/thunder/Tropical Thunder - RKVC.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '802', 'name': 'Thunderstorm', 'icon': '⛈️', 'file': 'sounds/thunder/Thunderstorm - Hanu Dixit.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '803', 'name': 'Thunder Chant', 'icon': '🎵', 'file': 'sounds/thunder/Thunder Chant - E_s Jammy Jams.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '804', 'name': 'Thunder', 'icon': '⚡', 'file': 'sounds/thunder/Thunder - Telecasted.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '805', 'name': 'Thunder Eveningland', 'icon': '⚡', 'file': 'sounds/thunder/Thunder - Eveningland.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '806', 'name': 'Thunderer March', 'icon': '🥁', 'file': 'sounds/thunder/The Thunderer March - United States Marine Band.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '807', 'name': 'The Thunderer', 'icon': '🎵', 'file': 'sounds/thunder/The Thunderer - The U.S. Army Band.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '808', 'name': 'Synergy', 'icon': '🌀', 'file': 'sounds/thunder/Synergy - Geographer.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '809', 'name': 'Slip', 'icon': '🎵', 'file': 'sounds/thunder/Slip - Geographer.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '810', 'name': 'I Feel It All', 'icon': '💫', 'file': 'sounds/thunder/I Feel It All So Deeply - Bail Bonds.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '811', 'name': 'Earthly Destiny', 'icon': '🌍', 'file': 'sounds/thunder/Earthly Destiny - Sir Cubworth.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '812', 'name': 'Der Kleber Sting', 'icon': '🎵', 'file': 'sounds/thunder/Der Kleber Sting - Kevin MacLeod.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '813', 'name': 'Der Kleber Sting 2', 'icon': '🎵', 'file': 'sounds/thunder/Der Kleber Sting - Kevin MacLeod (1).mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '814', 'name': 'Chasing Vision', 'icon': '👁️', 'file': 'sounds/thunder/Chasing Down a Vision - Bail Bonds.mp3', 'category': 'Thunder', 'isFavorite': false},
      {'id': '815', 'name': 'Annihilate', 'icon': '💥', 'file': 'sounds/thunder/Annihilate - Jeremy Blake.mp3', 'category': 'Thunder', 'isFavorite': false},

      // WIND CATEGORY
      {'id': '900', 'name': 'Wind-Up Mountains', 'icon': '🏔️', 'file': 'sounds/wind/Wind-Up Mountains - Schwartzy.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '901', 'name': 'Windshield Wipers', 'icon': '🚗', 'file': 'sounds/wind/Windshield Wipers No Water.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '902', 'name': 'Window Latch', 'icon': '🪟', 'file': 'sounds/wind/Window Latch Open Series.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '903', 'name': 'Window Close', 'icon': '🪟', 'file': 'sounds/wind/Window Close Series.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '904', 'name': 'Winding Clock', 'icon': '⏰', 'file': 'sounds/wind/Winding Alarm Clock.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '905', 'name': 'Wind Up Toy', 'icon': '🤖', 'file': 'sounds/wind/Wind Up Toy.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '906', 'name': 'Wind Creaks', 'icon': '🌬️', 'file': 'sounds/wind/Wind Quiet Creaks.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '907', 'name': 'Wind on Camera', 'icon': '🎥', 'file': 'sounds/wind/Wind on Video Camera Mic.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '908', 'name': 'Pine Trees', 'icon': '🌲', 'file': 'sounds/wind/Wind In Pine Trees.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '909', 'name': 'Leaves Porch', 'icon': '🍃', 'file': 'sounds/wind/Wind In Leaves On Porch.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '910', 'name': 'Water Lapping Wind', 'icon': '🌊', 'file': 'sounds/wind/Water Lapping Wind.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '911', 'name': 'Viral Dance', 'icon': '💃', 'file': 'sounds/wind/Viral Dance - Ryan Stasik.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '912', 'name': 'Trunk Window', 'icon': '🚗', 'file': 'sounds/wind/Trunk Window Open Hydraulic Hiss.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '913', 'name': 'Soft Wind', 'icon': '💨', 'file': 'sounds/wind/Soft Wind.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '914', 'name': 'Smashing Window', 'icon': '🚗', 'file': 'sounds/wind/Smashing Car Window.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '915', 'name': 'Sliding Window', 'icon': '🪟', 'file': 'sounds/wind/Sliding Window Aggressive.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '916', 'name': 'Open Close Window', 'icon': '🪟', 'file': 'sounds/wind/Open and Close Window.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '917', 'name': 'Open Close Window 2', 'icon': '🪟', 'file': 'sounds/wind/Open and Close Window (1).mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '918', 'name': 'Monthaholic', 'icon': '🎵', 'file': 'sounds/wind/Monthaholic - Schwartzy.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '919', 'name': 'Lake Wind', 'icon': '🌊', 'file': 'sounds/wind/Lake Wind Ambience.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '920', 'name': 'Glass Windows Crash', 'icon': '💥', 'file': 'sounds/wind/Glass Windows Crashing.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '921', 'name': 'Glass Windows Break', 'icon': '💥', 'file': 'sounds/wind/Glass Windows Breaking.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '922', 'name': 'Desert Wind', 'icon': '🏜️', 'file': 'sounds/wind/Desert Howling Wind.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '923', 'name': 'Cocktail Lounge', 'icon': '🍸', 'file': 'sounds/wind/Cocktail Lounge - Dyalla.mp3', 'category': 'Wind', 'isFavorite': false},
      {'id': '924', 'name': 'Bring It Together', 'icon': '🎵', 'file': 'sounds/wind/Bring It Together - Telecasted.mp3', 'category': 'Wind', 'isFavorite': false},
    ];

    // Initialize volumes for all sounds
    for (var sound in _availableSounds) {
      _soundVolumes[sound['id']] = 0.5;
    }

    print('🔊 Loaded ${_availableSounds.length} sounds from local data');
  }
}