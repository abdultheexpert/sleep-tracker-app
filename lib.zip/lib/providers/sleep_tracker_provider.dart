import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/api_service.dart';

class SleepTrackerProvider with ChangeNotifier {
  bool _isTracking = false;
  bool _isAnalyzing = false;
  DateTime? _sleepStartTime;
  List<Map<String, dynamic>> _sleepHistory = [];
  Map<String, dynamic> _currentSleepData = {};
  List<Map<String, dynamic>> _sleepEvents = [];
  Timer? _audioAnalysisTimer;
  Timer? _movementAnalysisTimer;
  Timer? _sleepStageTimer;
  Timer? _sensorDataTimer;
  Random _random = Random();
  List<double> _accelerometerData = [];
  List<double> _gyroscopeData = [];
  StreamSubscription<AccelerometerEvent>? _accelerometerSubscription;
  StreamSubscription<GyroscopeEvent>? _gyroscopeSubscription;
  StreamSubscription<UserAccelerometerEvent>? _userAccelerometerSubscription;

  // ========== GETTERS ==========
  bool get isTracking => _isTracking;
  bool get isAnalyzing => _isAnalyzing;
  List<Map<String, dynamic>> get sleepHistory => _sleepHistory;
  Map<String, dynamic> get currentSleepData => _currentSleepData;
  List<Map<String, dynamic>> get sleepEvents => _sleepEvents;

  Duration get currentTrackingDuration {
    if (!_isTracking || _sleepStartTime == null) return Duration.zero;
    return DateTime.now().difference(_sleepStartTime!);
  }

  String get currentSleepStage {
    return _currentSleepData['currentStage'] ?? 'awake';
  }

  double get trackingProgress {
    if (!_isTracking) return 0.0;
    final duration = currentTrackingDuration;
    final totalMinutes = duration.inMinutes;
    return (totalMinutes / 480).clamp(0.0, 1.0); // 8 hours max
  }

  // ========== INITIALIZATION ==========
  SleepTrackerProvider() {
    _initializeSensors();
    _loadSleepHistory();
  }

  Future<void> _initializeSensors() async {
    try {
      await Permission.microphone.request();
      await Permission.sensors.request();
      await Permission.notification.request();
      print('✅ Sensor permissions initialized');
    } catch (e) {
      print('❌ Error initializing sensors: $e');
    }
  }

  Future<void> _loadSleepHistory() async {
    try {
      final backendData = await ApiService.getSleepHistory();
      if (backendData.isNotEmpty) {
        _sleepHistory = List<Map<String, dynamic>>.from(backendData);
        print('✅ Loaded ${_sleepHistory.length} sleep sessions from backend');
      } else {
        _loadDemoHistory();
      }
    } catch (e) {
      print('❌ Error loading sleep history from backend: $e');
      _loadDemoHistory();
    }
    notifyListeners();
  }

  void _loadDemoHistory() {
    _sleepHistory = [
      {
        'id': 'demo_1',
        'startTime': DateTime.now().subtract(Duration(days: 1)),
        'endTime': DateTime.now().subtract(Duration(days: 1)).add(Duration(hours: 7, minutes: 30)),
        'duration': Duration(hours: 7, minutes: 30),
        'deepSleep': Duration(hours: 1, minutes: 45),
        'lightSleep': Duration(hours: 4, minutes: 15),
        'remSleep': Duration(hours: 1, minutes: 30),
        'awakeTime': Duration(minutes: 30),
        'sleepScore': 82,
        'sleepEfficiency': 92.5,
        'sleepReport': {
          'totalSleepTime': Duration(hours: 7),
          'sleepEfficiency': 92.5,
          'sleepScore': 82,
          'deepSleepPercentage': 25,
          'remSleepPercentage': 21,
          'lightSleepPercentage': 54,
          'awakePercentage': 7,
          'eventsSummary': {'snoring': 3, 'coughing': 1, 'talking': 0, 'movement': 8},
          'recommendations': ['Maintain consistent sleep schedule', 'Reduce screen time before bed'],
        },
        'source': 'demo_data'
      }
    ];
  }

  // ========== SLEEP TRACKING CONTROL ==========
  Future<void> startSleepTracking() async {
    if (_isTracking) return;

    setState(() {
      _isTracking = true;
      _isAnalyzing = false;
    });

    _sleepStartTime = DateTime.now();
    _currentSleepData = {
      'id': 'session_${DateTime.now().millisecondsSinceEpoch}',
      'startTime': _sleepStartTime,
      'sleepStages': [],
      'snoringEvents': 0,
      'coughingEvents': 0,
      'talkingEvents': 0,
      'movementEvents': 0,
      'audioAnalysis': [],
      'sensorData': [],
      'currentStage': 'awake',
      'deviceInfo': {
        'platform': 'flutter',
        'timestamp': DateTime.now().toIso8601String(),
      }
    };
    _sleepEvents.clear();
    _accelerometerData.clear();
    _gyroscopeData.clear();

    // Start all monitoring systems
    _startAudioMonitoring();
    _startMovementMonitoring();
    _startSleepStageSimulation();
    _startSensorMonitoring();

    print('🎯 Sleep tracking started at $_sleepStartTime');
    notifyListeners();
  }

  Future<void> stopSleepTracking() async {
    if (!_isTracking) return;

    setState(() {
      _isAnalyzing = true;
    });

    _stopAllMonitoring();

    final sleepEndTime = DateTime.now();
    final duration = sleepEndTime.difference(_sleepStartTime!);

    // Generate final sleep data
    _generateRealisticSleepData(duration);

    // Perform AI analysis
    await _performAIAnalysis();

    // Save to backend
    await _saveSleepDataToBackend();

    // Save to local history
    _sleepHistory.insert(0, Map<String, dynamic>.from(_currentSleepData));

    setState(() {
      _isTracking = false;
      _isAnalyzing = false;
    });

    print('✅ Sleep tracking completed. Duration: $duration');
    notifyListeners();
  }

  void _stopAllMonitoring() {
    _audioAnalysisTimer?.cancel();
    _movementAnalysisTimer?.cancel();
    _sleepStageTimer?.cancel();
    _sensorDataTimer?.cancel();

    _accelerometerSubscription?.cancel();
    _gyroscopeSubscription?.cancel();
    _userAccelerometerSubscription?.cancel();
  }

  // ========== BACKEND INTEGRATION ==========
  Future<void> _saveSleepDataToBackend() async {
    try {
      final totalMinutes = _currentSleepData['duration'].inMinutes;

      final result = await ApiService.submitSleepSession(
        duration: totalMinutes.toDouble(),
        quality: _currentSleepData['sleepScore'] ?? 80,
        stages: {
          'light': _currentSleepData['lightSleep'].inMinutes.toDouble(),
          'deep': _currentSleepData['deepSleep'].inMinutes.toDouble(),
          'rem': _currentSleepData['remSleep'].inMinutes.toDouble(),
        },
        soundsDetected: _getDetectedSounds(),
        date: _sleepStartTime!.toIso8601String(),
      );

      if (result['success']) {
        print('✅ Sleep data saved to backend');
        if (result['data'] != null && result['data']['_id'] != null) {
          _currentSleepData['backendId'] = result['data']['_id'];
        }
      } else {
        print('❌ Failed to save sleep data to backend: ${result['error']}');
      }
    } catch (e) {
      print('❌ Error saving sleep data to backend: $e');
    }
  }

  List<String> _getDetectedSounds() {
    List<String> sounds = [];
    if ((_currentSleepData['snoringEvents'] ?? 0) > 0) sounds.add('snoring');
    if ((_currentSleepData['coughingEvents'] ?? 0) > 0) sounds.add('coughing');
    if ((_currentSleepData['talkingEvents'] ?? 0) > 0) sounds.add('talking');
    if ((_currentSleepData['movementEvents'] ?? 0) > 0) sounds.add('movement');
    return sounds;
  }

  Future<void> _performAIAnalysis() async {
    try {
      print('🤖 Starting AI sleep analysis...');

      final result = await ApiService.analyzeSleepWithAI(
        audioData: _encodeAudioDataForAI(),
        userId: 'current_user',
        sessionId: _currentSleepData['id'],
      );

      if (result['success']) {
        print('✅ AI analysis completed successfully');
        _currentSleepData['aiAnalysis'] = result['data'];
        if (_currentSleepData['sleepReport'] != null) {
          _currentSleepData['sleepReport']['aiInsights'] = result['data']['analysis']?['insights'] ?? [];
        }
      } else {
        print('❌ AI analysis failed: ${result['error']}');
        _generateAIFallbackAnalysis();
      }
    } catch (e) {
      print('❌ Error during AI analysis: $e');
      _generateAIFallbackAnalysis();
    }
  }

  String _encodeAudioDataForAI() {
    return 'simulated_audio_data_${DateTime.now().millisecondsSinceEpoch}';
  }

  void _generateAIFallbackAnalysis() {
    _currentSleepData['aiAnalysis'] = {
      'analysis': {
        'snoringConfidence': 65 + _random.nextInt(30),
        'sleepApneaRisk': 'low',
        'breathingPattern': 'normal',
        'sleepQualityMetrics': {
          'consistency': 75 + _random.nextInt(20),
          'depth': 70 + _random.nextInt(25),
          'efficiency': 80 + _random.nextInt(15),
        },
        'insights': [
          'Normal breathing patterns detected',
          'Minimal sleep disruptions',
          'Good sleep cycle consistency'
        ],
      },
      'source': 'fallback_analysis'
    };
  }

  // ========== SENSOR MONITORING ==========
  void _startSensorMonitoring() {
    _accelerometerSubscription = accelerometerEvents.listen((AccelerometerEvent event) {
      if (!_isTracking) return;

      final movement = sqrt(event.x * event.x + event.y * event.y + event.z * event.z);
      _accelerometerData.add(movement);

      if (_accelerometerData.length > 100) {
        _accelerometerData.removeAt(0);
      }

      _analyzeRealMovement(movement);
    });

    _gyroscopeSubscription = gyroscopeEvents.listen((GyroscopeEvent event) {
      if (!_isTracking) return;

      final rotation = sqrt(event.x * event.x + event.y * event.y + event.z * event.z);
      _gyroscopeData.add(rotation);

      if (_gyroscopeData.length > 100) {
        _gyroscopeData.removeAt(0);
      }
    });

    _userAccelerometerSubscription = userAccelerometerEvents.listen((UserAccelerometerEvent event) {
      if (!_isTracking) return;

      final userAcceleration = sqrt(event.x * event.x + event.y * event.y + event.z * event.z);
      _detectBodyMovement(userAcceleration);
    });
  }

  void _analyzeRealMovement(double movement) {
    if (movement > 1.5) {
      _detectSleepEvent('movement', 'Significant body movement detected', 75 + _random.nextInt(20));
    }
    _updateSleepStageFromSensors();
  }

  void _detectBodyMovement(double acceleration) {
    if (acceleration > 2.0 && _isTracking) {
      _currentSleepData['movementEvents'] = (_currentSleepData['movementEvents'] ?? 0) + 1;

      _sleepEvents.add({
        'type': 'body_movement',
        'timestamp': DateTime.now(),
        'description': 'Body position change detected',
        'confidence': 80 + _random.nextInt(15),
        'intensity': 'moderate',
        'sensorData': {
          'acceleration': acceleration,
          'type': 'position_change'
        }
      });

      notifyListeners();
    }
  }

  void _updateSleepStageFromSensors() {
    if (!_isTracking || _accelerometerData.length < 10) return;

    final recentMovement = _accelerometerData.length >= 10
        ? _accelerometerData.sublist(_accelerometerData.length - 10).reduce((a, b) => a + b) / 10
        : _accelerometerData.reduce((a, b) => a + b) / _accelerometerData.length;

    String stage;
    if (recentMovement < 0.3) {
      stage = 'deep';
    } else if (recentMovement < 0.8) {
      stage = 'light';
    } else if (recentMovement < 1.5) {
      stage = 'rem';
    } else {
      stage = 'awake';
    }

    _currentSleepData['currentStage'] = stage;
    _addSleepStage(stage, recentMovement);
  }

  // ========== AUDIO MONITORING ==========
  void _startAudioMonitoring() {
    _audioAnalysisTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      if (!_isTracking) {
        timer.cancel();
        return;
      }
      _analyzeAudioPatterns();
    });
  }

  void _analyzeAudioPatterns() {
    if (!_isTracking) return;

    final randomValue = _random.nextInt(100);
    final currentTime = DateTime.now();
    final trackingMinutes = currentTrackingDuration.inMinutes;

    double snoringProbability = trackingMinutes > 30 ? 15 : 5;
    double coughingProbability = 8;
    double talkingProbability = trackingMinutes < 10 ? 10 : 3;

    if (randomValue < snoringProbability) {
      _detectSleepEvent('snoring', 'Rhythmic breathing pattern consistent with snoring', 70 + _random.nextInt(25));
    } else if (randomValue < snoringProbability + coughingProbability) {
      _detectSleepEvent('coughing', 'Sharp expiratory sound detected', 75 + _random.nextInt(20));
    } else if (randomValue < snoringProbability + coughingProbability + talkingProbability) {
      _detectSleepEvent('talking', 'Vocalization patterns detected', 65 + _random.nextInt(30));
    } else if (randomValue < 25) {
      _detectSleepEvent('movement', 'Audio signature consistent with body movement', 60 + _random.nextInt(25));
    }

    _currentSleepData['audioAnalysis'].add({
      'timestamp': currentTime,
      'analysisType': 'periodic_check',
      'movementLevel': _random.nextDouble() * 2.0,
      'ambientNoise': _random.nextDouble() * 100,
      'detectedEvents': _sleepEvents.where((e) => e['timestamp'].isAfter(currentTime.subtract(Duration(seconds: 30)))).length,
    });
  }

  // ========== MOVEMENT ANALYSIS ==========
  void _startMovementMonitoring() {
    _movementAnalysisTimer = Timer.periodic(Duration(seconds: 60), (timer) {
      if (!_isTracking) {
        timer.cancel();
        return;
      }
      _analyzeComprehensiveMovement();
    });
  }

  void _analyzeComprehensiveMovement() {
    final movementScore = _calculateMovementScore();
    _addMovementAnalysis(movementScore);
  }

  double _calculateMovementScore() {
    if (_accelerometerData.isEmpty) return _random.nextDouble() * 2.0;

    final recentMovements = _accelerometerData.length >= 20
        ? _accelerometerData.sublist(_accelerometerData.length - 20)
        : _accelerometerData;

    return recentMovements.reduce((a, b) => a + b) / recentMovements.length;
  }

  void _addMovementAnalysis(double movementScore) {
    _currentSleepData['sensorData'].add({
      'timestamp': DateTime.now(),
      'movementScore': movementScore,
      'accelerometerAvg': movementScore,
      'gyroscopeAvg': _gyroscopeData.isNotEmpty ? _gyroscopeData.reduce((a, b) => a + b) / _gyroscopeData.length : 0.0,
      'sleepStage': _currentSleepData['currentStage'],
    });
  }

  // ========== SLEEP STAGE MANAGEMENT ==========
  void _startSleepStageSimulation() {
    _sleepStageTimer = Timer.periodic(Duration(minutes: 5), (timer) {
      if (!_isTracking) {
        timer.cancel();
        return;
      }
      _simulateSleepStageProgression();
    });
  }

  void _simulateSleepStageProgression() {
    final trackingMinutes = currentTrackingDuration.inMinutes;
    String stage;

    if (trackingMinutes < 15) {
      stage = 'awake';
    } else if (trackingMinutes < 30) {
      stage = 'light';
    } else if (trackingMinutes < 90) {
      stage = 'deep';
    } else if (trackingMinutes < 110) {
      stage = 'rem';
    } else {
      final cyclePosition = (trackingMinutes - 110) % 90;
      if (cyclePosition < 30) stage = 'light';
      else if (cyclePosition < 60) stage = 'deep';
      else stage = 'rem';
    }

    _currentSleepData['currentStage'] = stage;
    _addSleepStage(stage, _calculateMovementScore());
  }

  void _detectSleepEvent(String eventType, String description, int confidence) {
    _currentSleepData['${eventType}Events'] = (_currentSleepData['${eventType}Events'] ?? 0) + 1;

    _sleepEvents.add({
      'type': eventType,
      'timestamp': DateTime.now(),
      'description': description,
      'confidence': confidence,
      'intensity': _getEventIntensity(eventType),
      'sleepStage': _currentSleepData['currentStage'],
      'sensorCorrelation': {
        'movement': _calculateMovementScore(),
        'timestamp': DateTime.now().toIso8601String(),
      }
    });

    notifyListeners();
  }

  String _getEventIntensity(String eventType) {
    switch (eventType) {
      case 'snoring': return ['light', 'medium', 'heavy'][_random.nextInt(3)];
      case 'coughing': return ['mild', 'strong'][_random.nextInt(2)];
      case 'talking': return ['mumble', 'clear'][_random.nextInt(2)];
      case 'movement': return ['subtle', 'moderate', 'significant'][_random.nextInt(3)];
      default: return 'medium';
    }
  }

  void _addSleepStage(String stage, double movement) {
    if (_currentSleepData['sleepStages'] == null) {
      _currentSleepData['sleepStages'] = [];
    }

    _currentSleepData['sleepStages'].add({
      'stage': stage,
      'timestamp': DateTime.now(),
      'movement': movement,
      'duration': 5,
      'sensorConfidence': (80 + _random.nextInt(20)).toDouble(),
    });
  }

  // ========== DATA GENERATION & ANALYSIS ==========
  void _generateRealisticSleepData(Duration totalDuration) {
    final totalMinutes = totalDuration.inMinutes;

    final deepSleep = Duration(minutes: (totalMinutes * 0.20).round());
    final remSleep = Duration(minutes: (totalMinutes * 0.25).round());
    final lightSleep = Duration(minutes: (totalMinutes * 0.45).round());
    final awakeTime = Duration(minutes: (totalMinutes * 0.10).round());

    _currentSleepData['endTime'] = DateTime.now();
    _currentSleepData['duration'] = totalDuration;
    _currentSleepData['deepSleep'] = deepSleep;
    _currentSleepData['lightSleep'] = lightSleep;
    _currentSleepData['remSleep'] = remSleep;
    _currentSleepData['awakeTime'] = awakeTime;
    _currentSleepData['sleepScore'] = _calculateRealisticSleepScore(totalMinutes, awakeTime.inMinutes);
    _currentSleepData['sleepEfficiency'] = ((totalMinutes - awakeTime.inMinutes) / totalMinutes * 100);

    _generateComprehensiveSleepReport();
  }

  int _calculateRealisticSleepScore(int totalMinutes, int awakeMinutes) {
    int baseScore = 70;

    if (totalMinutes >= 420 && totalMinutes <= 540) baseScore += 15;
    else if (totalMinutes >= 360 && totalMinutes < 420) baseScore += 10;
    else if (totalMinutes > 540) baseScore += 5;

    final awakePercentage = (awakeMinutes / totalMinutes * 100);
    if (awakePercentage > 15) baseScore -= 15;
    else if (awakePercentage > 10) baseScore -= 10;
    else if (awakePercentage > 5) baseScore -= 5;

    final efficiency = ((totalMinutes - awakeMinutes) / totalMinutes * 100);
    if (efficiency >= 90) baseScore += 10;
    else if (efficiency >= 85) baseScore += 5;

    final snoringEvents = _currentSleepData['snoringEvents'] ?? 0;
    if (snoringEvents > 10) baseScore -= 5;

    return baseScore.clamp(0, 100);
  }

  void _generateComprehensiveSleepReport() {
    final totalSleep = (_currentSleepData['duration'] as Duration).inMinutes - (_currentSleepData['awakeTime'] as Duration).inMinutes;

    _currentSleepData['sleepReport'] = {
      'totalSleepTime': Duration(minutes: totalSleep),
      'sleepEfficiency': _currentSleepData['sleepEfficiency'],
      'sleepScore': _currentSleepData['sleepScore'],
      'deepSleepPercentage': ((_currentSleepData['deepSleep'] as Duration).inMinutes / totalSleep * 100).round(),
      'remSleepPercentage': ((_currentSleepData['remSleep'] as Duration).inMinutes / totalSleep * 100).round(),
      'lightSleepPercentage': ((_currentSleepData['lightSleep'] as Duration).inMinutes / totalSleep * 100).round(),
      'awakePercentage': ((_currentSleepData['awakeTime'] as Duration).inMinutes / (_currentSleepData['duration'] as Duration).inMinutes * 100).round(),
      'eventsSummary': {
        'snoring': _currentSleepData['snoringEvents'] ?? 0,
        'coughing': _currentSleepData['coughingEvents'] ?? 0,
        'talking': _currentSleepData['talkingEvents'] ?? 0,
        'movement': _currentSleepData['movementEvents'] ?? 0,
        'body_movements': _sleepEvents.where((e) => e['type'] == 'body_movement').length,
      },
      'sleepCycles': _calculateSleepCycles(),
      'recommendations': _generatePersonalizedRecommendations(),
      'trends': _analyzeSleepTrends(),
    };
  }

  int _calculateSleepCycles() {
    final totalMinutes = (_currentSleepData['duration'] as Duration).inMinutes;
    return (totalMinutes / 90).round();
  }

  Map<String, dynamic> _analyzeSleepTrends() {
    return {
      'consistency': 75 + _random.nextInt(20),
      'deepSleepTrend': 'stable',
      'remSleepTrend': 'improving',
      'efficiencyTrend': 'consistent',
      'comparisonToAverage': 'better',
    };
  }

  List<String> _generatePersonalizedRecommendations() {
    final score = _currentSleepData['sleepScore'] ?? 0;
    final snoringEvents = _currentSleepData['snoringEvents'] ?? 0;
    final awakePercentage = ((_currentSleepData['awakeTime'] as Duration).inMinutes / (_currentSleepData['duration'] as Duration).inMinutes * 100);
    final totalMinutes = (_currentSleepData['duration'] as Duration).inMinutes;

    List<String> recommendations = [];

    if (score < 70) recommendations.add('Try to maintain a consistent sleep schedule of 7-9 hours');
    if (awakePercentage > 10) recommendations.add('Reduce screen time 1 hour before bed for better sleep onset');
    if (snoringEvents > 5) recommendations.add('Consider side sleeping position to reduce snoring');
    if (totalMinutes < 360) recommendations.add('Aim for at least 6 hours of sleep for optimal health');
    if (totalMinutes > 600) recommendations.add('Consider if you\'re getting too much sleep - 7-9 hours is optimal');

    if (recommendations.isEmpty) {
      recommendations.add('Excellent sleep habits! Continue your current routine');
    }

    return recommendations;
  }

  // ========== PUBLIC UTILITY METHODS ==========
  List<Map<String, dynamic>> getRecentEvents(int count) {
    return _sleepEvents.length > count
        ? _sleepEvents.sublist(_sleepEvents.length - count)
        : _sleepEvents;
  }

  Map<String, dynamic> getSleepStats() {
    if (_sleepHistory.isEmpty) return {};

    final totalSessions = _sleepHistory.length;
    final avgDuration = _sleepHistory.map((session) => session['duration'].inMinutes).reduce((a, b) => a + b) / totalSessions;
    final avgScore = _sleepHistory.map((session) => session['sleepScore'] ?? 0).reduce((a, b) => a + b) / totalSessions;

    return {
      'totalSessions': totalSessions,
      'avgDuration': Duration(minutes: avgDuration.round()),
      'avgScore': avgScore.round(),
      'bestScore': _sleepHistory.map((session) => session['sleepScore'] ?? 0).reduce((a, b) => a > b ? a : b),
      'totalSleepTime': _sleepHistory.map((session) => session['duration']).fold(Duration.zero, (sum, duration) => sum + duration),
      'avgEfficiency': _sleepHistory.map((session) => session['sleepEfficiency'] ?? 0).reduce((a, b) => a + b) / totalSessions,
      'consistencyScore': _calculateConsistencyScore(),
    };
  }

  double _calculateConsistencyScore() {
    if (_sleepHistory.length < 2) return 0.0;

    final durations = _sleepHistory.map((session) => session['duration'].inMinutes.toDouble()).toList();
    final mean = durations.reduce((a, b) => a + b) / durations.length;
    final variance = durations.map((d) => pow(d - mean, 2)).reduce((a, b) => a + b) / durations.length;
    final standardDeviation = sqrt(variance);

    return (100 - (standardDeviation / mean * 100)).clamp(0, 100);
  }

  String getSleepScoreDescription(int score) {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Good';
    if (score >= 70) return 'Fair';
    if (score >= 60) return 'Poor';
    return 'Very Poor';
  }

  void clearSleepData() {
    _sleepHistory.clear();
    _sleepEvents.clear();
    _currentSleepData = {};
    notifyListeners();
  }

  Future<void> refreshSleepHistory() async {
    await _loadSleepHistory();
  }

  void setState(VoidCallback fn) {
    fn();
    notifyListeners();
  }

  @override
  void dispose() {
    _stopAllMonitoring();
    super.dispose();
  }
}