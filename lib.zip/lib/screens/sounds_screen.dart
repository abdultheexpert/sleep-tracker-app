import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/sound_mixer_provider.dart';
import '../services/api_service.dart';

class SoundsScreen extends StatefulWidget {
  @override
  _SoundsScreenState createState() => _SoundsScreenState();
}

class _SoundsScreenState extends State<SoundsScreen> with SingleTickerProviderStateMixin {
  String _selectedCategory = 'All';
  final List<String> _categories = ['All', 'Noise', 'Birds', 'Forest', 'Nature', 'Rain', 'River', 'Sleep', 'Thunder', 'Wind', 'Favorites'];
  late AnimationController _animationController;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 2000),
    );
    _loadSoundsFromBackend();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadSoundsFromBackend() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final sounds = await ApiService.getSounds();
      final soundProvider = Provider.of<SoundMixerProvider>(context, listen: false);

      // Update provider with backend sounds
      if (sounds.isNotEmpty && sounds[0]['source'] != 'demo_data') {
        // Convert backend format to app format
        final convertedSounds = sounds.map((sound) => {
          'id': sound['_id'],
          'name': sound['name'],
          'icon': _getIconForCategory(sound['category']),
          'file': sound['file'],
          'category': sound['category'],
          'isFavorite': sound['isFavorite'] ?? false,
          'isPremium': sound['isPremium'] ?? false,
        }).toList();

        // Update provider (you'll need to add a method to SoundMixerProvider)
        // soundProvider.updateSounds(convertedSounds);
      }
    } catch (e) {
      print('Error loading sounds from backend: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  String _getIconForCategory(String category) {
    final icons = {
      'Noise': '🎵',
      'Birds': '🐦',
      'Forest': '🌲',
      'Nature': '🌿',
      'Rain': '🌧️',
      'River': '🌊',
      'Sleep': '😴',
      'Thunder': '⚡',
      'Wind': '💨',
    };
    return icons[category] ?? '🎵';
  }

  @override
  Widget build(BuildContext context) {
    final soundProvider = Provider.of<SoundMixerProvider>(context);

    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.music_note, color: Colors.blueAccent, size: 24),
            SizedBox(width: 8),
            Text('Sleep Sounds', style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            )),
          ],
        ),
        backgroundColor: Color(0xFF1D1E33),
        elevation: 0,
        actions: [
          // Favorite sounds button with badge
          Stack(
            children: [
              IconButton(
                icon: Icon(Icons.favorite, color: Colors.white),
                onPressed: () {
                  setState(() {
                    _selectedCategory = 'Favorites';
                  });
                },
              ),
              if (soundProvider.getFavoriteSounds().isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    constraints: BoxConstraints(
                      minWidth: 12,
                      minHeight: 12,
                    ),
                    child: Text(
                      '${soundProvider.getFavoriteSounds().length}',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
          // Mix management button
          IconButton(
            icon: Icon(Icons.playlist_add, color: Colors.white),
            onPressed: () => _showSavedMixes(soundProvider),
          ),
        ],
      ),
      body: Column(
        children: [
          // Category Filter with improved design
          _buildCategoryFilter(),

          // Active Sounds Bar with enhanced visuals
          if (soundProvider.activeSounds.isNotEmpty)
            _buildActiveSoundsBar(soundProvider),

          // Loading indicator or sounds grid
          Expanded(
            child: _isLoading
                ? _buildLoadingIndicator()
                : _buildSoundsGrid(soundProvider),
          ),

          // Enhanced Player Controls
          _buildPlayerControls(soundProvider),
        ],
      ),
    );
  }

  Widget _buildCategoryFilter() {
    return Container(
      height: 70,
      decoration: BoxDecoration(
        color: Color(0xFF1D1E33),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
      ),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        itemCount: _categories.length,
        itemBuilder: (context, index) {
          final category = _categories[index];
          final isSelected = _selectedCategory == category;

          return Padding(
            padding: EdgeInsets.only(right: 8),
            child: AnimatedContainer(
              duration: Duration(milliseconds: 300),
              decoration: BoxDecoration(
                color: isSelected ? Colors.blueAccent : Color(0xFF2A2B3D),
                borderRadius: BorderRadius.circular(25),
                border: isSelected ? Border.all(color: Colors.blueAccent, width: 2) : null,
                boxShadow: isSelected ? [
                  BoxShadow(
                    color: Colors.blueAccent.withOpacity(0.3),
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  )
                ] : null,
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(25),
                  onTap: () {
                    setState(() {
                      _selectedCategory = category;
                    });
                  },
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (category == 'Favorites')
                          Icon(Icons.favorite,
                              color: isSelected ? Colors.white : Colors.red,
                              size: 16),
                        SizedBox(width: category == 'Favorites' ? 4 : 0),
                        Text(
                          category,
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildActiveSoundsBar(SoundMixerProvider soundProvider) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blueAccent.withOpacity(0.1), Colors.purpleAccent.withOpacity(0.1)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        border: Border(
          bottom: BorderSide(color: Colors.blueAccent.withOpacity(0.3), width: 1),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.volume_up, color: Colors.blueAccent, size: 16),
              SizedBox(width: 8),
              Text(
                'Active Sounds (${soundProvider.activeSounds.length}/7)',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Spacer(),
              if (soundProvider.activeSounds.isNotEmpty)
                TextButton(
                  onPressed: () => soundProvider.clearAllSounds(),
                  child: Text(
                    'Clear All',
                    style: TextStyle(
                      color: Colors.redAccent,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: soundProvider.activeSounds.map((sound) {
              return AnimatedContainer(
                duration: Duration(milliseconds: 300),
                child: Chip(
                  label: Text(
                    sound['name'],
                    style: TextStyle(color: Colors.white, fontSize: 12),
                  ),
                  backgroundColor: Colors.blueAccent,
                  deleteIcon: Icon(Icons.close, size: 14, color: Colors.white),
                  onDeleted: () => soundProvider.toggleSound(sound),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 50,
            height: 50,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent),
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Loading Sounds...',
            style: TextStyle(color: Colors.white70, fontSize: 16),
          ),
        ],
      ),
    );
  }

  Widget _buildSoundsGrid(SoundMixerProvider soundProvider) {
    final filteredSounds = _getFilteredSounds(soundProvider);

    if (filteredSounds.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.music_off, size: 64, color: Colors.white30),
            SizedBox(height: 16),
            Text(
              _selectedCategory == 'Favorites'
                  ? 'No favorite sounds yet'
                  : 'No sounds found',
              style: TextStyle(color: Colors.white70, fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              _selectedCategory == 'Favorites'
                  ? 'Double-tap on sounds to add them to favorites'
                  : 'Try selecting a different category',
              style: TextStyle(color: Colors.white54, fontSize: 14),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.all(16),
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.85,
        ),
        itemCount: filteredSounds.length,
        itemBuilder: (context, index) {
          final sound = filteredSounds[index];
          return _buildSoundCard(sound, soundProvider);
        },
      ),
    );
  }

  Widget _buildSoundCard(Map<String, dynamic> sound, SoundMixerProvider soundProvider) {
    final isActive = soundProvider.isSoundActive(sound['id']);
    final isFavorite = sound['isFavorite'] == true;
    final isPremium = sound['isPremium'] == true;

    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      child: Card(
        color: isActive ? Colors.blueAccent.withOpacity(0.2) : Color(0xFF1D1E33),
        elevation: isActive ? 8 : 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: isActive ? Colors.blueAccent : Colors.transparent,
            width: isActive ? 2 : 0,
          ),
        ),
        child: InkWell(
          onTap: () {
            if (isPremium) {
              _showPremiumDialog();
            } else {
              soundProvider.toggleSound(sound);
              if (isActive) {
                _animationController.forward(from: 0.0);
              }
            }
          },
          onDoubleTap: () => soundProvider.toggleFavorite(sound['id']),
          borderRadius: BorderRadius.circular(16),
          child: Stack(
            children: [
              Padding(
                padding: EdgeInsets.all(12),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Animated icon with Better Sleep style
                    AnimatedContainer(
                      duration: Duration(milliseconds: 500),
                      curve: Curves.elasticOut,
                      transform: Matrix4.identity()
                        ..scale(isActive ? 1.1 : 1.0),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              color: isActive ? Colors.blueAccent.withOpacity(0.3) : Colors.white10,
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                sound['icon'],
                                style: TextStyle(fontSize: 24),
                              ),
                            ),
                          ),
                          if (isActive)
                            Icon(
                              Icons.waves,
                              color: Colors.blueAccent,
                              size: 30,
                            ),
                        ],
                      ),
                    ),
                    SizedBox(height: 8),
                    // Sound name with better typography
                    Text(
                      sound['name'],
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white,
                        fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                        height: 1.2,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (isActive) ...[
                      SizedBox(height: 4),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.volume_up, color: Colors.blueAccent, size: 12),
                          SizedBox(width: 4),
                          // Volume slider for active sounds
                          Expanded(
                            child: Slider(
                              value: soundProvider.getVolume(sound['id']),
                              onChanged: (value) => soundProvider.setVolume(sound['id'], value),
                              min: 0,
                              max: 1,
                              activeColor: Colors.blueAccent,
                              inactiveColor: Colors.white30,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              // Favorite indicator
              if (isFavorite)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.favorite, color: Colors.white, size: 12),
                  ),
                ),
              // Premium lock indicator
              if (isPremium)
                Positioned(
                  top: 8,
                  left: 8,
                  child: Container(
                    padding: EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.lock, color: Colors.white, size: 12),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPlayerControls(SoundMixerProvider soundProvider) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      height: soundProvider.activeSounds.isNotEmpty ? 120 : 0,
      decoration: BoxDecoration(
        color: Color(0xFF1D1E33),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: Offset(0, -2),
          ),
        ],
      ),
      child: soundProvider.activeSounds.isNotEmpty
          ? Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            // Master volume control
            Row(
              children: [
                Icon(Icons.volume_up, color: Colors.white70, size: 16),
                SizedBox(width: 8),
                Expanded(
                  child: Slider(
                    value: soundProvider.masterVolume,
                    onChanged: (value) => soundProvider.setMasterVolume(value),
                    min: 0,
                    max: 1,
                    activeColor: Colors.blueAccent,
                    inactiveColor: Colors.white30,
                  ),
                ),
                Text(
                  '${(soundProvider.masterVolume * 100).round()}%',
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
            SizedBox(height: 12),
            // Playback controls
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: Icon(Icons.favorite_border, color: Colors.white70),
                  onPressed: () => _showSaveMixDialog(soundProvider),
                  tooltip: 'Save Mix',
                ),
                AnimatedContainer(
                  duration: Duration(milliseconds: 300),
                  decoration: BoxDecoration(
                    color: Colors.blueAccent,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blueAccent.withOpacity(0.5),
                        blurRadius: 8,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: IconButton(
                    icon: Icon(
                      soundProvider.isPlaying ? Icons.pause : Icons.play_arrow,
                      color: Colors.white,
                      size: 30,
                    ),
                    onPressed: soundProvider.togglePlayback,
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.shuffle, color: Colors.white70),
                  onPressed: () => _shuffleSounds(soundProvider),
                  tooltip: 'Shuffle Sounds',
                ),
              ],
            ),
          ],
        ),
      )
          : SizedBox.shrink(),
    );
  }

  void _showSaveMixDialog(SoundMixerProvider soundProvider) {
    final TextEditingController controller = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Save Sound Mix',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Save your current sound mix for later use',
                style: TextStyle(color: Colors.white70)),
            SizedBox(height: 16),
            TextField(
              controller: controller,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Enter mix name (e.g., "Ocean Relaxation")',
                hintStyle: TextStyle(color: Colors.white54),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Color(0xFF2A2B3D),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              if (controller.text.trim().isNotEmpty) {
                soundProvider.saveCurrentMix(controller.text.trim());
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('"${controller.text}" mix saved!'),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            },
            child: Text('Save Mix'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  void _showSavedMixes(SoundMixerProvider soundProvider) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: 400,
        decoration: BoxDecoration(
          color: Color(0xFF1D1E33),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(16),
              child: Text('Saved Sound Mixes',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            Expanded(
              child: soundProvider.favoriteMixes.isEmpty
                  ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.playlist_add, size: 64, color: Colors.white30),
                    SizedBox(height: 16),
                    Text('No saved mixes yet',
                        style: TextStyle(color: Colors.white70)),
                  ],
                ),
              )
                  : ListView.builder(
                itemCount: soundProvider.favoriteMixes.length,
                itemBuilder: (context, index) {
                  final mix = soundProvider.favoriteMixes[index];
                  return ListTile(
                    leading: Icon(Icons.playlist_play, color: Colors.blueAccent),
                    title: Text(mix['name'], style: TextStyle(color: Colors.white)),
                    subtitle: Text(
                      '${mix['sounds'].length} sounds',
                      style: TextStyle(color: Colors.white70),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.play_arrow, color: Colors.blueAccent),
                          onPressed: () => soundProvider.loadMix(index),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => soundProvider.deleteMix(index),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _shuffleSounds(SoundMixerProvider soundProvider) {
    // Implement shuffle logic
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Shuffle feature coming soon!')),
    );
  }

  void _showPremiumDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Premium Sound', style: TextStyle(color: Colors.white)),
        content: Text('This sound is available for premium users only. Upgrade to unlock all premium sounds.',
            style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Maybe Later', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Navigate to subscription screen
            },
            child: Text('Upgrade Now'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> _getFilteredSounds(SoundMixerProvider soundProvider) {
    if (_selectedCategory == 'All') {
      return soundProvider.availableSounds;
    } else if (_selectedCategory == 'Favorites') {
      return soundProvider.getFavoriteSounds();
    } else {
      return soundProvider.getSoundsByCategory(_selectedCategory);
    }
  }
}