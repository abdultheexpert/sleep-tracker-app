import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/sleep_tracker_provider.dart';

class SleepTrackerScreen extends StatefulWidget {
  @override
  _SleepTrackerScreenState createState() => _SleepTrackerScreenState();
}

class _SleepTrackerScreenState extends State<SleepTrackerScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  bool _isAnalyzing = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 1500),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sleepProvider = Provider.of<SleepTrackerProvider>(context);

    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.nightlight_round, color: Colors.blueAccent, size: 24),
            SizedBox(width: 8),
            Text('Sleep Tracker', style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            )),
          ],
        ),
        backgroundColor: Color(0xFF1D1E33),
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.analytics, color: Colors.white),
            onPressed: () => _showAdvancedAnalytics(context, sleepProvider),
            tooltip: 'Advanced Analytics',
          ),
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: () => sleepProvider.refreshSleepHistory(),
            tooltip: 'Refresh Data',
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            // Enhanced Sleep Tracking Controls
            _buildTrackingControls(sleepProvider),
            SizedBox(height: 20),

            // Real-time Tracking Data with Progress
            if (sleepProvider.isTracking)
              _buildRealTimeTracking(sleepProvider),

            // Sleep Analytics Overview
            if (!sleepProvider.isTracking && sleepProvider.sleepHistory.isNotEmpty)
              _buildSleepAnalytics(sleepProvider),

            // Sleep History
            Expanded(
              child: _buildSleepHistory(sleepProvider),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTrackingControls(SleepTrackerProvider sleepProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedContainer(
                  duration: Duration(milliseconds: 500),
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: sleepProvider.isTracking ? Colors.green.withOpacity(0.2) : Colors.blueAccent.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    sleepProvider.isTracking ? Icons.nightlight : Icons.nightlight_round,
                    color: sleepProvider.isTracking ? Colors.green : Colors.blueAccent,
                    size: 24,
                  ),
                ),
                SizedBox(width: 12),
                Text(
                  sleepProvider.isTracking ? 'Sleep Tracking Active' : 'Ready to Track',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              ],
            ),
            SizedBox(height: 16),
            Text(
              sleepProvider.isTracking
                  ? 'AI is monitoring your sleep patterns with motion sensors and audio analysis...'
                  : 'Start tracking to get detailed insights into your sleep quality, stages, and patterns',
              style: TextStyle(color: Colors.white70, height: 1.4),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),

            // Enhanced Tracking Button with Animation
            AnimatedContainer(
              duration: Duration(milliseconds: 300),
              width: double.infinity,
              height: 60,
              child: ElevatedButton(
                onPressed: () async {
                  if (sleepProvider.isTracking) {
                    setState(() {
                      _isAnalyzing = true;
                    });
                    await sleepProvider.stopSleepTracking();
                    setState(() {
                      _isAnalyzing = false;
                    });
                  } else {
                    await sleepProvider.startSleepTracking();
                    _animationController.repeat();
                  }
                },
                child: _isAnalyzing
                    ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(width: 12),
                    Text('ANALYZING SLEEP DATA...', style: TextStyle(fontWeight: FontWeight.bold)),
                  ],
                )
                    : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(sleepProvider.isTracking ? Icons.stop : Icons.play_arrow, size: 20),
                    SizedBox(width: 8),
                    Text(
                      sleepProvider.isTracking ? 'STOP TRACKING' : 'START SLEEP TRACKING',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ],
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: sleepProvider.isTracking ? Colors.red : Colors.blueAccent,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 4,
                ),
              ),
            ),

            SizedBox(height: 12),
            if (sleepProvider.isTracking) ...[
              LinearProgressIndicator(
                value: sleepProvider.trackingProgress,
                backgroundColor: Colors.white24,
                color: Colors.blueAccent,
                minHeight: 6,
                borderRadius: BorderRadius.circular(3),
              ),
              SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Tracking Progress',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  Text(
                    '${(sleepProvider.trackingProgress * 100).toStringAsFixed(1)}%',
                    style: TextStyle(color: Colors.blueAccent, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildRealTimeTracking(SleepTrackerProvider sleepProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.insights, color: Colors.blueAccent, size: 20),
                SizedBox(width: 8),
                Text('Live Tracking Data', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.green),
                  ),
                  child: Text(
                    'LIVE',
                    style: TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),

            // Real-time Stats Grid
            GridView.count(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              crossAxisCount: 3,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              children: [
                _buildLiveStat('Duration', _formatDuration(sleepProvider.currentTrackingDuration), Icons.timer, Colors.blueAccent),
                _buildLiveStat('Sleep Stage', sleepProvider.currentSleepStage.toUpperCase(), Icons.hotel, _getStageColor(sleepProvider.currentSleepStage)),
                _buildLiveStat('Events', '${sleepProvider.sleepEvents.length}', Icons.notifications, Colors.orange),
                _buildLiveStat('Movement', '${_getMovementLevel(sleepProvider)}', Icons.directions_walk, Colors.green),
                _buildLiveStat('Sound Level', '${_getSoundLevel(sleepProvider)}', Icons.volume_up, Colors.purple),
                _buildLiveStat('Quality', '${_getLiveQuality(sleepProvider)}', Icons.assessment, Colors.amber),
              ],
            ),

            SizedBox(height: 16),

            // Recent Events with Enhanced UI
            if (sleepProvider.sleepEvents.isNotEmpty) ...[
              Divider(color: Colors.white30, height: 20),
              Text('Recent Sleep Events', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              SizedBox(height: 12),
              Container(
                height: 120,
                child: ListView.builder(
                  itemCount: sleepProvider.sleepEvents.length,
                  itemBuilder: (context, index) {
                    final event = sleepProvider.sleepEvents[index];
                    return _buildEventItem(event);
                  },
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSleepAnalytics(SleepTrackerProvider sleepProvider) {
    final stats = sleepProvider.getSleepStats();

    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.analytics, color: Colors.blueAccent, size: 20),
                SizedBox(width: 8),
                Text('Sleep Analytics', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                Spacer(),
                if (stats.isNotEmpty)
                  Chip(
                    label: Text('${stats['totalSessions']} sessions', style: TextStyle(color: Colors.white, fontSize: 12)),
                    backgroundColor: Colors.blueAccent,
                  ),
              ],
            ),
            SizedBox(height: 16),

            if (stats.isNotEmpty) ...[
              GridView.count(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                children: [
                  _buildAnalyticStat('Avg. Duration', _formatDuration(stats['avgDuration'] ?? Duration.zero), Icons.timer, Colors.blueAccent),
                  _buildAnalyticStat('Avg. Score', '${stats['avgScore']?.round() ?? 0}', Icons.assessment, Colors.green),
                  _buildAnalyticStat('Best Score', '${stats['bestScore'] ?? 0}', Icons.emoji_events, Colors.amber),
                  _buildAnalyticStat('Total Sleep', _formatDuration(stats['totalSleepTime'] ?? Duration.zero), Icons.nightlight_round, Colors.purple),
                ],
              ),
            ] else ...[
              Container(
                padding: EdgeInsets.symmetric(vertical: 40),
                child: Column(
                  children: [
                    Icon(Icons.analytics_outlined, size: 80, color: Colors.white30),
                    SizedBox(height: 16),
                    Text(
                      'Start tracking to see your sleep analytics',
                      style: TextStyle(color: Colors.white70, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSleepHistory(SleepTrackerProvider sleepProvider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(bottom: 16),
          child: Row(
            children: [
              Text('Sleep History', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              Spacer(),
              if (sleepProvider.sleepHistory.isNotEmpty)
                TextButton(
                  onPressed: () => _showAllSessions(context, sleepProvider),
                  child: Text('View All', style: TextStyle(color: Colors.blueAccent)),
                ),
            ],
          ),
        ),
        Expanded(
          child: sleepProvider.sleepHistory.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
            itemCount: sleepProvider.sleepHistory.length,
            itemBuilder: (context, index) {
              final session = sleepProvider.sleepHistory[index];
              return _buildSessionCard(session);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildLiveStat(String label, String value, IconData icon, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            SizedBox(height: 8),
            Text(value, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white)),
            SizedBox(height: 4),
            Text(label, style: TextStyle(fontSize: 10, color: Colors.white70), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalyticStat(String label, String value, IconData icon, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 24),
            SizedBox(height: 8),
            Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
            SizedBox(height: 4),
            Text(label, style: TextStyle(fontSize: 12, color: Colors.white70), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _buildEventItem(Map<String, dynamic> event) {
    return Container(
      margin: EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _getEventColor(event['type']).withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: _getEventColor(event['type']).withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _getEventColor(event['type']).withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(_getEventIcon(event['type']), color: _getEventColor(event['type']), size: 16),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  event['type'].toString().toUpperCase(),
                  style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 2),
                Text(
                  event['description'] ?? 'Event detected',
                  style: TextStyle(color: Colors.white70, fontSize: 10),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          SizedBox(width: 8),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: _getEventColor(event['type']).withOpacity(0.2),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              '${event['confidence'] ?? 0}%',
              style: TextStyle(color: _getEventColor(event['type']), fontSize: 10, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSessionCard(Map<String, dynamic> session) {
    final score = session['sleepScore'] ?? 0;
    final startTime = session['startTime'] is DateTime ? session['startTime'] : DateTime.parse(session['startTime'].toString());

    return Card(
      color: Color(0xFF1D1E33),
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_getScoreColor(score), _getScoreColor(score).withOpacity(0.7)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              '$score',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ),
        title: Text(
          _formatDuration(session['duration'] ?? Duration.zero),
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${_getSleepScoreDescription(score)} • ${_formatDate(startTime)}',
              style: TextStyle(color: Colors.white70),
            ),
            SizedBox(height: 4),
            Row(
              children: [
                _buildMiniStage('Deep', session['deepSleep'] ?? Duration.zero, session['duration'] ?? Duration.zero),
                SizedBox(width: 4),
                _buildMiniStage('Light', session['lightSleep'] ?? Duration.zero, session['duration'] ?? Duration.zero),
                SizedBox(width: 4),
                _buildMiniStage('REM', session['remSleep'] ?? Duration.zero, session['duration'] ?? Duration.zero),
              ],
            ),
          ],
        ),
        trailing: Icon(Icons.arrow_forward_ios, size: 16, color: Colors.white54),
        onTap: () {
          _showSleepSessionDetails(context, session);
        },
      ),
    );
  }

  Widget _buildMiniStage(String stage, Duration duration, Duration totalDuration) {
    final percentage = totalDuration.inMinutes > 0 ? (duration.inMinutes / totalDuration.inMinutes * 100).round() : 0;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: _getStageColor(stage.toLowerCase()).withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: _getStageColor(stage.toLowerCase()).withOpacity(0.5)),
      ),
      child: Text(
        '$stage ${percentage}%',
        style: TextStyle(
          color: _getStageColor(stage.toLowerCase()),
          fontSize: 8,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.nightlight_round, size: 80, color: Colors.white30),
          SizedBox(height: 20),
          Text(
            'No Sleep Data Yet',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(
            'Start tracking your sleep to see detailed\nanalytics and insights here',
            style: TextStyle(color: Colors.white70, fontSize: 14),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              final sleepProvider = Provider.of<SleepTrackerProvider>(context, listen: false);
              sleepProvider.startSleepTracking();
            },
            child: Text('START YOUR FIRST SESSION'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  void _showSleepSessionDetails(BuildContext context, Map<String, dynamic> session) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.85,
        decoration: BoxDecoration(
          color: Color(0xFF1D1E33),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white30,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Text('Sleep Session Analysis', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
              SizedBox(height: 20),
              Expanded(
                child: _buildSessionDetailsContent(session),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSessionDetailsContent(Map<String, dynamic> session) {
    final sleepReport = session['sleepReport'] ?? {};
    final eventsSummary = sleepReport['eventsSummary'] ?? {'snoring': 0, 'coughing': 0, 'talking': 0, 'movement': 0};

    return SingleChildScrollView(
      child: Column(
        children: [
          // Sleep Stages Chart - SIMPLIFIED VERSION
          Container(
            height: 200,
            child: _buildCustomSleepChart(session),
          ),
          SizedBox(height: 20),

          // Sleep Metrics
          GridView.count(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            children: [
              _buildDetailMetric('Total Duration', _formatDuration(session['duration'] ?? Duration.zero), Icons.timer),
              _buildDetailMetric('Sleep Score', '${session['sleepScore'] ?? 0}', Icons.assessment),
              _buildDetailMetric('Sleep Efficiency', '${((session['sleepEfficiency'] ?? 0) * 100).toStringAsFixed(1)}%', Icons.trending_up),
              _buildDetailMetric('Time to Fall Asleep', '~15 min', Icons.hourglass_bottom),
            ],
          ),

          SizedBox(height: 20),

          // Sleep Events Summary
          Text('Sleep Events Summary', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
          SizedBox(height: 12),
          GridView.count(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            children: [
              _buildEventMetric('Snoring', eventsSummary['snoring']?.toString() ?? '0', Icons.volume_up),
              _buildEventMetric('Coughing', eventsSummary['coughing']?.toString() ?? '0', Icons.medical_services),
              _buildEventMetric('Talking', eventsSummary['talking']?.toString() ?? '0', Icons.record_voice_over),
              _buildEventMetric('Movement', eventsSummary['movement']?.toString() ?? '0', Icons.directions_walk),
            ],
          ),

          SizedBox(height: 20),

          // Recommendations
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blueAccent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.blueAccent.withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Sleep Recommendations', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                SizedBox(height: 8),
                ..._generateRecommendations(session).map((recommendation) => Padding(
                  padding: EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.check_circle, color: Colors.green, size: 16),
                      SizedBox(width: 8),
                      Expanded(child: Text(recommendation, style: TextStyle(color: Colors.white70, fontSize: 14))),
                    ],
                  ),
                )).toList(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // CUSTOM SLEEP CHART WITHOUT EXTERNAL DEPENDENCIES
  Widget _buildCustomSleepChart(Map<String, dynamic> session) {
    final deepMinutes = (session['deepSleep'] ?? Duration.zero).inMinutes;
    final lightMinutes = (session['lightSleep'] ?? Duration.zero).inMinutes;
    final remMinutes = (session['remSleep'] ?? Duration.zero).inMinutes;
    final awakeMinutes = (session['awakeTime'] ?? Duration.zero).inMinutes;

    final totalMinutes = deepMinutes + lightMinutes + remMinutes + awakeMinutes;
    if (totalMinutes == 0) return Container();

    return Column(
      children: [
        Text('Sleep Stages Distribution', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
        SizedBox(height: 16),
        Expanded(
          child: Row(
            children: [
              _buildChartBar('Deep', deepMinutes, totalMinutes, Colors.purpleAccent),
              SizedBox(width: 4),
              _buildChartBar('Light', lightMinutes, totalMinutes, Colors.blueAccent),
              SizedBox(width: 4),
              _buildChartBar('REM', remMinutes, totalMinutes, Colors.greenAccent),
              SizedBox(width: 4),
              _buildChartBar('Awake', awakeMinutes, totalMinutes, Colors.orangeAccent),
            ],
          ),
        ),
        SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildChartLegend('Deep', Colors.purpleAccent),
            _buildChartLegend('Light', Colors.blueAccent),
            _buildChartLegend('REM', Colors.greenAccent),
            _buildChartLegend('Awake', Colors.orangeAccent),
          ],
        ),
      ],
    );
  }

  Widget _buildChartBar(String label, int value, int total, Color color) {
    final percentage = total > 0 ? value / total : 0.0; // Changed to 0.0 instead of 0
    return Expanded(
      child: Column(
        children: [
          Expanded(
            child: Container(
              width: double.infinity,
              child: FractionallySizedBox(
                heightFactor: percentage, // This now accepts the double value
                child: Container(
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(4)),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 4),
          Text(
            '${(percentage * 100).round()}%',
            style: TextStyle(color: Colors.white70, fontSize: 10),
          ),
          Text(
            label,
            style: TextStyle(color: Colors.white70, fontSize: 10),
          ),
        ],
      ),
    );
  }

  Widget _buildChartLegend(String label, Color color) {
    return Row(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        SizedBox(width: 4),
        Text(label, style: TextStyle(color: Colors.white70, fontSize: 10)),
      ],
    );
  }

  Widget _buildDetailMetric(String label, String value, IconData icon) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.blueAccent, size: 24),
          SizedBox(height: 8),
          Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
          SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 12, color: Colors.white70), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildEventMetric(String label, String value, IconData icon) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _getEventColor(label.toLowerCase()).withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: _getEventColor(label.toLowerCase()).withOpacity(0.3)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: _getEventColor(label.toLowerCase()), size: 20),
          SizedBox(height: 8),
          Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
          SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 12, color: Colors.white70)),
        ],
      ),
    );
  }

  void _showAdvancedAnalytics(BuildContext context, SleepTrackerProvider sleepProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Advanced Analytics', style: TextStyle(color: Colors.white)),
        content: Text('Advanced sleep analytics with trends and patterns coming soon!', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK', style: TextStyle(color: Colors.blueAccent)),
          ),
        ],
      ),
    );
  }

  void _showAllSessions(BuildContext context, SleepTrackerProvider sleepProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('All Sleep Sessions', style: TextStyle(color: Colors.white)),
        content: Container(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: sleepProvider.sleepHistory.length,
            itemBuilder: (context, index) {
              final session = sleepProvider.sleepHistory[index];
              return _buildSessionCard(session);
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close', style: TextStyle(color: Colors.blueAccent)),
          ),
        ],
      ),
    );
  }

  // IMPLEMENTED HELPER METHODS
  String _getMovementLevel(SleepTrackerProvider sleepProvider) {
    if (!sleepProvider.isTracking) return 'N/A';
    final movementEvents = sleepProvider.sleepEvents.where((e) => e['type'] == 'movement').length;
    if (movementEvents > 10) return 'High';
    if (movementEvents > 5) return 'Medium';
    return 'Low';
  }

  String _getSoundLevel(SleepTrackerProvider sleepProvider) {
    if (!sleepProvider.isTracking) return 'N/A';
    final soundEvents = sleepProvider.sleepEvents.where((e) =>
    e['type'] == 'snoring' || e['type'] == 'coughing' || e['type'] == 'talking').length;
    if (soundEvents > 8) return 'Loud';
    if (soundEvents > 4) return 'Moderate';
    return 'Quiet';
  }

  String _getLiveQuality(SleepTrackerProvider sleepProvider) {
    if (!sleepProvider.isTracking) return 'N/A';

    final movementLevel = _getMovementLevel(sleepProvider);
    final soundLevel = _getSoundLevel(sleepProvider);

    if (movementLevel == 'High' || soundLevel == 'Loud') return 'Poor';
    if (movementLevel == 'Medium' || soundLevel == 'Moderate') return 'Fair';
    return 'Good';
  }

  Color _getStageColor(String stage) {
    switch (stage) {
      case 'deep': return Colors.purpleAccent;
      case 'light': return Colors.blueAccent;
      case 'rem': return Colors.greenAccent;
      case 'awake': return Colors.orangeAccent;
      default: return Colors.grey;
    }
  }

  IconData _getEventIcon(String eventType) {
    switch (eventType) {
      case 'snoring': return Icons.volume_up;
      case 'coughing': return Icons.medical_services;
      case 'talking': return Icons.record_voice_over;
      case 'movement': return Icons.directions_walk;
      default: return Icons.notifications;
    }
  }

  Color _getEventColor(String eventType) {
    switch (eventType) {
      case 'snoring': return Colors.orange;
      case 'coughing': return Colors.red;
      case 'talking': return Colors.blue;
      case 'movement': return Colors.green;
      default: return Colors.grey;
    }
  }

  Color _getScoreColor(int score) {
    if (score >= 80) return Colors.green;
    if (score >= 60) return Colors.orange;
    return Colors.red;
  }

  String _getSleepScoreDescription(int score) {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Good';
    if (score >= 70) return 'Fair';
    if (score >= 60) return 'Poor';
    return 'Very Poor';
  }

  List<String> _generateRecommendations(Map<String, dynamic> session) {
    final score = session['sleepScore'] ?? 0;
    final recommendations = <String>[];

    if (score < 70) {
      recommendations.add('Try to maintain a consistent sleep schedule');
    }
    if ((session['deepSleep'] ?? Duration.zero).inMinutes < 60) {
      recommendations.add('Create a darker, cooler sleep environment for deeper sleep');
    }
    if ((session['awakeTime'] ?? Duration.zero).inMinutes > 30) {
      recommendations.add('Reduce screen time 1 hour before bed');
    }

    if (recommendations.isEmpty) {
      recommendations.add('Great sleep! Keep maintaining your healthy sleep habits');
    }

    return recommendations;
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    return '${hours}h ${minutes}m';
  }

  String _formatDate(DateTime date) {
    return '${date.month}/${date.day}/${date.year}';
  }
}