import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'login_screen.dart';
import 'dashboard_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isCheckingAuth = true;
  bool _hasError = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _checkAuthenticationStatus();
  }

  Future<void> _checkAuthenticationStatus() async {
    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);

      // Check authentication status
      await authProvider.checkAuthenticationStatus();

      // Add a small delay for better UX (only if authentication was fast)
      await Future.delayed(Duration(milliseconds: 1000));

      if (mounted) {
        setState(() {
          _isCheckingAuth = false;
        });
      }
    } catch (e) {
      print('❌ Error checking authentication: $e');
      if (mounted) {
        setState(() {
          _isCheckingAuth = false;
          _hasError = true;
          _errorMessage = 'Failed to check authentication status';
        });
      }
    }
  }

  void _retryAuthentication() {
    setState(() {
      _isCheckingAuth = true;
      _hasError = false;
      _errorMessage = null;
    });
    _checkAuthenticationStatus();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    // Show splash screen while checking authentication
    if (_isCheckingAuth) {
      return _SplashScreen();
    }

    // Show error screen if authentication check failed
    if (_hasError) {
      return _buildErrorScreen();
    }

    // Return appropriate screen based on authentication status
    return authProvider.isLoggedIn ? DashboardScreen() : LoginScreen();
  }

  Widget _buildErrorScreen() {
    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.error_outline,
                size: 80,
                color: Colors.redAccent,
              ),
              SizedBox(height: 24),
              Text(
                'Connection Error',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 16),
              Text(
                _errorMessage ?? 'Unable to connect to authentication service',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white70,
                ),
              ),
              SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                    onPressed: _retryAuthentication,
                    icon: Icon(Icons.refresh),
                    label: Text('Retry'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueAccent,
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    ),
                  ),
                  SizedBox(width: 16),
                  TextButton.icon(
                    onPressed: () {
                      // Continue as guest
                      final authProvider = Provider.of<AuthProvider>(context, listen: false);
                      authProvider.loginAsGuest();
                    },
                    icon: Icon(Icons.person_outline),
                    label: Text('Continue as Guest'),
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.white70,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Animated Logo with pulse effect
            _buildAnimatedLogo(),
            SizedBox(height: 30),

            // App Name with Typing Animation
            _buildAppName(),
            SizedBox(height: 10),

            // Tagline
            _buildTagline(),
            SizedBox(height: 40),

            // Loading Indicator
            _buildLoadingIndicator(),
            SizedBox(height: 20),

            // Loading Text
            _buildLoadingText(),

            // Version Info
            _buildVersionInfo(),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimatedLogo() {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 2000),
      tween: Tween<double>(begin: 0.8, end: 1.0),
      builder: (context, double value, child) {
        return Transform.scale(
          scale: value,
          child: Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: RadialGradient(
                colors: [
                  Colors.blueAccent.withOpacity(0.3),
                  Colors.transparent,
                ],
                radius: 1.0,
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.nightlight_round,
              size: 100,
              color: Colors.blueAccent,
            ),
          ),
        );
      },
    );
  }

  Widget _buildAppName() {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 800),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, (1 - value) * 20),
            child: child,
          ),
        );
      },
      child: Text(
        'Sleep Tracker Pro',
        style: TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.bold,
          color: Colors.white,
          letterSpacing: 1.1,
        ),
      ),
    );
  }

  Widget _buildTagline() {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 800),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, (1 - value) * 10),
            child: child,
          ),
        );
      },
      child: Text(
        'Better Sleep Starts Here',
        style: TextStyle(
          fontSize: 16,
          color: Colors.white70,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    return SizedBox(
      width: 40,
      height: 40,
      child: CircularProgressIndicator(
        strokeWidth: 3,
        valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent),
        backgroundColor: Colors.blueAccent.withOpacity(0.2),
      ),
    );
  }

  Widget _buildLoadingText() {
    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 1500),
      tween: Tween<double>(begin: 0.3, end: 1.0),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: child,
        );
      },
      child: Text(
        'Loading...',
        style: TextStyle(
          color: Colors.white54,
          fontSize: 14,
        ),
      ),
    );
  }

  Widget _buildVersionInfo() {
    return Container(
      margin: EdgeInsets.only(top: 50),
      child: Text(
        'Version 1.0.0',
        style: TextStyle(
          color: Colors.white30,
          fontSize: 12,
        ),
      ),
    );
  }
}