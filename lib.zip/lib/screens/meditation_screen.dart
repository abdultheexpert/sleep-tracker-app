import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:audioplayers/audioplayers.dart';
import '../providers/content_provider.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';

class MeditationScreen extends StatefulWidget {
  @override
  _MeditationScreenState createState() => _MeditationScreenState();
}

class _MeditationScreenState extends State<MeditationScreen> with SingleTickerProviderStateMixin {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isPlaying = false;
  String? _currentPlayingId;
  late TabController _tabController;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _setupAudioPlayer();
    _loadContentFromBackend();
  }

  void _setupAudioPlayer() {
    _audioPlayer.onPlayerStateChanged.listen((state) {
      setState(() {
        _isPlaying = state == PlayerState.playing;
      });
    });

    _audioPlayer.onPlayerComplete.listen((event) {
      setState(() {
        _isPlaying = false;
        _currentPlayingId = null;
      });
    });
  }

  Future<void> _loadContentFromBackend() async {
    try {
      final contentProvider = Provider.of<ContentProvider>(context, listen: false);

      // Use the content provider's sync method
      await contentProvider.syncWithBackend();

    } catch (e) {
      print('Error loading content from backend: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final contentProvider = Provider.of<ContentProvider>(context);
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.self_improvement, color: Colors.purpleAccent, size: 24),
            SizedBox(width: 8),
            Text('Meditation & Content', style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            )),
          ],
        ),
        backgroundColor: Color(0xFF1D1E33),
        elevation: 0,
        actions: [
          // Daily Affirmation Button
          IconButton(
            icon: Stack(
              children: [
                Icon(Icons.lightbulb_outline, color: Colors.amber),
                Positioned(
                  right: 0,
                  top: 0,
                  child: Container(
                    padding: EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      shape: BoxShape.circle,
                    ),
                    child: Text('365', style: TextStyle(
                      color: Colors.black,
                      fontSize: 6,
                      fontWeight: FontWeight.bold,
                    )),
                  ),
                ),
              ],
            ),
            onPressed: () => _showDailyAffirmation(context, contentProvider),
            tooltip: 'Daily Affirmation',
          ),
        ],
      ),
      body: _isLoading
          ? _buildLoadingIndicator()
          : Column(
        children: [
          // Enhanced Tab Bar
          Container(
            decoration: BoxDecoration(
              color: Color(0xFF1D1E33),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
            child: TabBar(
              controller: _tabController,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              indicatorColor: Colors.purpleAccent,
              indicatorWeight: 3,
              indicatorPadding: EdgeInsets.symmetric(horizontal: 20),
              labelStyle: TextStyle(fontWeight: FontWeight.bold),
              tabs: [
                Tab(icon: Icon(Icons.self_improvement, size: 20), text: 'Meditations'),
                Tab(icon: Icon(Icons.menu_book, size: 20), text: 'Stories'),
                Tab(icon: Icon(Icons.music_note, size: 20), text: 'Music'),
                Tab(icon: Icon(Icons.videocam, size: 20), text: 'Videos'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildContentList(context, contentProvider.meditations, authProvider, 'meditation'),
                _buildContentList(context, contentProvider.stories, authProvider, 'story'),
                _buildContentList(context, contentProvider.music, authProvider, 'music'),
                _buildVideoList(context, contentProvider.videos, authProvider),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: Colors.purpleAccent),
          SizedBox(height: 16),
          Text(
            'Loading Content...',
            style: TextStyle(color: Colors.white70, fontSize: 16),
          ),
        ],
      ),
    );
  }

  Widget _buildContentList(BuildContext context, List<Map<String, dynamic>> content, AuthProvider authProvider, String type) {
    if (content.isEmpty) {
      return _buildEmptyState(type);
    }

    return RefreshIndicator(
      backgroundColor: Color(0xFF1D1E33),
      color: Colors.purpleAccent,
      onRefresh: () => _loadContentFromBackend(),
      child: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: content.length,
        itemBuilder: (context, index) {
          final item = content[index];
          final isLocked = item['isPremium'] == true && !authProvider.isPremium;
          final isCurrentlyPlaying = _currentPlayingId == item['id'] && _isPlaying;

          return _buildContentCard(item, type, isLocked, isCurrentlyPlaying, authProvider);
        },
      ),
    );
  }

  Widget _buildContentCard(Map<String, dynamic> item, String type, bool isLocked, bool isCurrentlyPlaying, AuthProvider authProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      margin: EdgeInsets.only(bottom: 12),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _handleContentTap(context, item, type, authProvider),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              // Content Icon with Animation
              AnimatedContainer(
                duration: Duration(milliseconds: 300),
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _getColorForType(type).withOpacity(0.3),
                      _getColorForType(type).withOpacity(0.1),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _getColorForType(type).withOpacity(0.5)),
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(_getIconForType(type), color: _getColorForType(type), size: 24),
                    if (isCurrentlyPlaying)
                      Icon(Icons.equalizer, color: _getColorForType(type), size: 16),
                  ],
                ),
              ),
              SizedBox(width: 16),

              // Content Details
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            item['title'] ?? 'Untitled',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (isLocked) ...[
                          SizedBox(width: 8),
                          Container(
                            padding: EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: Colors.amber.withOpacity(0.2),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(Icons.lock, color: Colors.amber, size: 14),
                          ),
                        ],
                      ],
                    ),
                    SizedBox(height: 4),
                    Text(
                      item['description'] ?? 'Relax and unwind with this content',
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.schedule, color: Colors.white54, size: 12),
                        SizedBox(width: 4),
                        Text(
                          item['duration'] ?? '10 min',
                          style: TextStyle(color: Colors.white54, fontSize: 12),
                        ),
                        SizedBox(width: 12),
                        Icon(Icons.person, color: Colors.white54, size: 12),
                        SizedBox(width: 4),
                        Text(
                          item['instructor'] ?? item['narrator'] ?? item['artist'] ?? 'Unknown',
                          style: TextStyle(color: Colors.white54, fontSize: 12),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Play Button
              SizedBox(width: 12),
              _buildPlayButton(item, type, isLocked, isCurrentlyPlaying, authProvider),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPlayButton(Map<String, dynamic> item, String type, bool isLocked, bool isCurrentlyPlaying, AuthProvider authProvider) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      decoration: BoxDecoration(
        color: isCurrentlyPlaying
            ? _getColorForType(type).withOpacity(0.3)
            : _getColorForType(type).withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isCurrentlyPlaying
              ? _getColorForType(type)
              : Colors.transparent,
          width: 2,
        ),
      ),
      child: IconButton(
        icon: Icon(
          isCurrentlyPlaying ? Icons.pause : Icons.play_arrow,
          color: _getColorForType(type),
          size: 24,
        ),
        onPressed: () => _handleContentTap(context, item, type, authProvider),
      ),
    );
  }

  Widget _buildVideoList(BuildContext context, List<Map<String, dynamic>> videos, AuthProvider authProvider) {
    if (videos.isEmpty) {
      return _buildEmptyState('video');
    }

    return RefreshIndicator(
      backgroundColor: Color(0xFF1D1E33),
      color: Colors.redAccent,
      onRefresh: () => _loadContentFromBackend(),
      child: GridView.builder(
        padding: EdgeInsets.all(16),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.8,
        ),
        itemCount: videos.length,
        itemBuilder: (context, index) {
          final video = videos[index];
          final isLocked = video['isPremium'] == true && !authProvider.isPremium;

          return _buildVideoCard(video, isLocked, authProvider);
        },
      ),
    );
  }

  Widget _buildVideoCard(Map<String, dynamic> video, bool isLocked, AuthProvider authProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _playVideoContent(context, video, authProvider),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Video Thumbnail
            Expanded(
              flex: 3,
              child: Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                      color: Colors.black26,
                      image: video['thumbnail'] != null ? DecorationImage(
                        image: AssetImage(video['thumbnail']!),
                        fit: BoxFit.cover,
                      ) : null,
                    ),
                    child: video['thumbnail'] == null ? Center(
                      child: Icon(Icons.videocam, size: 40, color: Colors.white30),
                    ) : null,
                  ),
                  if (isLocked)
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        padding: EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.lock, color: Colors.amber, size: 16),
                      ),
                    ),
                  Positioned.fill(
                    child: Center(
                      child: Container(
                        padding: EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.play_arrow, color: Colors.white, size: 24),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Video Info
            Expanded(
              flex: 2,
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      video['title'] ?? 'Untitled Video',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 4),
                    Text(
                      video['description'] ?? 'Watch this video content',
                      style: TextStyle(color: Colors.white70, fontSize: 10),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Spacer(),
                    Row(
                      children: [
                        Icon(Icons.schedule, color: Colors.white54, size: 10),
                        SizedBox(width: 4),
                        Text(
                          video['duration'] ?? '10 min',
                          style: TextStyle(color: Colors.white54, fontSize: 10),
                        ),
                        Spacer(),
                        if (isLocked)
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.amber.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              'PREMIUM',
                              style: TextStyle(color: Colors.amber, fontSize: 8, fontWeight: FontWeight.bold),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(String type) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(_getIconForType(type), size: 80, color: Colors.white30),
          SizedBox(height: 16),
          Text(
            'No ${type}s Available',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(
            _getEmptyStateMessage(type),
            style: TextStyle(color: Colors.white70, fontSize: 14),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: _loadContentFromBackend,
            child: Text('Refresh Content'),
            style: ElevatedButton.styleFrom(
              backgroundColor: _getColorForType(type),
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  String _getEmptyStateMessage(String type) {
    switch (type) {
      case 'meditation': return 'Check back later for new guided meditations';
      case 'story': return 'New bedtime stories coming soon';
      case 'music': return 'Relaxing music will be available shortly';
      case 'video': return 'Video content will be added in the next update';
      default: return 'Content coming soon';
    }
  }

  void _handleContentTap(BuildContext context, Map<String, dynamic> item, String type, AuthProvider authProvider) {
    if (item['isPremium'] == true && !authProvider.isPremium) {
      _showPremiumDialog(context);
      return;
    }

    if (type == 'video') {
      _playVideoContent(context, item, authProvider);
    } else {
      _playAudioContent(context, item, type, authProvider);
    }
  }

  Future<void> _playAudioContent(BuildContext context, Map<String, dynamic> item, String type, AuthProvider authProvider) async {
    if (_currentPlayingId == item['id'] && _isPlaying) {
      await _audioPlayer.pause();
      return;
    }

    // Stop current playback
    if (_isPlaying) {
      await _audioPlayer.stop();
    }

    // For now, skip ads - you can add them back later
    _startAudioPlayback(item);
  }

  Future<void> _startAudioPlayback(Map<String, dynamic> item) async {
    try {
      // Use actual audio URL from backend or fallback to local asset
      String audioUrl = item['file'] ?? item['audioUrl'] ?? 'assets/sounds/meditation/sample.mp3';

      // Check if it's a local asset or network URL
      if (audioUrl.startsWith('assets/')) {
        await _audioPlayer.play(AssetSource(audioUrl));
      } else {
        await _audioPlayer.play(UrlSource(audioUrl));
      }

      setState(() {
        _currentPlayingId = item['id'];
        _isPlaying = true;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('🎵 Now playing: ${item['title']}'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );

    } catch (e) {
      print('Error playing audio: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error playing audio. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _playVideoContent(BuildContext context, Map<String, dynamic> video, AuthProvider authProvider) {
    if (video['isPremium'] == true && !authProvider.isPremium) {
      _showPremiumDialog(context);
      return;
    }

    // For now, skip ads and video player - show message
    _showVideoNotAvailable(context, video);
  }

  void _showVideoNotAvailable(BuildContext context, Map<String, dynamic> video) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Video player will be available in the next update'),
        backgroundColor: Colors.orange,
        duration: Duration(seconds: 3),
      ),
    );
  }

  void _showDailyAffirmation(BuildContext context, ContentProvider contentProvider) {
    final affirmation = contentProvider.dailyAffirmation;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.lightbulb, color: Colors.amber),
            SizedBox(width: 8),
            Text('Daily Affirmation', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(affirmation, style: TextStyle(color: Colors.white70, fontSize: 16, height: 1.4)),
            SizedBox(height: 16),
            Text('Day ${_getCurrentDay()} of 365',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close', style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () {
              contentProvider.nextAffirmation();
              Navigator.pop(context);
            },
            child: Text('Next', style: TextStyle(color: Colors.amber)),
          ),
        ],
      ),
    );
  }

  int _getCurrentDay() {
    final now = DateTime.now();
    final startOfYear = DateTime(now.year, 1, 1);
    return now.difference(startOfYear).inDays + 1;
  }

  void _showPremiumDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Premium Content', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: Text(
          'This content is available for premium users only. Upgrade to unlock all features and remove ads.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Maybe Later', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showSubscriptionOptions(context);
            },
            child: Text('Upgrade Now'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  void _showSubscriptionOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: BoxDecoration(
          color: Color(0xFF1D1E33),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white30,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Text('Choose Your Plan', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
              SizedBox(height: 10),
              Text('Unlock all premium features and content', style: TextStyle(color: Colors.white70, fontSize: 14)),
              SizedBox(height: 20),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildSubscriptionOption('Monthly', '\$9.99/month', '7-day free trial', Icons.calendar_today),
                      _buildSubscriptionOption('Yearly', '\$59.99/year', 'Save 50%', Icons.verified_user, isPopular: true),
                      _buildSubscriptionOption('Lifetime', '\$149.99', 'One-time payment', Icons.workspace_premium),
                      SizedBox(height: 20),
                      Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Premium Features:', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                            SizedBox(height: 8),
                            _buildFeatureItem('✓ Unlimited access to all content'),
                            _buildFeatureItem('✓ No advertisements'),
                            _buildFeatureItem('✓ Offline downloads'),
                            _buildFeatureItem('✓ Priority support'),
                            _buildFeatureItem('✓ Exclusive premium content'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    final authProvider = Provider.of<AuthProvider>(context, listen: false);
                    authProvider.upgradeToPremium();
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('🎉 Welcome to Premium! All features unlocked.'),
                        backgroundColor: Colors.green,
                        duration: Duration(seconds: 3),
                      ),
                    );
                  },
                  child: Text('Start Free Trial', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              SizedBox(height: 10),
              Center(
                child: Text('Cancel anytime • No commitment', style: TextStyle(color: Colors.white54, fontSize: 12)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSubscriptionOption(String period, String price, String savings, IconData icon, {bool isPopular = false}) {
    return Card(
      color: isPopular ? Colors.blueAccent.withOpacity(0.2) : Color(0xFF2A2B3D),
      margin: EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isPopular ? Colors.blueAccent : Colors.transparent,
          width: 2,
        ),
      ),
      child: ListTile(
        leading: Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.blueAccent.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: Colors.blueAccent),
        ),
        title: Row(
          children: [
            Text(period, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            if (isPopular) ...[
              SizedBox(width: 8),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text('POPULAR', style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold)),
              ),
            ],
          ],
        ),
        subtitle: Text(savings, style: TextStyle(color: Colors.white70)),
        trailing: Text(price, style: TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold, fontSize: 16)),
        onTap: () {
          print('Selected plan: $period');
        },
      ),
    );
  }

  Widget _buildFeatureItem(String text) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(Icons.check_circle, color: Colors.green, size: 16),
          SizedBox(width: 8),
          Expanded(child: Text(text, style: TextStyle(color: Colors.white70, fontSize: 14))),
        ],
      ),
    );
  }

  IconData _getIconForType(String type) {
    switch (type) {
      case 'meditation': return Icons.self_improvement;
      case 'story': return Icons.menu_book;
      case 'music': return Icons.music_note;
      case 'video': return Icons.videocam;
      default: return Icons.play_arrow;
    }
  }

  Color _getColorForType(String type) {
    switch (type) {
      case 'meditation': return Colors.purpleAccent;
      case 'story': return Colors.orangeAccent;
      case 'music': return Colors.greenAccent;
      case 'video': return Colors.redAccent;
      default: return Colors.blueAccent;
    }
  }
}