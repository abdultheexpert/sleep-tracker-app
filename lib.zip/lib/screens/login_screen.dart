import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../services/api_service.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _nameController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  bool _isLogin = true;
  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;

  @override
  void initState() {
    super.initState();
    _checkIfReturningFromSignup();
  }

  void _checkIfReturningFromSignup() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      if (authProvider.showSignupSuccess) {
        _showSuccessSnackbar('🎉 Signup successful! Please sign in.');
        authProvider.resetSignupSuccess();
        setState(() {
          _isLogin = true;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(24.0),
            child: Column(
              children: [
                // Enhanced Header Section with Animation
                _buildHeaderSection(),

                // Login/Signup Form
                _buildAuthForm(authProvider),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      height: 280,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Animated Icon
          AnimatedContainer(
            duration: Duration(milliseconds: 1000),
            curve: Curves.elasticOut,
            child: Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blueAccent, Colors.purpleAccent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.blueAccent.withOpacity(0.3),
                    blurRadius: 15,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Icon(
                Icons.nightlight_round,
                size: 60,
                color: Colors.white,
              ),
            ),
          ),
          SizedBox(height: 20),
          Text(
            'Sleep Tracker Pro',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 10),
          Text(
            '260+ Sounds • AI Sleep Detection • Meditation',
            style: TextStyle(
              fontSize: 16,
              color: Colors.white70,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.blueAccent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.blueAccent.withOpacity(0.3)),
            ),
            child: Text(
              'Like Better Sleep & Best Sleep Apps',
              style: TextStyle(
                fontSize: 14,
                color: Colors.blueAccent,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAuthForm(AuthProvider authProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 8,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          children: [
            // Form Title
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  _isLogin ? Icons.login : Icons.person_add,
                  color: Colors.blueAccent,
                  size: 28,
                ),
                SizedBox(width: 8),
                Text(
                  _isLogin ? 'Sign In' : 'Create Account',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            SizedBox(height: 30),

            // Name Field (Signup only)
            if (!_isLogin) _buildNameField(),

            // Email Field
            _buildEmailField(),

            // Password Field
            _buildPasswordField(),

            // Confirm Password Field (Signup only)
            if (!_isLogin) _buildConfirmPasswordField(),

            // Forgot Password (Login only)
            if (_isLogin) _buildForgotPassword(),

            SizedBox(height: 30),

            // Submit Button
            _buildSubmitButton(authProvider),

            SizedBox(height: 20),

            // Social Login Section
            _buildSocialLoginSection(authProvider),

            SizedBox(height: 20),

            // Guest Login
            _buildGuestLoginButton(authProvider),

            SizedBox(height: 20),

            // Toggle between Login/Signup
            _buildToggleAuthButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildNameField() {
    return TextField(
      controller: _nameController,
      style: TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: 'Full Name',
        labelStyle: TextStyle(color: Colors.white70),
        prefixIcon: Icon(Icons.person, color: Colors.white70),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white30),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.blueAccent),
        ),
        filled: true,
        fillColor: Colors.white.withOpacity(0.05),
      ),
    );
  }

  Widget _buildEmailField() {
    return Column(
      children: [
        TextField(
          controller: _emailController,
          style: TextStyle(color: Colors.white),
          keyboardType: TextInputType.emailAddress,
          decoration: InputDecoration(
            labelText: 'Email',
            labelStyle: TextStyle(color: Colors.white70),
            prefixIcon: Icon(Icons.email, color: Colors.white70),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white30),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.blueAccent),
            ),
            filled: true,
            fillColor: Colors.white.withOpacity(0.05),
          ),
        ),
        SizedBox(height: 20),
      ],
    );
  }

  Widget _buildPasswordField() {
    return Column(
      children: [
        TextField(
          controller: _passwordController,
          obscureText: _obscurePassword,
          style: TextStyle(color: Colors.white),
          decoration: InputDecoration(
            labelText: 'Password',
            labelStyle: TextStyle(color: Colors.white70),
            prefixIcon: Icon(Icons.lock, color: Colors.white70),
            suffixIcon: IconButton(
              icon: Icon(
                _obscurePassword ? Icons.visibility : Icons.visibility_off,
                color: Colors.white70,
              ),
              onPressed: () {
                setState(() {
                  _obscurePassword = !_obscurePassword;
                });
              },
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white30),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.blueAccent),
            ),
            filled: true,
            fillColor: Colors.white.withOpacity(0.05),
          ),
        ),
        SizedBox(height: 20),
      ],
    );
  }

  Widget _buildConfirmPasswordField() {
    return Column(
      children: [
        TextField(
          controller: _confirmPasswordController,
          obscureText: _obscureConfirmPassword,
          style: TextStyle(color: Colors.white),
          decoration: InputDecoration(
            labelText: 'Confirm Password',
            labelStyle: TextStyle(color: Colors.white70),
            prefixIcon: Icon(Icons.lock_outline, color: Colors.white70),
            suffixIcon: IconButton(
              icon: Icon(
                _obscureConfirmPassword ? Icons.visibility : Icons.visibility_off,
                color: Colors.white70,
              ),
              onPressed: () {
                setState(() {
                  _obscureConfirmPassword = !_obscureConfirmPassword;
                });
              },
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white30),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.blueAccent),
            ),
            filled: true,
            fillColor: Colors.white.withOpacity(0.05),
          ),
        ),
        SizedBox(height: 20),
      ],
    );
  }

  Widget _buildForgotPassword() {
    return Align(
      alignment: Alignment.centerRight,
      child: TextButton(
        onPressed: _handleForgotPassword,
        child: Text(
          'Forgot Password?',
          style: TextStyle(color: Colors.blueAccent),
        ),
      ),
    );
  }

  Widget _buildSubmitButton(AuthProvider authProvider) {
    return _isLoading
        ? Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          CircularProgressIndicator(color: Colors.blueAccent),
          SizedBox(height: 16),
          Text(
            _isLogin ? 'Signing in...' : 'Creating account...',
            style: TextStyle(color: Colors.white70),
          ),
        ],
      ),
    )
        : SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: () => _handleEmailPasswordAuth(authProvider),
        child: Text(
          _isLogin ? 'SIGN IN' : 'CREATE ACCOUNT',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blueAccent,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: 4,
          shadowColor: Colors.blueAccent.withOpacity(0.3),
        ),
      ),
    );
  }

  Widget _buildSocialLoginSection(AuthProvider authProvider) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: Divider(color: Colors.white30)),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text('Or continue with', style: TextStyle(color: Colors.white70)),
            ),
            Expanded(child: Divider(color: Colors.white30)),
          ],
        ),
        SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            SocialLoginButton(
              icon: Icons.facebook,
              color: Color(0xFF1877F2),
              onPressed: () => _handleSocialLogin('Facebook', authProvider),
              tooltip: 'Continue with Facebook',
            ),
            SocialLoginButton(
              icon: Icons.g_mobiledata,
              color: Colors.red,
              onPressed: () => _handleSocialLogin('Google', authProvider),
              tooltip: 'Continue with Google',
            ),
            SocialLoginButton(
              icon: Icons.apple,
              color: Colors.white,
              onPressed: () => _handleSocialLogin('Apple', authProvider),
              tooltip: 'Continue with Apple',
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildGuestLoginButton(AuthProvider authProvider) {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: () => _handleGuestLogin(authProvider),
        icon: Icon(Icons.person_outline, size: 20),
        label: Text(
          'CONTINUE AS GUEST',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white70,
          side: BorderSide(color: Colors.white30),
          padding: EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  Widget _buildToggleAuthButton() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          _isLogin ? 'Don\'t have an account? ' : 'Already have an account? ',
          style: TextStyle(color: Colors.white70),
        ),
        TextButton(
          onPressed: () {
            setState(() {
              _isLogin = !_isLogin;
              _clearForm();
            });
          },
          child: Text(
            _isLogin ? 'Sign Up' : 'Sign In',
            style: TextStyle(
              color: Colors.blueAccent,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }

  // ========== AUTHENTICATION HANDLERS ==========

  Future<void> _handleEmailPasswordAuth(AuthProvider authProvider) async {
    if (!_validateForm()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      bool success;
      if (_isLogin) {
        success = await authProvider.login(
          _emailController.text.trim(),
          _passwordController.text.trim(),
        );

        if (success) {
          _showSuccessSnackbar('Welcome back! 🎉');
          _navigateToDashboard();
        }
      } else {
        success = await authProvider.signUp(
          _nameController.text.trim(),
          _emailController.text.trim(),
          _passwordController.text.trim(),
        );

        if (success) {
          _showSuccessSnackbar('🎉 Account created successfully! Please sign in.');
          setState(() {
            _isLogin = true;
            _clearForm();
          });
        }
      }

      if (!success && authProvider.error != null) {
        _showErrorSnackbar(authProvider.error!);
      }
    } catch (e) {
      print('Auth error: $e');
      _showErrorSnackbar('Network error. Please check your connection.');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _handleSocialLogin(String provider, AuthProvider authProvider) async {
    setState(() {
      _isLoading = true;
    });

    try {
      // For demo purposes - generate fake user data
      final fakeEmail = '${provider.toLowerCase()}@example.com';
      final fakeName = '$provider User';

      final success = await authProvider.loginWithSocial(fakeName, fakeEmail, provider);

      if (success) {
        _showSuccessSnackbar('$provider login successful! 🎉');
        _navigateToDashboard();
      } else {
        _showErrorSnackbar('$provider login failed. Please try again.');
      }
    } catch (e) {
      print('$provider login error: $e');
      _showErrorSnackbar('$provider login failed. Please try again.');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _handleGuestLogin(AuthProvider authProvider) async {
    setState(() {
      _isLoading = true;
    });

    try {
      final success = await authProvider.loginAsGuest();

      if (success) {
        _showSuccessSnackbar('Continuing as guest. Some features are limited.');
        _navigateToDashboard();
      } else {
        _showErrorSnackbar('Guest login failed. Please try again.');
      }
    } catch (e) {
      _showErrorSnackbar('Guest login error. Please try again.');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _handleForgotPassword() async {
    if (_emailController.text.isEmpty || !_emailController.text.contains('@')) {
      _showErrorSnackbar('Please enter a valid email address');
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Reset Password', style: TextStyle(color: Colors.white)),
        content: Text(
          'Password reset feature will be available in the next update.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK', style: TextStyle(color: Colors.blueAccent)),
          ),
        ],
      ),
    );
  }

  // ========== HELPER METHODS ==========

  bool _validateForm() {
    if (!_isLogin) {
      if (_nameController.text.isEmpty) {
        _showErrorSnackbar('Please enter your name');
        return false;
      }
      if (_passwordController.text != _confirmPasswordController.text) {
        _showErrorSnackbar('Passwords do not match');
        return false;
      }
      if (_passwordController.text.length < 6) {
        _showErrorSnackbar('Password must be at least 6 characters');
        return false;
      }
    }

    if (_emailController.text.isEmpty || !_emailController.text.contains('@')) {
      _showErrorSnackbar('Please enter a valid email');
      return false;
    }

    if (_passwordController.text.isEmpty) {
      _showErrorSnackbar('Please enter password');
      return false;
    }

    return true;
  }

  void _showSuccessSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 3),
      ),
    );
  }

  void _showErrorSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: Duration(seconds: 3),
      ),
    );
  }

  void _navigateToDashboard() {
    Navigator.pushReplacementNamed(context, '/home');
  }

  void _clearForm() {
    _emailController.clear();
    _passwordController.clear();
    _nameController.clear();
    _confirmPasswordController.clear();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _nameController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }
}

class SocialLoginButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onPressed;
  final String tooltip;

  const SocialLoginButton({
    required this.icon,
    required this.color,
    required this.onPressed,
    required this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.3),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: IconButton(
          icon: Icon(icon, color: Colors.white, size: 24),
          onPressed: onPressed,
        ),
      ),
    );
  }
}