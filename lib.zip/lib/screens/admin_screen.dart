import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../providers/auth_provider.dart';

class AdminScreen extends StatefulWidget {
  @override
  _AdminScreenState createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  Map<String, dynamic> _dashboardStats = {};
  List<dynamic> _users = [];
  List<dynamic> _sounds = [];
  List<dynamic> _videos = [];
  List<dynamic> _sleepData = [];
  List<dynamic> _giftCodes = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 6, vsync: this);
    _loadAdminData();
  }

  Future<void> _loadAdminData() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      await Future.wait([
        _loadDashboardStats(),
        _loadUsers(),
        _loadSounds(),
        _loadVideos(),
        _loadSleepData(),
        _loadGiftCodes(),
      ]);
    } catch (e) {
      print('Error loading admin data: $e');
      setState(() {
        _error = 'Failed to load admin data: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _loadDashboardStats() async {
    try {
      final result = await ApiService.getDashboardStats();
      if (result['success']) {
        setState(() {
          _dashboardStats = result['data'] ?? {};
        });
      } else {
        throw Exception(result['error'] ?? 'Failed to load dashboard stats');
      }
    } catch (e) {
      print('Error loading dashboard stats: $e');
      // Fallback to demo data
      setState(() {
        _dashboardStats = {
          'totalUsers': 1250,
          'activeSubscriptions': 298,
          'totalSleepSessions': 15678,
          'todaySleepSessions': 89,
          'premiumUsers': 298,
          'monthlyRevenue': 2977.02,
        };
      });
    }
  }

  Future<void> _loadUsers() async {
    try {
      final users = await ApiService.getUsers();
      setState(() {
        _users = users;
      });
    } catch (e) {
      print('Error loading users: $e');
      // Fallback to demo data
      setState(() {
        _users = [
          {
            '_id': '1',
            'name': 'John Doe',
            'email': 'john@example.com',
            'isPremium': true,
            'joinDate': '2024-01-15',
            'source': 'demo_data'
          },
          {
            '_id': '2',
            'name': 'Sarah Smith',
            'email': 'sarah@example.com',
            'isPremium': false,
            'joinDate': '2024-01-20',
            'source': 'demo_data'
          }
        ];
      });
    }
  }

  Future<void> _loadSounds() async {
    try {
      final sounds = await ApiService.getSounds();
      setState(() {
        _sounds = sounds;
      });
    } catch (e) {
      print('Error loading sounds: $e');
      // Fallback to demo data
      setState(() {
        _sounds = [
          {
            '_id': '1',
            'name': 'Ocean Waves',
            'category': 'Nature',
            'icon': '🌊',
            'isPremium': false,
            'file': 'sounds/ocean_waves.mp3',
            'source': 'demo_data'
          },
          {
            '_id': '2',
            'name': 'Rainfall',
            'category': 'Nature',
            'icon': '🌧️',
            'isPremium': false,
            'file': 'sounds/rainfall.mp3',
            'source': 'demo_data'
          }
        ];
      });
    }
  }

  Future<void> _loadVideos() async {
    try {
      final videos = await ApiService.getVideos();
      setState(() {
        _videos = videos;
      });
    } catch (e) {
      print('Error loading videos: $e');
      // Fallback to demo data
      setState(() {
        _videos = [
          {
            '_id': '1',
            'title': 'Guided Sleep Meditation',
            'description': 'Visual journey to peaceful sleep',
            'duration': '15 min',
            'videoUrl': 'https://www.youtube.com/watch?v=inpok4MKVLM',
            'thumbnail': 'assets/images/meditation_thumb.jpg',
            'isPremium': false,
            'source': 'demo_data'
          }
        ];
      });
    }
  }

  Future<void> _loadSleepData() async {
    try {
      final sleepHistory = await ApiService.getSleepHistory();
      setState(() {
        _sleepData = sleepHistory;
      });
    } catch (e) {
      print('Error loading sleep data: $e');
      setState(() {
        _sleepData = [];
      });
    }
  }

  Future<void> _loadGiftCodes() async {
    try {
      // This would call a backend endpoint for gift codes
      // For now, using empty list as placeholder
      setState(() {
        _giftCodes = [];
      });
    } catch (e) {
      print('Error loading gift codes: $e');
      setState(() {
        _giftCodes = [];
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    // Enhanced admin check - in production, you might want more robust admin verification
    if (!authProvider.isPremium && authProvider.userEmail != 'admin@admin.com') {
      return _buildAccessDeniedScreen();
    }

    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.admin_panel_settings, color: Colors.blueAccent),
            SizedBox(width: 8),
            Text('Admin Panel', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
        backgroundColor: Color(0xFF1D1E33),
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: _loadAdminData,
            tooltip: 'Refresh Data',
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.blueAccent,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.blueAccent,
          isScrollable: true,
          tabs: [
            Tab(icon: Icon(Icons.dashboard), text: 'Dashboard'),
            Tab(icon: Icon(Icons.people), text: 'Users (${_users.length})'),
            Tab(icon: Icon(Icons.music_note), text: 'Sounds (${_sounds.length})'),
            Tab(icon: Icon(Icons.videocam), text: 'Videos (${_videos.length})'),
            Tab(icon: Icon(Icons.analytics), text: 'Analytics'),
            Tab(icon: Icon(Icons.card_giftcard), text: 'Gift Codes'),
          ],
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: Colors.blueAccent))
          : _error != null
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 64, color: Colors.red),
            SizedBox(height: 16),
            Text(
              'Error Loading Data',
              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              _error!,
              style: TextStyle(color: Colors.white70),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loadAdminData,
              child: Text('Retry'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      )
          : TabBarView(
        controller: _tabController,
        children: [
          _buildDashboardTab(),
          _buildUsersTab(),
          _buildSoundsTab(),
          _buildVideosTab(),
          _buildAnalyticsTab(),
          _buildGiftCodesTab(),
        ],
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  Widget _buildAccessDeniedScreen() {
    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.admin_panel_settings, size: 80, color: Colors.red),
            SizedBox(height: 20),
            Text(
              'Admin Access Required',
              style: TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'You need administrator privileges to access this panel',
              style: TextStyle(color: Colors.white70, fontSize: 16),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Go Back'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Quick Stats
          GridView.count(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            children: [
              _buildAdminStatCard(
                  'Total Users',
                  _dashboardStats['totalUsers']?.toString() ?? '0',
                  Icons.people,
                  Colors.blueAccent
              ),
              _buildAdminStatCard(
                  'Premium Users',
                  _dashboardStats['premiumUsers']?.toString() ?? '0',
                  Icons.verified_user,
                  Colors.green
              ),
              _buildAdminStatCard(
                  'Sleep Sessions',
                  _dashboardStats['totalSleepSessions']?.toString() ?? '0',
                  Icons.nightlight_round,
                  Colors.purpleAccent
              ),
              _buildAdminStatCard(
                  'Active Today',
                  _dashboardStats['todaySleepSessions']?.toString() ?? '0',
                  Icons.today,
                  Colors.orange
              ),
            ],
          ),
          SizedBox(height: 20),

          // Revenue Overview
          Card(
            color: Color(0xFF1D1E33),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.attach_money, color: Colors.green),
                      SizedBox(width: 8),
                      Text('Revenue Overview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                    ],
                  ),
                  SizedBox(height: 16),
                  _buildSimpleBarChart(),
                ],
              ),
            ),
          ),
          SizedBox(height: 20),

          // System Status
          Card(
            color: Color(0xFF1D1E33),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.settings, color: Colors.blueAccent),
                      SizedBox(width: 8),
                      Text('System Status', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                    ],
                  ),
                  SizedBox(height: 16),
                  _buildSystemStatus(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSystemStatus() {
    return Column(
      children: [
        _buildStatusItem('Backend API', 'Connected', Icons.check_circle, Colors.green),
        _buildStatusItem('Database', 'Online', Icons.check_circle, Colors.green),
        _buildStatusItem('AI Services', 'Active', Icons.check_circle, Colors.green),
        _buildStatusItem('File Storage', 'Operational', Icons.check_circle, Colors.green),
      ],
    );
  }

  Widget _buildStatusItem(String title, String status, IconData icon, Color color) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          SizedBox(width: 12),
          Expanded(
            child: Text(title, style: TextStyle(color: Colors.white)),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color),
            ),
            child: Text(
              status,
              style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSimpleBarChart() {
    // FIXED: Proper type handling for monthlyRevenue with explicit conversion
    double monthlyRevenue = 2977.02; // Default value

    if (_dashboardStats['monthlyRevenue'] != null) {
      final revenueData = _dashboardStats['monthlyRevenue'];
      if (revenueData is int) {
        monthlyRevenue = revenueData.toDouble();
      } else if (revenueData is double) {
        monthlyRevenue = revenueData;
      } else if (revenueData is String) {
        monthlyRevenue = double.tryParse(revenueData) ?? 2977.02;
      }
    }

    final data = [
      {'month': 'Jan', 'revenue': (monthlyRevenue * 0.8)},
      {'month': 'Feb', 'revenue': (monthlyRevenue * 0.9)},
      {'month': 'Mar', 'revenue': monthlyRevenue},
      {'month': 'Apr', 'revenue': (monthlyRevenue * 1.1)},
    ];

    final maxRevenue = data.map((e) => e['revenue'] as double).reduce((a, b) => a > b ? a : b);

    return Container(
      height: 200,
      child: Column(
        children: [
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: data.map((item) {
                final revenue = item['revenue'] as double;
                final height = maxRevenue > 0 ? (revenue / maxRevenue) * 150 : 0.0; // CHANGED: 0 to 0.0

                return Expanded(
                  child: Column(
                    children: [
                      Container(
                        height: height,
                        margin: EdgeInsets.symmetric(horizontal: 8),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.blueAccent, Colors.purpleAccent],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                          borderRadius: BorderRadius.vertical(top: Radius.circular(4)),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        item['month'] as String,
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                      Text(
                        '\$${revenue.toStringAsFixed(0)}',
                        style: TextStyle(color: Colors.white54, fontSize: 10),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUsersTab() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Search users...',
                    hintStyle: TextStyle(color: Colors.white70),
                    prefixIcon: Icon(Icons.search, color: Colors.white70),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    filled: true,
                    fillColor: Color(0xFF2A2B3D),
                  ),
                  style: TextStyle(color: Colors.white),
                  onChanged: (value) {
                    // Implement search functionality
                  },
                ),
              ),
              SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: _showAddUserDialog,
                icon: Icon(Icons.person_add),
                label: Text('Add User'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: _users.isEmpty
              ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.people_outline, size: 80, color: Colors.white30),
                SizedBox(height: 16),
                Text(
                  'No Users Found',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  'Users will appear here once they register',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
              ],
            ),
          )
              : ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 16),
            itemCount: _users.length,
            itemBuilder: (context, index) {
              final user = _users[index];
              final userName = user['name'] != null ? user['name'] as String : 'Unknown User';
              final userEmail = user['email'] != null ? user['email'] as String : 'No email';
              final userJoinDate = user['joinDate'] != null ? user['joinDate'] as String : 'Unknown';

              return Card(
                color: Color(0xFF1D1E33),
                margin: EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.blueAccent,
                    child: Text(
                      userName[0].toUpperCase(),
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  title: Text(
                    userName,
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(userEmail, style: TextStyle(color: Colors.white70)),
                      Text(
                        'Joined: $userJoinDate',
                        style: TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Chip(
                        label: Text(
                          (user['isPremium'] == true) ? 'PREMIUM' : 'FREE',
                          style: TextStyle(color: Colors.white, fontSize: 10),
                        ),
                        backgroundColor: (user['isPremium'] == true) ? Colors.green : Colors.blueAccent,
                      ),
                      SizedBox(width: 8),
                      PopupMenuButton(
                        icon: Icon(Icons.more_vert, color: Colors.white70),
                        itemBuilder: (context) => [
                          PopupMenuItem(child: Text('Edit User'), value: 'edit'),
                          PopupMenuItem(child: Text('View Details'), value: 'details'),
                          PopupMenuItem(child: Text('Delete User'), value: 'delete'),
                        ],
                        onSelected: (value) => _handleUserAction(value as String, user),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSoundsTab() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: Text('Sounds Library (${_sounds.length})',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
              ElevatedButton.icon(
                onPressed: _showAddSoundDialog,
                icon: Icon(Icons.add),
                label: Text('Add Sound'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: _sounds.isEmpty
              ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.music_note, size: 80, color: Colors.white30),
                SizedBox(height: 16),
                Text(
                  'No Sounds Available',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  'Add sounds to build your library',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
              ],
            ),
          )
              : GridView.builder(
            padding: EdgeInsets.all(16),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.2,
            ),
            itemCount: _sounds.length,
            itemBuilder: (context, index) {
              final sound = _sounds[index];
              final soundName = sound['name'] != null ? sound['name'] as String : 'Unknown Sound';
              final soundCategory = sound['category'] != null ? sound['category'] as String : 'Uncategorized';
              final soundIcon = sound['icon'] != null ? sound['icon'] as String : '🎵';

              return Card(
                color: Color(0xFF1D1E33),
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.blueAccent.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(soundIcon, style: TextStyle(fontSize: 16)),
                          ),
                          Spacer(),
                          if (sound['isPremium'] == true)
                            Icon(Icons.lock, color: Colors.amber, size: 16),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        soundName,
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 4),
                      Text(
                        soundCategory,
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                      Spacer(),
                      Row(
                        children: [
                          IconButton(
                            icon: Icon(Icons.play_arrow, color: Colors.green, size: 18),
                            onPressed: () => _previewSound(sound),
                          ),
                          IconButton(
                            icon: Icon(Icons.edit, color: Colors.blueAccent, size: 18),
                            onPressed: () => _showEditSoundDialog(sound),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: Colors.red, size: 18),
                            onPressed: () => _showDeleteSoundDialog(sound),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildVideosTab() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: Text('Video Content (${_videos.length})',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
              ElevatedButton.icon(
                onPressed: _showAddVideoDialog,
                icon: Icon(Icons.video_library),
                label: Text('Add Video'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purpleAccent,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: _videos.isEmpty
              ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.videocam_off, size: 80, color: Colors.white30),
                SizedBox(height: 16),
                Text(
                  'No Videos Available',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  'Add videos to your content library',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
              ],
            ),
          )
              : ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 16),
            itemCount: _videos.length,
            itemBuilder: (context, index) {
              final video = _videos[index];
              final videoTitle = video['title'] != null ? video['title'] as String : 'Untitled Video';
              final videoDescription = video['description'] != null ? video['description'] as String : 'No description';
              final videoDuration = video['duration'] != null ? video['duration'] as String : 'Unknown';
              final videoThumbnail = video['thumbnail'] != null ? video['thumbnail'] as String : null;

              return Card(
                color: Color(0xFF1D1E33),
                margin: EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: Colors.black26,
                      borderRadius: BorderRadius.circular(8),
                      image: videoThumbnail != null ? DecorationImage(
                        image: NetworkImage(videoThumbnail),
                        fit: BoxFit.cover,
                      ) : null,
                    ),
                    child: videoThumbnail == null ? Icon(Icons.videocam, color: Colors.white30) : null,
                  ),
                  title: Text(
                    videoTitle,
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        videoDescription,
                        style: TextStyle(color: Colors.white70),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text(
                        'Duration: $videoDuration',
                        style: TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (video['isPremium'] == true)
                        Icon(Icons.lock, color: Colors.amber, size: 16),
                      SizedBox(width: 8),
                      PopupMenuButton(
                        icon: Icon(Icons.more_vert, color: Colors.white70),
                        itemBuilder: (context) => [
                          PopupMenuItem(child: Text('Edit Video'), value: 'edit'),
                          PopupMenuItem(child: Text('View Analytics'), value: 'analytics'),
                          PopupMenuItem(child: Text('Delete Video'), value: 'delete'),
                        ],
                        onSelected: (value) => _handleVideoAction(value as String, video),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildAnalyticsTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Sleep Analytics
          Card(
            color: Color(0xFF1D1E33),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.analytics, color: Colors.blueAccent),
                      SizedBox(width: 8),
                      Text('Sleep Quality Distribution', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                    ],
                  ),
                  SizedBox(height: 16),
                  _buildSleepQualityChart(),
                ],
              ),
            ),
          ),
          SizedBox(height: 20),

          // User Growth
          Card(
            color: Color(0xFF1D1E33),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.trending_up, color: Colors.green),
                      SizedBox(width: 8),
                      Text('User Growth', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                    ],
                  ),
                  SizedBox(height: 16),
                  _buildUserGrowthChart(),
                ],
              ),
            ),
          ),
          SizedBox(height: 20),

          // Content Performance
          Card(
            color: Color(0xFF1D1E33),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.star, color: Colors.amber),
                      SizedBox(width: 8),
                      Text('Content Performance', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                    ],
                  ),
                  SizedBox(height: 16),
                  _buildContentPerformance(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSleepQualityChart() {
    final List<Map<String, Object>> data = [
      {'quality': 'Excellent', 'users': 45, 'color': Colors.green},
      {'quality': 'Good', 'users': 120, 'color': Colors.blue},
      {'quality': 'Fair', 'users': 85, 'color': Colors.orange},
      {'quality': 'Poor', 'users': 30, 'color': Colors.red},
    ];

    final totalUsers = data.fold<int>(0, (sum, item) => sum + (item['users'] as int));

    return Column(
      children: data.map((item) {
        final percentage = totalUsers > 0 ? ((item['users'] as int) / totalUsers * 100) : 0;
        return Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: item['color'] as Color,
                  shape: BoxShape.circle,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  item['quality'] as String,
                  style: TextStyle(color: Colors.white),
                ),
              ),
              SizedBox(width: 8),
              Text(
                '${item['users']} users',
                style: TextStyle(color: Colors.white70),
              ),
              SizedBox(width: 8),
              Text(
                '(${percentage.toStringAsFixed(1)}%)',
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildUserGrowthChart() {
    final data = [
      {'month': 'Jan', 'users': 100},
      {'month': 'Feb', 'users': 250},
      {'month': 'Mar', 'users': 500},
      {'month': 'Apr', 'users': _users.length},
    ];

    return Column(
      children: data.map((item) {
        final currentIndex = data.indexOf(item);
        final previousUsers = currentIndex > 0 ? (data[currentIndex - 1]['users'] as int) : 0;
        final currentUsers = item['users'] as int;
        final growth = currentIndex > 0 ? ((currentUsers - previousUsers) / previousUsers * 100) : 0;

        return Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  item['month'] as String,
                  style: TextStyle(color: Colors.white),
                ),
              ),
              Text(
                '$currentUsers users',
                style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold),
              ),
              SizedBox(width: 8),
              Text(
                '${growth > 0 ? '+' : ''}${growth.toStringAsFixed(1)}%',
                style: TextStyle(
                  color: growth > 0 ? Colors.green : Colors.red,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildContentPerformance() {
    return Column(
      children: [
        _buildPerformanceItem('Meditations', 'High Engagement', Icons.self_improvement, Colors.green),
        _buildPerformanceItem('Sleep Stories', 'Medium Engagement', Icons.book, Colors.blue),
        _buildPerformanceItem('Relaxation Music', 'High Engagement', Icons.music_note, Colors.purple),
        _buildPerformanceItem('Guided Videos', 'Low Engagement', Icons.videocam, Colors.orange),
      ],
    );
  }

  Widget _buildPerformanceItem(String title, String performance, IconData icon, Color color) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          SizedBox(width: 12),
          Expanded(
            child: Text(title, style: TextStyle(color: Colors.white)),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color),
            ),
            child: Text(
              performance,
              style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGiftCodesTab() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: Text('Gift Codes & Licenses',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
              ElevatedButton.icon(
                onPressed: _showGenerateGiftCodeDialog,
                icon: Icon(Icons.card_giftcard),
                label: Text('Generate Code'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: _giftCodes.isEmpty
              ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.card_giftcard, size: 80, color: Colors.white30),
                SizedBox(height: 16),
                Text(
                  'No Gift Codes Generated',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  'Generate your first gift code to start selling subscriptions directly',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _showGenerateGiftCodeDialog,
                  child: Text('Generate First Code'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
          )
              : ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 16),
            itemCount: _giftCodes.length,
            itemBuilder: (context, index) {
              final code = _giftCodes[index];
              final codeValue = code['code'] != null ? code['code'] as String : 'Unknown Code';
              final codePlan = code['plan'] != null ? code['plan'] as String : 'Unknown';
              final codeStatus = code['status'] != null ? code['status'] as String : 'Active';

              return Card(
                color: Color(0xFF1D1E33),
                margin: EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.card_giftcard, color: Colors.orange),
                  ),
                  title: Text(
                    codeValue,
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Plan: $codePlan', style: TextStyle(color: Colors.white70)),
                      Text('Status: $codeStatus', style: TextStyle(color: Colors.white54, fontSize: 12)),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.copy, color: Colors.blueAccent, size: 18),
                        onPressed: () => _copyGiftCode(codeValue),
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red, size: 18),
                        onPressed: () => _showDeleteGiftCodeDialog(code),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildFloatingActionButton() {
    return FloatingActionButton(
      onPressed: _showQuickActions,
      child: Icon(Icons.add),
      backgroundColor: Colors.blueAccent,
      tooltip: 'Quick Actions',
    );
  }

  Widget _buildAdminStatCard(String title, String value, IconData icon, Color color) {
    return Card(
      color: Color(0xFF1D1E33),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            SizedBox(height: 12),
            Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
            SizedBox(height: 4),
            Text(title, style: TextStyle(color: Colors.white70, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  // ========== DIALOG METHODS ==========

  void _showAddUserDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Add New User', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(
                  labelText: 'Name',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: Colors.white),
              ),
              SizedBox(height: 12),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: Colors.white),
                keyboardType: TextInputType.emailAddress,
              ),
              SizedBox(height: 12),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Password',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: Colors.white),
                obscureText: true,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              // Implement add user functionality
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('User added successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Add User'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
          ),
        ],
      ),
    );
  }

  void _showAddSoundDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Add New Sound', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(
                  labelText: 'Sound Name',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: Colors.white),
              ),
              SizedBox(height: 12),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Category',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: Colors.white),
              ),
              SizedBox(height: 12),
              Row(
                children: [
                  Checkbox(
                    value: false,
                    onChanged: (value) {},
                    fillColor: MaterialStateProperty.all(Colors.blueAccent),
                  ),
                  Text('Premium Sound', style: TextStyle(color: Colors.white70)),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Sound added successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Add Sound'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          ),
        ],
      ),
    );
  }

  void _showAddVideoDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Add New Video', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(
                  labelText: 'Video Title',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: Colors.white),
              ),
              SizedBox(height: 12),
              TextField(
                decoration: InputDecoration(
                  labelText: 'YouTube URL',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                ),
                style: TextStyle(color: Colors.white),
                keyboardType: TextInputType.url,
              ),
              SizedBox(height: 12),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Duration',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                  hintText: 'e.g., 15 min',
                  hintStyle: TextStyle(color: Colors.white54),
                ),
                style: TextStyle(color: Colors.white),
              ),
              SizedBox(height: 12),
              Row(
                children: [
                  Checkbox(
                    value: false,
                    onChanged: (value) {},
                    fillColor: MaterialStateProperty.all(Colors.blueAccent),
                  ),
                  Text('Premium Video', style: TextStyle(color: Colors.white70)),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Video added successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Add Video'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.purpleAccent),
          ),
        ],
      ),
    );
  }

  void _showGenerateGiftCodeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Generate Gift Code', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelText: 'Subscription Plan',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                ),
                items: [
                  DropdownMenuItem(child: Text('Monthly', style: TextStyle(color: Colors.white)), value: 'monthly'),
                  DropdownMenuItem(child: Text('Yearly', style: TextStyle(color: Colors.white)), value: 'yearly'),
                  DropdownMenuItem(child: Text('Lifetime', style: TextStyle(color: Colors.white)), value: 'lifetime'),
                ],
                onChanged: (value) {},
                style: TextStyle(color: Colors.white),
              ),
              SizedBox(height: 12),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Number of Codes',
                  labelStyle: TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(),
                  hintText: '1',
                  hintStyle: TextStyle(color: Colors.white54),
                ),
                style: TextStyle(color: Colors.white),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Gift codes generated successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Generate'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
          ),
        ],
      ),
    );
  }

  void _showQuickActions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Color(0xFF1D1E33),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              SizedBox(height: 16),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  _buildQuickActionButton('Add User', Icons.person_add, Colors.blueAccent, _showAddUserDialog),
                  _buildQuickActionButton('Add Sound', Icons.music_note, Colors.green, _showAddSoundDialog),
                  _buildQuickActionButton('Add Video', Icons.videocam, Colors.purpleAccent, _showAddVideoDialog),
                  _buildQuickActionButton('Generate Code', Icons.card_giftcard, Colors.orange, _showGenerateGiftCodeDialog),
                  _buildQuickActionButton('Refresh Data', Icons.refresh, Colors.blueAccent, _loadAdminData),
                  _buildQuickActionButton('System Status', Icons.settings, Colors.grey, () {}),
                ],
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActionButton(String label, IconData icon, Color color, VoidCallback onPressed) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context); // Close the bottom sheet
        onPressed();
      },
      child: Container(
        width: 100,
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            SizedBox(height: 8),
            Text(label, style: TextStyle(color: Colors.white, fontSize: 12), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  // ========== ACTION HANDLERS ==========

  void _handleUserAction(String action, dynamic user) {
    switch (action) {
      case 'edit':
        _showEditUserDialog(user);
        break;
      case 'details':
        _showUserDetailsDialog(user);
        break;
      case 'delete':
        _showDeleteUserDialog(user);
        break;
    }
  }

  void _handleVideoAction(String action, dynamic video) {
    switch (action) {
      case 'edit':
        _showEditVideoDialog(video);
        break;
      case 'analytics':
        _showVideoAnalyticsDialog(video);
        break;
      case 'delete':
        _showDeleteVideoDialog(video);
        break;
    }
  }

  void _showEditUserDialog(dynamic user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Edit User', style: TextStyle(color: Colors.white)),
        content: Text('Edit functionality for ${user['name']}', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('User updated successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Save'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
          ),
        ],
      ),
    );
  }

  void _showUserDetailsDialog(dynamic user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('User Details', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDetailItem('Name', user['name'] != null ? user['name'] as String : 'Unknown'),
              _buildDetailItem('Email', user['email'] != null ? user['email'] as String : 'Unknown'),
              _buildDetailItem('User ID', user['_id'] != null ? user['_id'] as String : 'Unknown'),
              _buildDetailItem('Subscription', (user['isPremium'] == true) ? 'Premium' : 'Free'),
              _buildDetailItem('Join Date', user['joinDate'] != null ? user['joinDate'] as String : 'Unknown'),
              _buildDetailItem('Source', user['source'] != null ? user['source'] as String : 'Unknown'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close', style: TextStyle(color: Colors.white70)),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label: ', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
          Expanded(
            child: Text(value, style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _showDeleteUserDialog(dynamic user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Delete User', style: TextStyle(color: Colors.white)),
        content: Text('Are you sure you want to delete ${user['name']}? This action cannot be undone.', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              // Implement delete user functionality
              setState(() {
                _users.removeWhere((u) => u['_id'] == user['_id']);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('User deleted successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Delete'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          ),
        ],
      ),
    );
  }

  void _previewSound(dynamic sound) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Previewing: ${sound['name']}'), backgroundColor: Colors.blueAccent),
    );
  }

  void _showEditSoundDialog(dynamic sound) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Edit Sound', style: TextStyle(color: Colors.white)),
        content: Text('Edit functionality for ${sound['name']}', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Sound updated successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Save'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          ),
        ],
      ),
    );
  }

  void _showDeleteSoundDialog(dynamic sound) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Delete Sound', style: TextStyle(color: Colors.white)),
        content: Text('Are you sure you want to delete ${sound['name']}?', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _sounds.removeWhere((s) => s['_id'] == sound['_id']);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Sound deleted successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Delete'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          ),
        ],
      ),
    );
  }

  void _showEditVideoDialog(dynamic video) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Edit Video', style: TextStyle(color: Colors.white)),
        content: Text('Edit functionality for ${video['title']}', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Video updated successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Save'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.purpleAccent),
          ),
        ],
      ),
    );
  }

  void _showVideoAnalyticsDialog(dynamic video) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Video Analytics', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Analytics for: ${video['title']}', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              SizedBox(height: 16),
              _buildAnalyticsItem('Views', '1,234'),
              _buildAnalyticsItem('Watch Time', '45.6 hours'),
              _buildAnalyticsItem('Engagement', '78%'),
              _buildAnalyticsItem('Completion Rate', '65%'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close', style: TextStyle(color: Colors.white70)),
          ),
        ],
      ),
    );
  }

  Widget _buildAnalyticsItem(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: Colors.white70))),
          Text(value, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  void _showDeleteVideoDialog(dynamic video) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Delete Video', style: TextStyle(color: Colors.white)),
        content: Text('Are you sure you want to delete ${video['title']}?', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _videos.removeWhere((v) => v['_id'] == video['_id']);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Video deleted successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Delete'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          ),
        ],
      ),
    );
  }

  void _showDeleteGiftCodeDialog(dynamic code) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        title: Text('Delete Gift Code', style: TextStyle(color: Colors.white)),
        content: Text('Are you sure you want to delete gift code ${code['code']}?', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _giftCodes.removeWhere((c) => c['code'] == code['code']);
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Gift code deleted successfully!'), backgroundColor: Colors.green),
              );
            },
            child: Text('Delete'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          ),
        ],
      ),
    );
  }

  void _copyGiftCode(String? code) {
    if (code != null) {
      // In a real app, you would use Clipboard.setData
      // Clipboard.setData(ClipboardData(text: code));
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gift code copied to clipboard: $code'),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 2),
        ),
      );
    }
  }
}