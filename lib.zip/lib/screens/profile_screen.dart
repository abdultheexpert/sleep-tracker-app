import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/sleep_tracker_provider.dart';
import '../providers/sound_mixer_provider.dart';
import '../services/api_service.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController _giftCodeController = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    if (!authProvider.isGuest) {
      try {
        // Load user profile from backend
        final result = await ApiService.getUserProfile();
        if (result['success']) {
          // User data is automatically updated in AuthProvider
          print('✅ User profile loaded successfully');
        }
      } catch (e) {
        print('❌ Error loading user profile: $e');
      }
    }
  }

  @override
  void dispose() {
    _giftCodeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final sleepProvider = Provider.of<SleepTrackerProvider>(context);
    final soundProvider = Provider.of<SoundMixerProvider>(context);

    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      appBar: AppBar(
        title: Text('Profile', style: TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        )),
        backgroundColor: Color(0xFF1D1E33),
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.settings, color: Colors.white),
            onPressed: () => _showSettings(context),
            tooltip: 'Settings',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            // Enhanced User Profile Card
            _buildUserProfileCard(authProvider),
            SizedBox(height: 20),

            // Sleep Statistics
            _buildSleepStatistics(sleepProvider, authProvider),
            SizedBox(height: 20),

            // Sound Usage Statistics
            _buildSoundStatistics(soundProvider),
            SizedBox(height: 20),

            // Subscription & Gift Code Section
            if (!authProvider.isPremium)
              _buildSubscriptionSection(context, authProvider),
            SizedBox(height: 20),

            // Account Management
            _buildAccountManagement(context, authProvider),
            SizedBox(height: 20),

            // App Preferences
            _buildAppPreferences(),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildUserProfileCard(AuthProvider authProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.blueAccent.withOpacity(0.2),
                  child: Icon(Icons.person, size: 40, color: Colors.blueAccent),
                ),
                if (authProvider.isPremium)
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.amber,
                        shape: BoxShape.circle,
                        border: Border.all(color: Color(0xFF1D1E33), width: 2),
                      ),
                      child: Icon(Icons.verified, color: Colors.white, size: 16),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 16),
            Text(
              authProvider.userName,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            SizedBox(height: 4),
            Text(
              authProvider.userEmail,
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Chip(
                  label: Text(
                    authProvider.loginMethod.toUpperCase(),
                    style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                  backgroundColor: _getMethodColor(authProvider.loginMethod),
                ),
                SizedBox(width: 8),
                Chip(
                  label: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.star, size: 12, color: Colors.white),
                      SizedBox(width: 4),
                      Text(
                        authProvider.isPremium ? 'PREMIUM' : 'FREE',
                        style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  backgroundColor: authProvider.isPremium ? Colors.green : Colors.amber,
                ),
                if (authProvider.isGuest) ...[
                  SizedBox(width: 8),
                  Chip(
                    label: Text(
                      'GUEST',
                      style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                    ),
                    backgroundColor: Colors.blueGrey,
                  ),
                ],
              ],
            ),
            SizedBox(height: 16),
            if (!authProvider.isPremium && !authProvider.isGuest)
              ElevatedButton.icon(
                onPressed: () => _showSubscriptionOptions(context),
                icon: Icon(Icons.workspace_premium, size: 18),
                label: Text('Upgrade to Premium'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  foregroundColor: Colors.black,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSleepStatistics(SleepTrackerProvider sleepProvider, AuthProvider authProvider) {
    // Get sleep stats from provider or calculate them
    final sleepStats = _calculateSleepStats(sleepProvider);

    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.analytics, color: Colors.blueAccent, size: 20),
                SizedBox(width: 8),
                Text('Sleep Analytics', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                Spacer(),
                Text(
                  '${sleepStats['totalSessions']} sessions',
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
            SizedBox(height: 16),

            // Sleep Score Display (Simplified without gauge)
            Container(
              height: 80,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '${sleepStats['avgScore']}',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: _getScoreColor(sleepStats['avgScore']),
                      ),
                    ),
                    Text(
                      'Average Sleep Score',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 16),

            GridView.count(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              children: [
                _buildStatItem('Total Sessions', sleepStats['totalSessions'].toString(),
                    Icons.nightlight_round, Colors.blueAccent),
                _buildStatItem('Avg. Duration', sleepStats['avgDuration'],
                    Icons.timer, Colors.greenAccent),
                _buildStatItem('Best Score', sleepStats['bestScore'].toString(),
                    Icons.emoji_events, Colors.amber),
                _buildStatItem('Sleep Efficiency', '${sleepStats['efficiency']}%',
                    Icons.trending_up, Colors.purpleAccent),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSoundStatistics(SoundMixerProvider soundProvider) {
    // Calculate sound statistics
    final totalSounds = soundProvider.availableSounds.length;
    final favoriteSounds = soundProvider.availableSounds.where((sound) => sound['isFavorite'] == true).length;
    final totalCategories = soundProvider.availableSounds.map((sound) => sound['category']).toSet().length;

    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.music_note, color: Colors.purpleAccent, size: 20),
                SizedBox(width: 8),
                Text('Sound Statistics', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
            SizedBox(height: 16),
            GridView.count(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              children: [
                _buildStatItem('Total Sounds', totalSounds.toString(),
                    Icons.library_music, Colors.purpleAccent),
                _buildStatItem('Favorites', favoriteSounds.toString(),
                    Icons.favorite, Colors.redAccent),
                _buildStatItem('Saved Mixes', '0', // Placeholder
                    Icons.playlist_play, Colors.orangeAccent),
                _buildStatItem('Categories', totalCategories.toString(),
                    Icons.category, Colors.greenAccent),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubscriptionSection(BuildContext context, AuthProvider authProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.workspace_premium, color: Colors.amber, size: 20),
                SizedBox(width: 8),
                Text('Premium Features', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
            SizedBox(height: 12),
            Text(
              'Unlock all premium features and enhance your sleep experience',
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            SizedBox(height: 16),

            // Gift Code Redemption
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blueAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blueAccent.withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Have a gift code?', style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  )),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _giftCodeController,
                          style: TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: 'Enter gift code...',
                            hintStyle: TextStyle(color: Colors.white54),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(color: Colors.white30),
                            ),
                            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      _isLoading
                          ? CircularProgressIndicator(strokeWidth: 2, color: Colors.blueAccent)
                          : ElevatedButton(
                        onPressed: () => _redeemGiftCode(context, authProvider),
                        child: Text('Redeem'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueAccent,
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _showSubscriptionOptions(context),
                icon: Icon(Icons.rocket_launch, size: 18),
                label: Text('View Subscription Plans'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  foregroundColor: Colors.black,
                  padding: EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountManagement(BuildContext context, AuthProvider authProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              children: [
                Icon(Icons.account_circle, color: Colors.blueAccent, size: 20),
                SizedBox(width: 8),
                Text('Account Management', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
          ),
          _buildAccountItem(Icons.credit_card, 'Subscription & Billing',
              authProvider.isPremium ? 'Premium - Active' : 'Free Plan - Upgrade Available',
              onTap: () => _showSubscriptionOptions(context)),
          _buildAccountItem(Icons.history, 'Sleep History & Analytics',
              'View detailed sleep reports and trends', onTap: () {}),
          _buildAccountItem(Icons.favorite, 'Favorite Sounds & Mixes',
              'Manage your sound preferences', onTap: () {}),
          _buildAccountItem(Icons.notifications_active, 'Notifications & Reminders',
              'Configure sleep alerts', onTap: () => _showNotificationSettings(context)),
          _buildAccountItem(Icons.help_center, 'Help & Support',
              'Get assistance and FAQs', onTap: () {}),
          _buildAccountItem(Icons.security, 'Privacy & Security',
              'Manage your data and privacy', onTap: () {}),
          _buildAccountItem(Icons.description, 'Terms & Policies',
              'Read our terms of service', onTap: () {}),
          if (!authProvider.isGuest)
            _buildAccountItem(Icons.logout, 'Sign Out',
                'Log out of your account', onTap: () => _showLogoutDialog(context, authProvider)),
        ],
      ),
    );
  }

  Widget _buildAppPreferences() {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              children: [
                Icon(Icons.settings, color: Colors.greenAccent, size: 20),
                SizedBox(width: 8),
                Text('App Preferences', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
          ),
          _buildSettingItem('Dark Mode', true, Icons.dark_mode, (value) {}),
          _buildSettingItem('Sleep Reminders', false, Icons.alarm, (value) {}),
          _buildSettingItem('Smart Alarm', true, Icons.smart_toy, (value) {}),
          _buildSettingItem('Snore Detection', true, Icons.record_voice_over, (value) {}),
          _buildSettingItem('Auto Sleep Tracking', false, Icons.self_improvement, (value) {}),
          _buildSettingItem('Background Audio', true, Icons.music_note, (value) {}),
          _buildSettingItem('Battery Optimization', true, Icons.battery_charging_full, (value) {}),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            SizedBox(height: 8),
            Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
            SizedBox(height: 4),
            Text(label, style: TextStyle(fontSize: 10, color: Colors.white70), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _buildAccountItem(IconData icon, String title, String subtitle, {VoidCallback? onTap}) {
    return ListTile(
      leading: Container(
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.blueAccent.withOpacity(0.2),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: Colors.blueAccent, size: 20),
      ),
      title: Text(title, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
      subtitle: Text(subtitle, style: TextStyle(color: Colors.white54, fontSize: 12)),
      trailing: Icon(Icons.arrow_forward_ios, size: 16, color: Colors.white54),
      onTap: onTap,
    );
  }

  Widget _buildSettingItem(String title, bool value, IconData icon, Function(bool) onChanged) {
    return ListTile(
      leading: Icon(icon, color: Colors.greenAccent, size: 20),
      title: Text(title, style: TextStyle(color: Colors.white)),
      trailing: Switch(
        value: value,
        onChanged: onChanged,
        activeColor: Colors.greenAccent,
        activeTrackColor: Colors.greenAccent.withOpacity(0.5),
      ),
    );
  }

  // Enhanced Methods
  Future<void> _redeemGiftCode(BuildContext context, AuthProvider authProvider) async {
    if (_giftCodeController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter a gift code'), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final result = await ApiService.redeemGiftCode(
        code: _giftCodeController.text.trim(),
      );

      setState(() {
        _isLoading = false;
      });

      if (result['success']) {
        // Update user premium status
        authProvider.upgradeToPremium();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('🎉 Gift code redeemed successfully! Premium activated.'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 3),
          ),
        );
        _giftCodeController.clear();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ ${result['error'] ?? "Invalid gift code"}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ Error redeeming gift code. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _showSubscriptionOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: BoxDecoration(
          color: Color(0xFF1D1E33),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: _buildSubscriptionBottomSheet(context),
      ),
    );
  }

  Widget _buildSubscriptionBottomSheet(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);

    return Padding(
      padding: EdgeInsets.all(20),
      child: Column(
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white30,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          SizedBox(height: 20),
          Text('Choose Your Plan', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
          SizedBox(height: 8),
          Text('Unlock all premium features and content', style: TextStyle(color: Colors.white70)),
          SizedBox(height: 20),

          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _buildSubscriptionPlan(
                    'Monthly',
                    '\$9.99/month',
                    '7-day free trial',
                    Icons.calendar_today,
                    false,
                    onTap: () => _upgradeToPlan(authProvider, 'monthly'),
                  ),
                  _buildSubscriptionPlan(
                    'Yearly',
                    '\$59.99/year',
                    'Save 50% • Most Popular',
                    Icons.verified_user,
                    true,
                    onTap: () => _upgradeToPlan(authProvider, 'yearly'),
                  ),
                  _buildSubscriptionPlan(
                    'Lifetime',
                    '\$149.99',
                    'One-time payment • Best Value',
                    Icons.workspace_premium,
                    false,
                    onTap: () => _upgradeToPlan(authProvider, 'lifetime'),
                  ),

                  SizedBox(height: 20),
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Premium Features Include:', style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        )),
                        SizedBox(height: 8),
                        _buildFeatureItem('✓ Unlimited access to all 260+ sleep sounds'),
                        _buildFeatureItem('✓ Advanced AI sleep tracking and analytics'),
                        _buildFeatureItem('✓ No advertisements'),
                        _buildFeatureItem('✓ Offline downloads'),
                        _buildFeatureItem('✓ Exclusive premium content'),
                        _buildFeatureItem('✓ Priority customer support'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => _upgradeToPlan(authProvider, 'yearly'),
              child: Text('Start 7-Day Free Trial', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          SizedBox(height: 8),
          Text('Cancel anytime • No commitment required',
              style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildSubscriptionPlan(String title, String price, String description, IconData icon, bool isPopular, {VoidCallback? onTap}) {
    return Card(
      color: isPopular ? Colors.blueAccent.withOpacity(0.2) : Color(0xFF2A2B3D),
      margin: EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isPopular ? Colors.blueAccent : Colors.transparent,
          width: 2,
        ),
      ),
      child: ListTile(
        leading: Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.blueAccent.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: Colors.blueAccent),
        ),
        title: Row(
          children: [
            Text(title, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            if (isPopular) ...[
              SizedBox(width: 8),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text('POPULAR', style: TextStyle(
                  color: Colors.white,
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                )),
              ),
            ],
          ],
        ),
        subtitle: Text(description, style: TextStyle(color: Colors.white70)),
        trailing: Text(price, style: TextStyle(
          color: Colors.blueAccent,
          fontWeight: FontWeight.bold,
          fontSize: 16,
        )),
        onTap: onTap,
      ),
    );
  }

  Widget _buildFeatureItem(String text) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(Icons.check_circle, color: Colors.green, size: 16),
          SizedBox(width: 8),
          Expanded(child: Text(text, style: TextStyle(color: Colors.white70, fontSize: 14))),
        ],
      ),
    );
  }

  void _upgradeToPlan(AuthProvider authProvider, String plan) {
    Navigator.pop(context); // Close bottom sheet
    authProvider.upgradeToPremium(plan);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('🎉 Welcome to Premium! All features unlocked.'),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 3),
      ),
    );
  }

  void _showSettings(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Settings screen coming soon!')),
    );
  }

  void _showNotificationSettings(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Notification settings coming soon!')),
    );
  }

  void _showLogoutDialog(BuildContext context, AuthProvider authProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Sign Out', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: Text('Are you sure you want to sign out? You can always log back in later.',
            style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          ElevatedButton(
            onPressed: () {
              authProvider.logout();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Signed out successfully')),
              );
            },
            child: Text('Sign Out', style: TextStyle(color: Colors.white)),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  // Helper Methods
  Color _getMethodColor(String method) {
    switch (method) {
      case 'google': return Colors.redAccent;
      case 'facebook': return Colors.blue[800]!;
      case 'apple': return Colors.black;
      case 'email': return Colors.green;
      case 'guest': return Colors.blueGrey;
      default: return Colors.blueAccent;
    }
  }

  Color _getScoreColor(int score) {
    if (score >= 80) return Colors.green;
    if (score >= 60) return Colors.orange;
    return Colors.red;
  }

  Map<String, dynamic> _calculateSleepStats(SleepTrackerProvider sleepProvider) {
    // Calculate sleep statistics from sleep history
    final sleepHistory = sleepProvider.sleepHistory;

    if (sleepHistory.isEmpty) {
      return {
        'totalSessions': 0,
        'avgScore': 0,
        'avgDuration': '0h 0m',
        'bestScore': 0,
        'efficiency': 0,
      };
    }

    // FIXED: Properly convert sleep scores to integers
    final totalSessions = sleepHistory.length;

    // Calculate total score with proper type conversion
    int totalScore = 0;
    int bestScore = 0;

    for (final session in sleepHistory) {
      final sessionScore = session['sleepScore'] ?? 0;
      final intScore = (sessionScore is int) ? sessionScore : (sessionScore as num).toInt();

      totalScore += intScore;
      if (intScore > bestScore) {
        bestScore = intScore;
      }
    }

    final avgScore = totalScore ~/ totalSessions;
    final efficiency = ((avgScore / 100) * 85 + 15).round();

    return {
      'totalSessions': totalSessions,
      'avgScore': avgScore,
      'avgDuration': '7h 30m', // Placeholder
      'bestScore': bestScore,
      'efficiency': efficiency,
    };
  }
}