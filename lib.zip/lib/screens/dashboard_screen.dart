import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/sleep_tracker_provider.dart';
import '../providers/sound_mixer_provider.dart';
import '../providers/content_provider.dart';
import '../services/api_service.dart';
import 'sleep_tracker_screen.dart';
import 'sounds_screen.dart';
import 'meditation_screen.dart';
import 'profile_screen.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with SingleTickerProviderStateMixin {
  Map<String, dynamic> _dashboardStats = {};
  bool _isLoadingBackend = true;
  bool _isRefreshing = false;
  late AnimationController _animationController;
  int _currentTipIndex = 0;
  final List<String> _usageTips = [
    'Start sleep tracking 30 minutes before bed for best results',
    'Mix 2-3 sounds for optimal relaxation and sleep quality',
    'Keep your phone charged and nearby during sleep tracking',
    'Review your sleep report in the morning for daily insights',
    'Use meditation sessions to wind down before bedtime',
    'Create custom sound mixes and save them for quick access',
    'Track your sleep consistently for better pattern analysis',
    'Try different sound combinations to find what works best',
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 2000),
    );
    _loadBackendData();
    _startTipsRotation();
  }

  void _startTipsRotation() {
    Future.delayed(Duration(seconds: 10), () {
      if (mounted) {
        setState(() {
          _currentTipIndex = (_currentTipIndex + 1) % _usageTips.length;
        });
        _startTipsRotation();
      }
    });
  }

  Future<void> _loadBackendData() async {
    try {
      final stats = await ApiService.getDashboardStats();
      setState(() {
        _dashboardStats = stats;
        _isLoadingBackend = false;
      });
    } catch (e) {
      print('Error loading backend data: $e');
      final demoStats = await ApiService.getDemoStats();
      setState(() {
        _dashboardStats = demoStats;
        _isLoadingBackend = false;
      });
    }
  }

  Future<void> _refreshData() async {
    setState(() {
      _isRefreshing = true;
    });
    await _loadBackendData();
    setState(() {
      _isRefreshing = false;
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final sleepProvider = Provider.of<SleepTrackerProvider>(context);
    final contentProvider = Provider.of<ContentProvider>(context);
    final soundProvider = Provider.of<SoundMixerProvider>(context);

    return Scaffold(
      backgroundColor: Color(0xFF0A0E21),
      appBar: _buildAppBar(authProvider),
      body: RefreshIndicator(
        onRefresh: _refreshData,
        backgroundColor: Color(0xFF1D1E33),
        color: Colors.blueAccent,
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Backend Connection Status
              _buildBackendStatus(),
              SizedBox(height: 16),

              // Welcome Section with User Avatar
              _buildWelcomeSection(authProvider, contentProvider),
              SizedBox(height: 20),

              // Live Statistics from Backend
              _buildBackendStats(),
              SizedBox(height: 20),

              // Sleep Tracking Card with Enhanced UI
              _buildSleepTrackerCard(context, sleepProvider),
              SizedBox(height: 20),

              // Quick Actions Grid with Animations
              _buildQuickActionsGrid(context, soundProvider),
              SizedBox(height: 20),

              // Recent Sleep Data with Charts
              _buildRecentSleepData(sleepProvider),
              SizedBox(height: 20),

              // Daily Affirmation with Flip Animation
              _buildDailyAffirmation(contentProvider),
              SizedBox(height: 20),

              // Rotating Usage Tips
              _buildUsageTips(),
              SizedBox(height: 20),

              // Premium Upgrade Card (for free users)
              if (!authProvider.isPremium) ...[
                _buildPremiumUpgradeCard(context),
                SizedBox(height: 20),
              ],
            ],
          ),
        ),
      ),
    );
  }

  AppBar _buildAppBar(AuthProvider authProvider) {
    return AppBar(
      title: Row(
        children: [
          AnimatedContainer(
            duration: Duration(milliseconds: 500),
            child: Icon(Icons.nightlight_round, color: Colors.blueAccent),
          ),
          SizedBox(width: 8),
          Text('Sleep Tracker Pro',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ],
      ),
      backgroundColor: Color(0xFF1D1E33),
      elevation: 0,
      actions: [
        _buildNotificationBadge(),
        IconButton(
          icon: Icon(Icons.person, color: Colors.white),
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => ProfileScreen())),
          tooltip: 'Profile',
        ),
      ],
    );
  }

  Widget _buildNotificationBadge() {
    return Stack(
      children: [
        IconButton(
          icon: Icon(Icons.notifications, color: Colors.white),
          onPressed: _showNotifications,
        ),
        Positioned(
          right: 8,
          top: 8,
          child: Container(
            padding: EdgeInsets.all(2),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(6),
            ),
            constraints: BoxConstraints(minWidth: 12, minHeight: 12),
            child: Text('1',
              style: TextStyle(color: Colors.white, fontSize: 8),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBackendStatus() {
    return FutureBuilder<bool>(
      future: ApiService.testConnection(),
      builder: (context, snapshot) {
        final isConnected = snapshot.data ?? false;
        return AnimatedContainer(
          duration: Duration(milliseconds: 500),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isConnected
                  ? [Colors.green.withOpacity(0.2), Colors.green.withOpacity(0.1)]
                  : [Colors.red.withOpacity(0.2), Colors.red.withOpacity(0.1)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isConnected ? Colors.green : Colors.red,
              width: 1,
            ),
          ),
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              AnimatedContainer(
                duration: Duration(milliseconds: 300),
                child: Icon(
                  isConnected ? Icons.cloud_done : Icons.cloud_off,
                  color: isConnected ? Colors.green : Colors.red,
                  size: 20,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isConnected ? 'Backend Connected' : 'Backend Offline',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      isConnected ? 'Real-time data sync active' : 'Using local data only',
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
              if (!isConnected)
                IconButton(
                  icon: Icon(Icons.refresh, color: Colors.white, size: 18),
                  onPressed: _refreshData,
                  tooltip: 'Retry Connection',
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildWelcomeSection(AuthProvider authProvider, ContentProvider contentProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF1D1E33), Color(0xFF2A2B3D)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            // User Avatar with Status
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blueAccent, Colors.purpleAccent],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.blueAccent.withOpacity(0.3),
                    blurRadius: 10,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Icon(Icons.nightlight_round, color: Colors.white, size: 32),
                  if (authProvider.isPremium)
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        padding: EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.amber,
                          shape: BoxShape.circle,
                          border: Border.all(color: Color(0xFF1D1E33), width: 2),
                        ),
                        child: Icon(Icons.star, color: Colors.white, size: 12),
                      ),
                    ),
                ],
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Good ${_getTimeOfDay()}, ${authProvider.userName.split(' ').first}!',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  SizedBox(height: 4),
                  Text(
                    _getWelcomeMessage(),
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                  SizedBox(height: 8),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: authProvider.isPremium
                          ? LinearGradient(colors: [Colors.blueAccent, Colors.purpleAccent])
                          : LinearGradient(colors: [Colors.amber, Colors.orange]),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          authProvider.isPremium ? Icons.verified : Icons.free_breakfast,
                          color: Colors.white,
                          size: 14,
                        ),
                        SizedBox(width: 4),
                        Text(
                          authProvider.isPremium ? 'PREMIUM' : 'FREE ACCOUNT',
                          style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBackendStats() {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.analytics, color: Colors.blueAccent, size: 24),
                SizedBox(width: 8),
                Text('Live Statistics',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                Spacer(),
                if (_isLoadingBackend)
                  SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                IconButton(
                  icon: Icon(Icons.refresh, color: Colors.white70, size: 20),
                  onPressed: _refreshData,
                  tooltip: 'Refresh Stats',
                ),
              ],
            ),
            SizedBox(height: 16),
            GridView.count(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              children: [
                _buildStatCard(
                  'Total Users',
                  _dashboardStats['totalUsers']?.toString() ?? '1,250',
                  Icons.people,
                  Colors.blueAccent,
                  'Across platform',
                ),
                _buildStatCard(
                  'Sleep Sessions',
                  _dashboardStats['totalSleepSessions']?.toString() ?? '15,678',
                  Icons.nightlight_round,
                  Colors.greenAccent,
                  'Total tracked',
                ),
                _buildStatCard(
                  'Premium Users',
                  _dashboardStats['premiumUsers']?.toString() ?? '298',
                  Icons.verified_user,
                  Colors.amber,
                  'Active subscribers',
                ),
                _buildStatCard(
                  'Active Today',
                  _dashboardStats['todaySleepSessions']?.toString() ?? '89',
                  Icons.today,
                  Colors.purpleAccent,
                  'Today\'s sessions',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color, String subtitle) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 500),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.2), color.withOpacity(0.05)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.1),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                Spacer(),
                Icon(Icons.trending_up, color: color.withOpacity(0.7), size: 16),
              ],
            ),
            SizedBox(height: 12),
            Text(
              value,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w500),
            ),
            SizedBox(height: 2),
            Text(
              subtitle,
              style: TextStyle(fontSize: 10, color: Colors.white54),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSleepTrackerCard(BuildContext context, SleepTrackerProvider sleepProvider) {
    final isTracking = sleepProvider.isTracking;
    final trackingDuration = sleepProvider.currentTrackingDuration;

    return Card(
      color: Color(0xFF1D1E33),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isTracking
                ? [Colors.blueAccent.withOpacity(0.1), Colors.green.withOpacity(0.05)]
                : [Color(0xFF1D1E33), Color(0xFF2A2B3D)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Sleep Tracker',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: isTracking ? Colors.green.withOpacity(0.2) : Colors.blueAccent.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: isTracking ? Colors.green : Colors.blueAccent),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        isTracking ? Icons.circle : Icons.nightlight_round,
                        color: isTracking ? Colors.green : Colors.blueAccent,
                        size: 12,
                      ),
                      SizedBox(width: 6),
                      Text(
                        isTracking ? 'LIVE TRACKING' : 'READY TO TRACK',
                        style: TextStyle(
                          fontSize: 12,
                          color: isTracking ? Colors.green : Colors.blueAccent,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Text(
              isTracking
                  ? 'AI is analyzing your sleep patterns with motion sensors and audio detection...'
                  : 'Track your sleep with AI-powered analysis and get detailed insights',
              style: TextStyle(color: Colors.white70, height: 1.4),
            ),
            if (isTracking) ...[
              SizedBox(height: 16),
              LinearProgressIndicator(
                value: _calculateTrackingProgress(trackingDuration),
                backgroundColor: Colors.white24,
                color: Colors.green,
                minHeight: 8,
                borderRadius: BorderRadius.circular(4),
              ),
              SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Tracking: ${_formatDuration(trackingDuration)}',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  Text(
                    '${(_calculateTrackingProgress(trackingDuration) * 100).toStringAsFixed(1)}%',
                    style: TextStyle(color: Colors.green, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ],
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => SleepTrackerScreen()));
                    },
                    icon: Icon(isTracking ? Icons.visibility : Icons.play_arrow),
                    label: Text(isTracking ? 'View Live Tracking' : 'Start Sleep Tracking'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isTracking ? Colors.green : Colors.blueAccent,
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      elevation: 4,
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: IconButton(
                    icon: Icon(Icons.analytics, color: Colors.white70),
                    onPressed: () => _showSleepAnalytics(context, sleepProvider),
                    tooltip: 'Sleep Analytics',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionsGrid(BuildContext context, SoundMixerProvider soundProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Quick Actions',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
            SizedBox(height: 16),
            GridView.count(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              children: [
                _buildQuickActionCard(
                  'Sleep Sounds',
                  Icons.music_note,
                  Colors.blueAccent,
                  '260+ Sounds',
                      () => Navigator.push(context, MaterialPageRoute(builder: (_) => SoundsScreen())),
                ),
                _buildQuickActionCard(
                  'Meditation',
                  Icons.self_improvement,
                  Colors.greenAccent,
                  'Guided Sessions',
                      () => Navigator.push(context, MaterialPageRoute(builder: (_) => MeditationScreen())),
                ),
                _buildQuickActionCard(
                  'Sleep Stories',
                  Icons.book,
                  Colors.purpleAccent,
                  'Bedtime Tales',
                      () => _showSleepStories(context),
                ),
                _buildQuickActionCard(
                  'Breathing',
                  Icons.air,
                  Colors.orangeAccent,
                  'Calm Exercises',
                      () => _showBreathingExercises(context),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionCard(String title, IconData icon, Color color, String subtitle, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color.withOpacity(0.2), color.withOpacity(0.05)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.1),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 24),
              ),
              SizedBox(height: 12),
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 10,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecentSleepData(SleepTrackerProvider sleepProvider) {
    final recentSessions = sleepProvider.sleepHistory.take(3).toList();

    return Card(
      color: Color(0xFF1D1E33),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.history, color: Colors.blueAccent, size: 24),
                SizedBox(width: 8),
                Text('Recent Sleep',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                Spacer(),
                TextButton(
                  onPressed: () => _showAllSleepHistory(context, sleepProvider),
                  child: Text('View All', style: TextStyle(color: Colors.blueAccent)),
                ),
              ],
            ),
            SizedBox(height: 16),
            if (recentSessions.isEmpty)
              _buildEmptySleepData()
            else
              Column(
                children: recentSessions.map((session) => _buildSleepSessionItem(session)).toList(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptySleepData() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Icon(Icons.nightlight_round, color: Colors.white30, size: 48),
          SizedBox(height: 12),
          Text(
            'No sleep data yet',
            style: TextStyle(color: Colors.white70, fontSize: 16),
          ),
          SizedBox(height: 8),
          Text(
            'Start tracking your sleep to see insights here',
            style: TextStyle(color: Colors.white54, fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSleepSessionItem(Map<String, dynamic> session) {
    final duration = session['duration'] is Duration
        ? session['duration'] as Duration
        : Duration(hours: 7, minutes: 30); // Fallback
    final sleepScore = session['sleepScore'] ?? 80;
    final date = session['startTime'] is DateTime
        ? session['startTime'] as DateTime
        : DateTime.now().subtract(Duration(days: 1));

    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: _getSleepScoreColor(sleepScore),
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(25),
            ),
            child: Center(
              child: Text(
                '$sleepScore',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${_formatDuration(duration)} sleep',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 4),
                Text(
                  _formatDate(date),
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
                SizedBox(height: 4),
                LinearProgressIndicator(
                  value: sleepScore / 100,
                  backgroundColor: Colors.white24,
                  color: _getSleepScoreProgressColor(sleepScore),
                  minHeight: 4,
                  borderRadius: BorderRadius.circular(2),
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_right, color: Colors.white54),
        ],
      ),
    );
  }

  Widget _buildDailyAffirmation(ContentProvider contentProvider) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.purpleAccent.withOpacity(0.1), Colors.blueAccent.withOpacity(0.05)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.auto_awesome, color: Colors.purpleAccent, size: 24),
                SizedBox(width: 8),
                Text('Daily Affirmation',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                Spacer(),
                IconButton(
                  icon: Icon(Icons.refresh, color: Colors.white70, size: 20),
                  onPressed: () => contentProvider.nextAffirmation(),
                  tooltip: 'Next Affirmation',
                ),
              ],
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.purpleAccent.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  Icon(Icons.format_quote, color: Colors.purpleAccent, size: 32),
                  SizedBox(height: 12),
                  Text(
                    contentProvider.dailyAffirmation,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontStyle: FontStyle.italic,
                      height: 1.4,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 12),
                  Text(
                    'Day ${contentProvider.currentAffirmation['day'] ?? 1} of 365',
                    style: TextStyle(color: Colors.white54, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUsageTips() {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.lightbulb, color: Colors.amber, size: 24),
                SizedBox(width: 8),
                Text('Pro Tips',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.amber),
                  ),
                  child: Text(
                    '${_currentTipIndex + 1}/${_usageTips.length}',
                    style: TextStyle(color: Colors.amber, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            AnimatedSwitcher(
              duration: Duration(milliseconds: 500),
              child: Container(
                key: ValueKey(_currentTipIndex),
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.amber.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.amber.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.tips_and_updates, color: Colors.amber, size: 20),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        _usageTips[_currentTipIndex],
                        style: TextStyle(color: Colors.white, height: 1.4),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPremiumUpgradeCard(BuildContext context) {
    return Card(
      color: Color(0xFF1D1E33),
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.amber.withOpacity(0.1), Colors.orange.withOpacity(0.05)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.amber.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Icon(Icons.star, color: Colors.amber, size: 24),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Upgrade to Premium',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Text(
              'Unlock all 260+ sounds, advanced AI sleep tracking, and ad-free experience',
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _showSubscriptionOptions(context),
                child: Text('UPGRADE NOW'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  foregroundColor: Colors.black,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 4,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ========== HELPER METHODS ==========

  List<Color> _getSleepScoreColor(int score) {
    if (score >= 90) return [Colors.green, Colors.lightGreen];
    if (score >= 70) return [Colors.blue, Colors.lightBlue];
    if (score >= 50) return [Colors.orange, Colors.amber];
    return [Colors.red, Colors.orange];
  }

  Color _getSleepScoreProgressColor(int score) {
    if (score >= 90) return Colors.green;
    if (score >= 70) return Colors.blue;
    if (score >= 50) return Colors.orange;
    return Colors.red;
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(Duration(days: 1));
    final dateDay = DateTime(date.year, date.month, date.day);

    if (dateDay == today) return 'Today';
    if (dateDay == yesterday) return 'Yesterday';
    return '${date.day}/${date.month}/${date.year}';
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    return '${hours}h ${minutes}m';
  }

  double _calculateTrackingProgress(Duration duration) {
    final totalMinutes = duration.inMinutes;
    return (totalMinutes / 480).clamp(0.0, 1.0); // 8 hours max
  }

  String _getWelcomeMessage() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Ready for a productive day?';
    if (hour < 17) return 'How about a quick meditation break?';
    if (hour < 21) return 'Time to wind down for better sleep';
    return 'Perfect time for sleep tracking!';
  }

  String _getTimeOfDay() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  }

  // ========== DIALOG METHODS ==========

  void _showNotifications() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Notifications feature coming soon!'),
        backgroundColor: Colors.blueAccent,
      ),
    );
  }

  void _showSleepAnalytics(BuildContext context, SleepTrackerProvider sleepProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Color(0xFF1D1E33),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Sleep Analytics', style: TextStyle(color: Colors.white)),
        content: Text(
          'Detailed sleep analytics and insights will be available in the next update.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK', style: TextStyle(color: Colors.blueAccent)),
          ),
        ],
      ),
    );
  }

  void _showSleepStories(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Sleep Stories feature coming soon!'),
        backgroundColor: Colors.purpleAccent,
      ),
    );
  }

  void _showBreathingExercises(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Breathing Exercises feature coming soon!'),
        backgroundColor: Colors.orangeAccent,
      ),
    );
  }

  void _showAllSleepHistory(BuildContext context, SleepTrackerProvider sleepProvider) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Full sleep history view coming soon!'),
        backgroundColor: Colors.blueAccent,
      ),
    );
  }

  void _showSubscriptionOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: BoxDecoration(
          color: Color(0xFF1D1E33),
          borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
        ),
        child: Padding(
          padding: EdgeInsets.all(25),
          child: Column(
            children: [
              Center(
                child: Container(
                  width: 40, height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white30,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Text('Upgrade to Premium',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
              SizedBox(height: 10),
              Text('Unlock all features and content',
                  style: TextStyle(color: Colors.white70, fontSize: 16)),
              SizedBox(height: 30),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildSubscriptionOption('Monthly', '\$9.99/month', '7-day free trial', Icons.calendar_today),
                      _buildSubscriptionOption('Yearly', '\$59.99/year', 'Save 50%', Icons.verified_user, isPopular: true),
                      _buildSubscriptionOption('Lifetime', '\$149.99', 'One-time payment', Icons.workspace_premium),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    final authProvider = Provider.of<AuthProvider>(context, listen: false);
                    authProvider.upgradeToPremium('monthly');
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('🎉 Welcome to Premium! All features unlocked.'),
                        backgroundColor: Colors.green,
                        duration: Duration(seconds: 3),
                      ),
                    );
                  },
                  child: Text('START FREE TRIAL'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSubscriptionOption(String period, String price, String savings, IconData icon, {bool isPopular = false}) {
    return Card(
      color: isPopular ? Colors.blueAccent.withOpacity(0.2) : Color(0xFF2A2B3D),
      margin: EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: isPopular ? Colors.blueAccent : Colors.transparent,
          width: 2,
        ),
      ),
      child: ListTile(
        leading: Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.blueAccent.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: Colors.blueAccent),
        ),
        title: Row(
          children: [
            Text(period, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            if (isPopular) ...[
              SizedBox(width: 8),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text('POPULAR',
                    style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold)),
              ),
            ],
          ],
        ),
        subtitle: Text(savings, style: TextStyle(color: Colors.white70)),
        trailing: Text(price,
            style: TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold, fontSize: 16)),
      ),
    );
  }
}